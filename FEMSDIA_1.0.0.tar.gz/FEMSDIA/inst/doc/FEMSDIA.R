## ----setup, include=FALSE-------------------------------------------------------------------------
options(width = 100)

## ----message=FALSE--------------------------------------------------------------------------------
require(FEMSDIA)

## -------------------------------------------------------------------------------------------------
ls("package:FEMSDIA")

## ----comment=NA-----------------------------------------------------------------------------------
args(FEMSDIA_run_steady)

## ----comment=NA-----------------------------------------------------------------------------------
args(FEMSDIA_run_dyna)

## ----comment=NA-----------------------------------------------------------------------------------
args(FEMSDIA_run_perturb)

## -------------------------------------------------------------------------------------------------
P  <- FEMSDIA_get_parms()
head(P)

## -------------------------------------------------------------------------------------------------
std <- FEMSDIA_run_steady()
print(FEMSDIA_get_budgetC(std))

## ----fig.width = 3, fig.height=4------------------------------------------------------------------
  std  <- FEMSDIA_run_steady(parms = list(Cflux = 2*1e3/12/365))
  std2 <- FEMSDIA_run_steady(parms = list(Cflux = 20*1e3/12/365))
  std3 <- FEMSDIA_run_steady(parms = list(Cflux = 200*1e3/12/365))
  
  pH  <- FEMSDIA_get_pH(std)
  pH2 <- FEMSDIA_get_pH(std2)
  pH3 <- FEMSDIA_get_pH(std3)
  matplot(x    = cbind(pH, pH2, pH3), y = FEMSDIA_get_depth(std), 
          ylim = c(0.10, 0), 
          main = "pH", ylab= "m", xlab = "-", 
          type = "l", lwd = 2, lty = 1)
  legend("bottomright", legend = c(2, 20, 200), title = "gC/m2/yr", 
         lty=1, col = 1:3, lwd = 2)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
  Cflux2 <- cbind (time = c(0,     100, 150, 175, 200,  250,  365),
                  flux  = c(0.01, 0.01,  10,   8,  12, 0.10, 0.01)) 
  Cflux1 <- Cflux3 <- Cflux2
  Cflux1[,2] <- Cflux1[,2]/10
  Cflux3[,2] <- Cflux3[,2]*10
  
  out1 <- FEMSDIA_run_dyna(parms   = list(pFast = 0.9), 
                         f_Cflux = list(data = Cflux1), 
                         spinup  = 0:365, 
                         times   = 0:365)
  out2 <- FEMSDIA_run_dyna(parms   = list(pFast = 0.9), 
                         f_Cflux = list(data = Cflux2), 
                         spinup  = 0:365,  times = 0:365)
  out3 <- FEMSDIA_run_dyna(parms   = list(pFast = 0.9), 
                         f_Cflux = list(data = Cflux3),  
                         spinup  = 0:365, times = 0:365)
  pH1 <- FEMSDIA_get_pH(out1)
  pH2 <- FEMSDIA_get_pH(out2)
  pH3 <- FEMSDIA_get_pH(out3)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
  par(oma = c(0,0,2,0))
  image2D(out1, 
          which = c("NH3", "O2", "NO3", "PO4", "H2S", "Fe", "SO4", "ALK"), 
          ylim  = c(0.10, 0), mfrow = c(3, 3))
  image2D(pH1, y = FEMSDIA_get_depth(out1), x = out1[,1], 
          ylim = c(0.10, 0), 
          clab = "", xlab = "day", ylab = "m", main = "pH")
  title(main = "Low flux", outer = TRUE)

  image2D(out3, 
          which = c("NH3", "O2", "NO3", "PO4", "H2S", "Fe", "SO4", "ALK"), 
          ylim = c(0.10, 0),  mfrow = c(3, 3))
  
  plot3D::image2D(pH3, y = FEMSDIA_get_depth(out3), x = out3[,1], 
                  ylim = c(0.10, 0), 
                  clab = "", xlab = "day", ylab = "m", main = "pH")
  title(main = "High flux", outer = TRUE)
  

## -------------------------------------------------------------------------------------------------
head(FEMSDIA_get_depth(std))
head(FEMSDIA_get_1Dvars(std), n = 3)

## -------------------------------------------------------------------------------------------------
FEMSDIA_get_parms(std, which = "Cflux")

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
convert <- 1e3/12/365

STD1 <- FEMSDIA_run_steady ()
STD2 <- FEMSDIA_run_steady (parms = list(Cflux = 100*convert))
STD3 <- FEMSDIA_run_steady (parms = list(Cflux = 2*convert))

plot(STD1, STD2, STD3, 
     which =  c(4:7, 10:11, 15), 
     lty = 1, lwd = 2, mfrow = c(3, 3))
plot(STD1, STD2, STD3, 
     which =  c( "OCpercent", "Fepercent"), 
     lty = 1, lwd = 2, mfrow = NULL)
legend("bottom", legend = c(20, 100, 2), lty = 1, col = 1:3, title = "gC/m2/yr")

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
Grid <- FEMSDIA_get_grid()
Irr  <- rep(0, Grid$N)
Irr[Grid$x.mid > 0.02 &  Grid$x.mid < 0.03] <- 1   

out    <- FEMSDIA_run_steady()
irrout <- FEMSDIA_run_steady(irrigation = Irr, run_steady_times = c(0, 1e5))

plot(out, irrout, 
     which = c(3:9), 
     ylim  = c(0.10, 0), lty = 1, lwd = 2)
plot(out, irrout, 
     which = c("OCpercent"), 
     ylim  = c(0.10, 0), lty = 1, lwd = 2, mfrow = NULL)
matplot(x = cbind(FEMSDIA_get_irr(out), FEMSDIA_get_irr(irrout)), 
        y = FEMSDIA_get_depth(out), 
        ylim = c(0.10, 0), 
        type = "l", lty = 1:2, lwd = 2, main = "irrigation")


## ----fig.width=4, fig.height=4--------------------------------------------------------------------
pH <- cbind(FEMSDIA_get_pH(out), FEMSDIA_get_pH(irrout))
matplot(x = pH, y = FEMSDIA_get_depth(out), 
        ylim = c(0.20,0), type = "l", 
        main = "pH", lty = 1, ylab = "depth")

## ----fig.width=8, fig.height=6, eval = FALSE------------------------------------------------------
# out1  <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 0))
# 
# out2  <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 1e2),
#                           yini = out1$y)
# out2b <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 1e3),
#                           yini = out2$y)
# out2c <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 5e3),
#                           yini = out2b$y,
#                           method = "mixed")
# out2d <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 8e3),
#                           yini = out2c$y,
#                           method = "mixed")
# out3  <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 1e4),
#                           yini = out2d$y,
#                           method = "mixed")
# out4  <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 5e4),
#                           yini = out3$y,
#                           method = "mixed")
# out5  <- FEMSDIA_run_steady(parms = c(por0 = 0.5, MPBprod = 1e5),
#                           yini = out4$y,
#                           method = "mixed")
# 
# PH1 <- FEMSDIA_get_pH(out1)
# PH2 <- FEMSDIA_get_pH(out2)
# PH3 <- FEMSDIA_get_pH(out3)
# PH4 <- FEMSDIA_get_pH(out4)
# PH5 <- FEMSDIA_get_pH(out5)

## ----fig.width=8, fig.height=6, eval = FALSE------------------------------------------------------
# plot(out1, out2, out3, out4, out5,
#      which = c(4,5:7),
#      ylim  = c(0.10, 0),
#      lty   = 1, lwd = 2, mfrow = c(2, 3))
# legend("center", col = 1:5, title = "prod, mmol/m3/d",
#        legend = c(0, 1e2, 1e4,  5e4, 1e5), lty = 1)
# plot(out1, out2, out3, out4, out5,
#      which = 3,
#      ylim  = c(0.03, 0),
#      lty   = 1, lwd = 2, mfrow = NULL)
# matplot(x = cbind(PH1, PH2, PH3, PH4, PH5),
#         y = FEMSDIA_get_depth(out1),
#         ylim = c(0.03, 0), type = "l", lty = 1, lwd = 2,
#         main = "pH", ylab = "", xlab = "")

## ----fig.width=6, fig.height=4, eval = FALSE------------------------------------------------------
# pH <- cbind(FEMSDIA_get_pH(out1),
#             FEMSDIA_get_pH(out2),
#             FEMSDIA_get_pH(out3),
#             FEMSDIA_get_pH(out4))
# par(mfrow = c(1,2))
# matplot(x = pH, y = FEMSDIA_get_depth(out1),
#         ylim = c(0.02,0), type = "l",
#         main = "pH", lty = 1, lwd = 2, ylab = "depth")
# matplot(x = pH, y = FEMSDIA_get_depth(out1),
#         ylim = c(0.10,0),
#         type = "l", main = "pH", lty = 1, lwd = 2, ylab = "depth")
# 

## ----eval = FALSE---------------------------------------------------------------------------------
# FEMSDIA_get_budgetO2(out1, out2, out3, out4)
# FEMSDIA_get_budgetC (out1, out2, out3, out4, which = "Rates")

## ----fig.width=8, fig.height=6, eval = FALSE------------------------------------------------------
# out    <- FEMSDIA_run_steady()
# outdry <- FEMSDIA_run_steady(parms = list(gasflux = 1),
#                              yini = out$y)
# 
# plot(out1, outdry,
#      which = c("O2", "NO3", "NH3",
#        "PO4", "FeP", "OCpercent"),
#      ylim  = c(0.10, 0), lty = 1, lwd = 2)
# legend("center", col = 1:2, title = "exchange",
#        legend = c("water", "dry"), lty = 1)
# 
# print(FEMSDIA_get_budgetO2(outdry))
# print(FEMSDIA_get_budgetN(outdry))

## -------------------------------------------------------------------------------------------------
FEMSDIA_get_parms(which = c("rSurfH2Sox", "rSurfCH4ox","ODUoxdepth", "ODUoxatt"))

## ----fig.width=8, fig.height=6--------------------------------------------------------------------
P <- FEMSDIA_get_parms(as.vector = TRUE)
P["rSurfH2Sox"]   <- 1
P["pFast"]        <- 0.2   # mmolFeOH3/m3 half-sat FeOH3 in iron red  
P["rSlow"]        <- 1e-5
P["kinFeOH3"]     <- 0.1
P["kinNO3anox"]   <- 0.1
P["FeOH3flux"]    <- 1
#P["ODUoxdepth"] <- 0.10
p0 <- p1 <- p2 <- p3 <- P

p1["Cflux"] <- 1
p2["Cflux"] <- 50 
p3["Cflux"] <- 100 #; p3["ODUoxdepth"] <- 0.10

out0    <- FEMSDIA_run_steady()
out0b   <- FEMSDIA_run_dyna (parms  = p0, 
                           yini   = out0$y,          
                           times  = c(0, 1e8))
out0b   <- FEMSDIA_run_dyna (parms  = p0, 
                           yini   = out0b[2, 2:2301], 
                           times  = c(0, 1e8))
out0c   <- FEMSDIA_run_steady(parms  = p0, 
                            yini   = out0b[2, 2:2301], 
                            method = "mixed")

out1ini <- FEMSDIA_run_steady(parms = list(Cflux = 1))
out1a   <- FEMSDIA_run_dyna (parms = p1, 
                           yini  = out1ini$y,       
                           times = c(0, 1e10))
out1a   <- FEMSDIA_run_dyna (parms = p1, 
                            yini   = out1a[2, 2:2301], 
                            times  = c(0, 1e10))
out1    <- FEMSDIA_run_steady(parms  = p1, 
                            yini   = out1a[2, 2:2301], 
                            method = "runsteady")

out2ini <- FEMSDIA_run_steady(parms  = list(Cflux = 50))
out2a   <- FEMSDIA_run_dyna (parms  = p2, 
                           yini   = out2ini$y, 
                           times  = c(0, 1e10))
out2    <- FEMSDIA_run_steady(parms  = p2, 
                           yini   = out2a[2, 2:2301], 
                           method = "runsteady")

out3ini <- FEMSDIA_run_steady(parms = list(Cflux = 100))
out3a   <- FEMSDIA_run_dyna (parms = p3, 
                           yini  = out3ini$y, 
                           times = c(0, 1e10))
out3    <- FEMSDIA_run_steady(parms = p3, 
                            yini  = out3a[2, 2:2301], 
                            method = "runsteady")

## ----fig.width=8, fig.height=6--------------------------------------------------------------------
plot(out0, out1, out2, out3, 
     which = c(6, 5), 
     ylim  = c(0.10, 0), 
     lty   = 1, lwd = 2, mfrow = c(2,2))
plot(out0, out1, out2, out3, 
     which = 3, 
     ylim  = c(0.005, 0), 
     lty = 1, lwd = 2, mfrow = NULL)
plot(out0,out1, out2, out3, 
     which = c("H2Soxsurf", "H2S", "SO4", "ALK"), 
     ylim  = c(0.30, 0), 
     lty   = 1, lwd = 2)
plot(out2, out3, 
  which = c("H2Soxsurf", "O2distConsump", "FeOH3", "BSRmin"), 
     ylim = c(0.05, 0), lty = 1, lwd = 2)


## -------------------------------------------------------------------------------------------------
FEMSDIA_get_budgetO2(out0, out1, out2, out3, which = "Fluxes")

## ----fig.width=4, fig.height=6--------------------------------------------------------------------
pH <- cbind(FEMSDIA_get_pH(out2),FEMSDIA_get_pH(out3))
matplot(x = pH, y = FEMSDIA_get_depth(out1), 
        ylim = c(0.02, 0), xlim = c(0, 10),
        type = "l", main = "pH", lty = 1, lwd = 2, ylab = "depth")

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
DIA <- FEMSDIA_run_dyna (Cflux = list(amp = 1))
pH  <- FEMSDIA_get_pH(DIA)

image2D(DIA, 
        which = c(4:7, 15), 
        ylim  = c(0.20, 0), mfrow = c(3, 3))
plot3D:::image2D(pH, y = FEMSDIA_get_depth(DIA), 
                 ylim = c(0.20, 0), main = "pH")
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(DIA, 
     which = c("NH3flux", "ALKflux"), 
     mfrow = NULL, lwd = 2)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
DIA <- FEMSDIA_run_dyna (parms     = list(MPBprod = 50000, por0 = 0.5),
                       f_MPBprod = list(amp = 4, phase = 100), 
                       spinup    = 0:365)
image2D(DIA, 
        which = 4:7, 
        ylim  = c(0.20, 0), mfrow = c(3,3))
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(DIA, 
     which = c("TotO2prod", "TotDenit","ALKflux","NO3flux","PO4flux"), 
     mfrow = NULL, lwd = 2)
print(FEMSDIA_get_budgetO2(DIA))

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
INI <- FEMSDIA_run_steady (parms = list(por0 = 0.5))

DIA <- FEMSDIA_run_dyna (parms     = list(MPBprod = 10000, por0 = 0.5), 
                       f_MPBprod = list(amp = 4, period = 1), 
                       yini      = INI$y,
                       spinup    = seq(0, 10, length.out = 1000), 
                       times     = seq(0,  3, length.out = 100))
PH <- FEMSDIA_get_pH(DIA)

image2D(DIA, 
        which = 4:7, 
        ylim = c(0.05, 0), mfrow = c(3,3))
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(DIA, 
     which = c("TotO2prod", "TotDenit","ALKflux","NO3flux","PO4flux"), 
     mfrow = NULL, lwd = 2)
print(FEMSDIA_get_budgetO2(DIA))

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
F <- 10
gasflux <- data.frame(time = c(0, 0.19999, 0.2, 0.6, 0.6661, 1.19999, 1.2, 
                               1.6, 1.6661, 2.19999, 2.2, 2.6, 2.6661, 3),
                flux       = c(0,  0,      F,   F,   0,      0      , F,   
                               F,   0,      0      ,F,   F,   0,      0    ))

yini <- FEMSDIA_run_steady (parms  = list(MPBprod = 10000))
DIA <- FEMSDIA_run_dyna (parms     = list(MPBprod = 10000), 
                         f_MPBprod = list(amp = 4, period = 1), 
                         f_gasflux = list(data = gasflux),
                         yini      = yini, 
                         spinup    = seq(0, 3, length.out = 100), 
                         times     = seq(0, 3, length.out = 100))

image2D(DIA, 
        which = c(4:7, 15), 
        ylim  = c(0.05, 0),  
        mfrow = c(3,4))
matplot.0D(DIA, 
           which = c("Cflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(DIA, 
     which = c("TotO2prod", "TotDenit","NO3flux","PO4flux",
               "DICflux","H2Sflux","ALKflux"), 
     mfrow = NULL, lwd = 2)
print(FEMSDIA_get_budgetO2(DIA))

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
fluxforcdat <- data.frame(time = c(0, 100, 101, 200, 201, 365),
                          flux = c(20, 20, 100, 100, 20, 20)*1e3/12/365)
O2forcdat <- data.frame(time = c(0, 100, 101, 200, 201, 365),
                        conc = c(200, 200, 10, 10, 200, 200))

DIA <- FEMSDIA_run_dyna (f_Cflux = list(data = fluxforcdat), 
                       f_O2bw  = list(data = O2forcdat), 
                       spinup  = 0:365)
image2D(DIA,  
        which = c(4:7, 15), 
        mfrow = c(3,3))
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2, main = "Fluxes")
plot(DIA, 
     which = c("O2bw","O2flux","NH3flux"), 
     mfrow = NULL, lwd = 2)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
fluxforcdat <- data.frame(time = c(0, 100, 101, 200, 201, 365),
                          flux = c(20, 20, 100, 100, 20, 20)*1e3/12/365)
seddat <- data.frame(time = c(0, 100, 101, 200, 201, 365),
                     w    = c(0.1, 0.1, 10, 10, 0.1, 0.1)/36500)  #m/d

DIA <- FEMSDIA_run_dyna (f_Cflux = list(data = fluxforcdat), 
                       f_w     = list(data = seddat), 
                       spinup  = 0:365)
image2D(DIA, 
        which = c(4:7, 10, 15),
        ylim  = c(0.20, 0), mfrow = c(3,3))
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2, main = "Fluxes")
plot(DIA, 
     which = c("w", "NH3flux"), 
     mfrow = NULL, lwd = 2)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
FF <- c(20,   30,  20,  10, 0,     0,   0,   0,   0, 0)*1e3/12/365
SS <- c(0.2, 0.2, 0.2, 0.1, 0., -0.1,-0.2,-0.2,-0.1, 0)/100  # m/d
FF <- rep(FF, times = 10)
Fluxforcdat <- data.frame(time = seq(0, to = 39.8, length.out = length(FF)), 
                          flux = FF)

SS <- rep(SS, times = 10)
Seddat <- data.frame(time = seq(0, to = 39.8, length.out = length(SS)), 
                     w    = SS)

times <- seq(0, 19, length.out = 300)

P <- list(Cflux = FF[1], w = SS[1])
std <- FEMSDIA_run_steady(parms = P)
DIA <- FEMSDIA_run_dyna (f_w    = list(data = Seddat), 
                       times  = times, 
                       spinup = times,
                       yini   = std$y)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
image2D(DIA, 
        which = c(4:7, 10, 15),
        ylim = c(0.15, 0), mfrow = c(3,3))
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2, main = "Fluxes")
plot(DIA, 
     which = c("w","NH3flux"), 
     mfrow = NULL, lwd = 2)


## -------------------------------------------------------------------------------------------------
DIA2 <- FEMSDIA_run_dyna (f_Cflux = list(data = Fluxforcdat), 
                        f_w     = list(data = Seddat),
                        times   = times, 
                        spinup  = times, 
                        yini    = std$y)

## ----fig.width=8, fig.height=8--------------------------------------------------------------------
image2D(DIA2, 
        which = c(4:7, 10, 15),
        ylim  = c(0.15, 0), mfrow = c(3,3))
matplot.0D(DIA2, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2, main = "Fluxes")
plot(DIA2, 
     which = c("w", "NH3flux"), 
     mfrow = NULL, lwd = 2)

print(FEMSDIA_get_budgetC(DIA, DIA2))

## -------------------------------------------------------------------------------------------------
std <- FEMSDIA_run_steady(dynamicbottomwater = FALSE, 
                        parms              = list(Cflux = 20*1e3/12/365))
FEMSDIA_get_budgetO2(std, which = "Fluxes")

## -------------------------------------------------------------------------------------------------
P <- FEMSDIA_get_parms(std, as.vector = TRUE, 
     which = c("O2bw", "NO3bw", "NO2bw", "NH3bw", 
               "Mnbw", "Febw", "H2Sbw", "SO4bw", 
               "CH4bw", "PO4bw", "DICbw", "ALKbw"))

# order of state variables, FDET,SDET,O2,NO3,NO2,NH3,DIC,Fe,FeOH3,H2S,SO4,CH4,PO4,FeP,CaP,Pads,ALK
BW <- c(0, 0, 0, P[c("O2bw", "NO3bw", "NO2bw", "NH3bw", "Mnbw")], 0,  
        P[c("Febw")], 0, P[c("H2Sbw", "SO4bw", "CH4bw", "PO4bw")], 
        0, 0, 0, 0, 0, 0, P[c("DICbw", "ALKbw")])  
dyn <- FEMSDIA_run_dyna(dynamicbottomwater = TRUE, 
                      yini               = rbind(BW, std$y), 
                      parms              = list(Cflux = 20*1e3/12/365), 
                      times              = seq(0, 2, length.out = 100))

## ----fig.width = 6, fig.height = 6----------------------------------------------------------------
image2D(dyn, 
        which = c("O2", "NO3", "NH3","CH4"), 
        ylim  = c(0.10,0))
plot(dyn, 
     which = c("O2_bw", "NO3_bw", "NH3_bw", "CH4_bw", "PO4_bw", "H2S_bw"))
plot(dyn, 
     which = c("O2flux",  "NO3flux", "NH3flux",
               "CH4flux", "PO4flux", "H2Sflux"))


## -------------------------------------------------------------------------------------------------
knitr:::kable(FEMSDIA_get_parms())

## -------------------------------------------------------------------------------------------------
knitr:::kable(FEMSDIA_get_states())

## -------------------------------------------------------------------------------------------------
knitr:::kable(FEMSDIA_get_0Dvars())

## -------------------------------------------------------------------------------------------------
knitr:::kable(FEMSDIA_get_1Dvars())

