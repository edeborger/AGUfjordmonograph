## ----setup, include=FALSE-------------------------------------------------------------------------
options(width = 100)

## ----message=FALSE--------------------------------------------------------------------------------
require(FEMSDIA)

## ----comment=NA-----------------------------------------------------------------------------------
args(FEMSDIA_run_perturb)

## -------------------------------------------------------------------------------------------------
times <- 0:730
DIA <- FEMSDIA_run_dyna(f_Cflux  = list(amp = 1), 
                        spinup   = 0:730, 
                        times    = times, 
                        verbose  = FALSE)

## ----fig.width=10, fig.height=10------------------------------------------------------------------
par (las = 1)
image2D(DIA, 
        which = c(4:7, 10, 23), 
        ylim = c(0.20, 0), mfrow = c(3, 3))
matplot.0D(DIA, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(DIA, 
     which = c("NH3flux", "Feflux"), 
     mfrow = NULL, lwd = 2)

## ----fig.width=8, fig.height=8, message = FALSE, warning = FALSE----------------------------------
times   <- 0:730
PERTmix <- FEMSDIA_run_perturb(f_Cflux       = list(amp = 1), 
                               spinup        = 0:730, 
                               times         = times, 
                               perturb_times = seq(from = 10, to = 730, by = 30), 
                               verbose       = FALSE)

image2D(PERTmix, 
        which = c(4:7, 10, 23), 
        ylim  = c(0.20, 0), mfrow = c(3, 3))

matplot.0D(PERTmix, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(PERTmix, 
     which = c("NH3flux", "Feflux"), 
     mfrow = NULL, lwd = 2)

## -------------------------------------------------------------------------------------------------
PertFlux <- attributes(PERTmix)$perturb_fluxes
knitr:::kable(rbind(PertFlux))

## -------------------------------------------------------------------------------------------------
rbind(perturbflux = (colSums(PertFlux)/730)[2:7],   
      ordinary    = summary(PERTmix)[4, 
                                     c("O2flux","NO3flux", "NH3flux", 
                                       "H2Sflux", "DICflux", "PO4flux")])

## ----fig.width=8, fig.height=8, message = FALSE, warning = FALSE----------------------------------
times <- 0:365
PERTdepo <- FEMSDIA_run_perturb(
                   spinup        = 0:365, 
                   times         = times, 
                   perturb_type  = "deposit", 
                   perturb_depth = 0.01,
                   perturb_times = seq(from = 10, to = max(times), by = 30), 
                   verbose       = FALSE)
image2D(PERTdepo, 
        which = c(4:7, 10, 23), , 
        ylim  = c(0.20, 0), 
        mfrow = c(3, 3))
matplot.0D(PERTdepo, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(PERTdepo, 
     which = c("NH3flux", "Feflux"), 
     mfrow = NULL, lwd = 2)

## -------------------------------------------------------------------------------------------------
PertFlux <- attributes(PERTdepo)$perturb_fluxes
rbind(perturbflux = (colSums(PertFlux)/365)[2:7],   
      ordinary = summary(PERTdepo)[4, c("O2flux","NO3flux", "NH3flux",
                                        "H2Sflux", "DICflux", "PO4flux")])

## ----fig.width=8, fig.height=8, message = FALSE, warning = FALSE----------------------------------
times <- 0:365
PERTdepo2 <- FEMSDIA_run_perturb(
                  spinup          = 0:365, 
                  times           = times, 
                  perturb_type    = "deposit", 
                  perturb_depth   = 0.01, 
                  perturb_concfac = 0.5, 
                  perturb_times   = seq(from = 10, to = max(times), by = 30), 
                  verbose         = FALSE)
image2D(PERTdepo2, 
        which = c(4:7, 10, 23), 
        ylim  = c(0.20, 0), 
        mfrow = c(3,3))
matplot.0D(PERTdepo2, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2, main = "Fluxes")
plot(PERTdepo2, 
     which = c("NH3flux", "Feflux"), 
     mfrow = NULL, lwd = 2)

## -------------------------------------------------------------------------------------------------
PertFlux <- attributes(PERTdepo2)$perturb_fluxes
rbind(perturbflux = (colSums(PertFlux)/365)[2:7],   
      ordinary = summary(PERTdepo2)[4, c("O2flux", "NO3flux", "NH3flux", 
                                         "H2Sflux", "DICflux", "PO4flux")])

## ----fig.width=8, fig.height=8, message = FALSE, warning = FALSE----------------------------------
times <- 0:365*2
PERTerode <- FEMSDIA_run_perturb(
                    Cflux         = list(amp = 1), 
                    spinup        = 0:365, 
                    times         = times, 
                    perturb_type  = "erode", 
                    perturb_depth = 0.01,
                    perturb_times = seq(from = 10, to = max(times), by = 30), 
                    verbose       = FALSE)

image2D(PERTerode, 
        which = c(4:7, 10, 23), , 
        ylim  = c(0.20, 0), mfrow = c(3,3))
matplot.0D(PERTerode, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(PERTerode, DIA,     # unperturbed fluxes in red
     which = c("NH3flux", "Feflux"), 
     mfrow = NULL, lwd = 2)

## -------------------------------------------------------------------------------------------------
PertFlux <- attributes(PERTerode)$perturb_fluxes
rbind(perturbflux = (colSums(PertFlux)/365)[2:7],   
      ordinary = summary(PERTerode)[4, c("O2flux", "NO3flux", "NH3flux",
                                         "H2Sflux", "DICflux", "PO4flux")])

## -------------------------------------------------------------------------------------------------
cbind(FEMSDIA_get_budgetO2(DIA)$Fluxes, 
      FEMSDIA_get_budgetO2(PERTerode)$Fluxes) 

## ----fig.width=8, fig.height=8, message = FALSE, warning = FALSE----------------------------------
times <- 0:365
fluxforcdat <- data.frame(time = c(0, 100, 101, 200, 201, 365),
                          flux = c(20, 20, 100, 100, 20, 20)*1e3/12/365)
BASE <- FEMSDIA_run_dyna(spinup = 0:365, 
                         times  = times, 
                         f_Cflux  = list(data = fluxforcdat))

PERTcomb <- FEMSDIA_run_perturb(
                   spinup = 0:365, 
                   times  = times, 
                   f_Cflux  = list(data = fluxforcdat),                         
                   perturb_times  = seq(from = 10, to = max(times), by = 30))

image2D(PERTcomb, 
        which = c(4:7, 10, 23), , 
        ylim  = c(0.20, 0), 
        mfrow = c(3, 3))
matplot.0D(PERTcomb, 
           which = c("OrgCflux", "O2flux"), 
           mfrow = NULL, lty = 1, lwd = 2)
plot(PERTcomb, 
     which = c("NH3flux", "Feflux"), 
     mfrow = NULL, lwd = 2)

## -------------------------------------------------------------------------------------------------
std <- FEMSDIA_run_steady(dynamicbottomwater = FALSE, 
                        parms              = list(Cflux = 20*1e3/12/365))
FEMSDIA_get_budgetO2(std, which = "Fluxes")

## -------------------------------------------------------------------------------------------------
P <- FEMSDIA_get_parms(std, as.vector = TRUE, which =
    c("O2bw", "NO3bw", "NO2bw", "NH3bw", 
      "Mnbw", "Febw", "H2Sbw", "SO4bw", 
      "CH4bw", "PO4bw", "DICbw", "ALKbw"))

# order of state variables: 
# FDET, SDET, RDET, 
# O2, NO3, NO2, NH3, Mn, MnO2, Fe, FeOH3, 
# H2S, SO4, CH4, PO4, FeP, CaP, Pads, FeS, FeS2, S0, DIC, ALK
BW <- c(0, 0, 0,   # FDET, SDET, RDET
        P[c("O2bw", "NO3bw", "NO2bw", "NH3bw", "Mnbw")], 0, 
        P[c("Febw")], 0, 
        P[c("H2Sbw", "SO4bw", "CH4bw", "PO4bw")], 
        0, 0, 0, 0, 0, 0, P[c("DICbw", "ALKbw")])  

times <- seq(0, 10, length.out = 100)

dyn  <- FEMSDIA_run_dyna(
                  dynamicbottomwater = TRUE, 
                  yini               = rbind(BW, std$y), 
                  parms = list(Cflux = 20*1e3/12/365), 
                  times = times)
dyn1 <- FEMSDIA_run_perturb(
                  dynamicbottomwater = TRUE, 
                  yini               = rbind(BW, std$y), 
                  perturb_type       = "mix", 
                  perturb_times      = 1, 
                  perturb_depth      = 0.01,
                  parms              = list(Cflux = 20*1e3/12/365), 
                  times              = times)
dyn2 <- FEMSDIA_run_perturb(
                  dynamicbottomwater = TRUE, 
                  yini               = rbind(BW, std$y), 
                  perturb_type       = "erode", 
                  perturb_times      = 1, 
                  perturb_depth      = 0.01,
                  parms              = list(Cflux = 20*1e3/12/365), 
                  times              = times)
dyn3 <- FEMSDIA_run_perturb(
                  dynamicbottomwater = TRUE, 
                  yini               = rbind(BW, std$y), 
                  perturb_type       = "deposit", 
                  perturb_times      = 1, 
                  perturb_depth      = 0.01,
                  parms              = list(Cflux = 20*1e3/12/365), 
                  times              = times)


## ----fig.width = 6, fig.height = 6----------------------------------------------------------------
image2D(dyn1, 
        which = c("O2", "NO3", "OCpercent"), 
        ylim  = c(0.10, 0), mfrow = c(3,3))
image2D(dyn2, 
        which = c("O2", "NO3", "OCpercent"), 
        ylim  = c(0.10, 0), mfrow = NULL)
image2D(dyn3, 
        which = c("O2", "NO3", "OCpercent"), 
        ylim  = c(0.10, 0), mfrow = NULL)

plot(dyn, dyn1, dyn2, dyn3, 
     which = c("O2bw", "NO3bw", "NH3bw", "CH4bw", "PO4bw", "H2Sbw"), 
     type  = "l", lwd = 2, lty = 1)
legend("top", col =1:4, lty = 1, lwd = 2, 
       legend = c("undisturbed", "mixed", "eroded", "deposited"))

plot(dyn, dyn1, dyn2, dyn3, 
     which = c("O2flux", "NO3flux", "NH3flux", "CH4flux", "PO4flux", "H2Sflux"), 
     type  = "l", lwd = 2, lty = 1)
legend("bottom", col =1:4, lty = 1, lwd = 2, 
       legend = c("undisturbed", "mixed", "eroded", "deposited"))

par(mfrow = c(2, 2))
matplot1D(dyn, 
          which = "OCpercent", 
          ylim = c(0.10, 0), 
          type = "l", col = "grey", mfrow = NULL, ylab = "undisturbed")
matplot1D(dyn1, 
          which = "OCpercent", 
          ylim = c(0.10, 0), 
          type = "l", col = "grey", mfrow = NULL, ylab = "mixed")
matplot1D(dyn2, 
          which = "OCpercent",  
          ylim = c(0.10, 0), 
          type = "l", col = "grey", mfrow = NULL, ylab = "eroded")
matplot1D(dyn3, 
          which = "OCpercent",  
          ylim = c(0.10, 0), 
          type = "l", col = "grey", mfrow = NULL, ylab = "deposited")

