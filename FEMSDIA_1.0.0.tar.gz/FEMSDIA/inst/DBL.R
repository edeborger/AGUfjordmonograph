# parameters
D    <- 1e-4    # diffusion coefficient in WATER
por_0  <- 0.8
tort <- por_0^2
Dstar <- D * tort  # Diff in upper sediment layer


DBL  <- 0.005

dx   <- 0.001
dx_int_0 <- dx/2

O2BW <- 300
O2_1 <- 298
ff   <- por_0*Dstar/dx_int_0
fac  <- ff*DBL


# FORMULA FOR w = 0

# FORMULA TO ESTIMATE CONC AT x=0
O2_0 <- (O2BW + fac* O2_1)/(1 + fac)

# Fluxes calculated two ways:
F_DBL <- (O2BW - O2_0)/DBL * D
F_0   <- (O2_0 - O2_1)* Dstar * por_0 / dx_int_0
c(O2_0, F_DBL, F_0)

# now with a w
w    <- 1e-6

#O2BW/DBL*D - O2_0/DBL*D  =  O2_0*ff*D - O2_1*ff*D  + w*D*O2_0
#O2BW/DBL*D + O2_1*ff*D   =  O2_0*(ff*D + D/DBL + w*por)

# FORMULA TO ESTIMATE CONC AT x=0
O2_0 = (O2BW/DBL*D + O2_1*Dstar*por_0)/(ff*D + D/DBL + w*por_0)

# or:
fac  = por_0 * Dstar / dx_int_0 * DBL
O2_0 = (O2BW * D/DBL + O2_1 * Dstar * por_0 / dx_int_0) / (Dstar * por_0 / dx_int_0 + D/DBL + w*por_0)

F_DBL <- (O2BW - O2_0)/DBL * D
F_0   <- (O2_0 - O2_1)* Dstar * por_0 / dx_int_0  + w *por_0 * O2_0
c(O2_0, F_DBL, F_0)
