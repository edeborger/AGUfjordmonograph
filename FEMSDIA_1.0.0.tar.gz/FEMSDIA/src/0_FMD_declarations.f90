!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! module declarations and common blocks
!
! Karline Soetaert, nioz-yerseke
!==========================================================================

!==========================================================================
! MODULES
!========================================================================== 

      MODULE dimfemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
! Number of boxes      
      INTEGER, PARAMETER :: N = 100, Np1 = N+1
      
! number of parameters passed from R     
      INTEGER, PARAMETER :: nparmsdia = 5*N + 5*(N+1) + 131
      INTEGER, PARAMETER :: nparmspH = 16
      INTEGER, PARAMETER :: nparms = nparmsdia + nparmspH
      
! number of forcing functions (data passed from R)
      INTEGER, PARAMETER :: nforcsdia = 27
      INTEGER, PARAMETER :: nforcspH  = 3 
      INTEGER, PARAMETER :: nforcs    = nforcsdia + nforcspH
      
! number of output variables (values passed to R)
      INTEGER, PARAMETER :: Noutdia   = 52*N + 122

! To check initialization
      LOGICAL :: initialized
      
! Flag for simple pH calculation
      LOGICAL ::  DynamicpH 

      END MODULE dimfemsdia

!==========================================================================

      MODULE modulefemsdia
      USE dimfemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
!------------------------------------------
!------------------------------------------
! state variables      
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION, DIMENSION(N) ::                                         &
     & FDET   , &! mmolC/m3 solid     Fast decaying Detritus (solid)
     & SDET   , &! mmolC/m3 solid     Slow decaying Detritus (solid)
     & RDET   , &! mmolC/m3 solid     Refractory Detritus (solid)
     & O2     , &! mmolO/m3 liquid    Oxygen (liquid)
     & NO3    , &! mmolN/m3 liquid    Nitrate (liquid)
     & NO2    , &! mmolN/m3 liquid    Nitrite (liquid)
     & NH3    , &! mmolN/m3 liquid    Ammonium/ammonia (liquid)
     & Mn     , &! mmolMn/m3 liquid   Mn2+ (liquid)! derivatives      
     & MnO2   , &! mmolMn/m3 solid    Mn-oxide (solid)
     & Fe     , &! mmolFe/m3 liquid   Fe2+ (liquid)
     & FeOH3  , &! mmolFe/m3 solid    Fe-oxide (solid)
     & H2S    , &! mmolS/m3 liquid    Sulphide (liquid)
     & SO4    , &! mmolS/m3 liquid    Sulphate (liquid)
     & CH4    , &! mmolC/m3 liquid    Methane (liquid)
     & PO4    , &! mmolP/m3 liquid    Phosphate (liquid)
     & FeP    , &! mmolP/m3 solid     Iron-bound P (solid)
     & CaP    , &! mmolP/m3 solid     Ca-bound P (solid)
     & Pads   , &! mmolP/m3 solid     Adsorbed P (solid)
     & FeS    , &! mmolFe/m3 solid    Iron sulphide (solid)
     & FeS2   , &! mmolFe/m3 solid    Pyrite (solid)
     & S0     , &! mmolS/m3 solid     Sulphur monoxide (liquid)
     & DIC    , &! mmolC/m3 liquid    Dissolved Inorganic Carbon (liquid)
     & ALK       ! mmol/m3 liquid     Alkalinity (liquid)

!------------------------------------------
! derivatives      
!------------------------------------------

      DOUBLE PRECISION :: dFdet(N),  dSdet(N), dRdet(N),                        &
     &  dO2(N),   dNO3(N), dNO2(N),   dNH3(N),                                  &
     &  dMn(N),  dMnO2(N),  dFe(N), dFeOH3(N),                                  &
     &  dH2S(N), dSO4(N),  dCH4(N),                                             &     
     &  dPO4(N),  dFeP(N), dCaP(N),  dPads(N),                                  &
     &  dFeS(N), dFeS2(N),  dS0(N),   dDIC(N),  dALK(N) 
     
!------------------------------------------
!------------------------------------------
! parameters - profiles
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION :: intpor(N+1)  ! -     porosity at interface
      DOUBLE PRECISION :: por(N)       ! -     porosity at middle
      DOUBLE PRECISION :: porfac(N+1)  ! -     porosity multiplication (for diffusion)
      DOUBLE PRECISION :: Db0(N+1)     ! m2/d  bioturbation profile (interface)
      DOUBLE PRECISION :: dx(N)        ! m     slice thickness
      DOUBLE PRECISION :: dxInt(N+1)   ! m     slice distance from mid to mid
      DOUBLE PRECISION :: x(N)         ! m     depth below surface
      DOUBLE PRECISION :: Aint(N+1)    ! m2    surface area at interface
      DOUBLE PRECISION :: Dirr0(N)     ! /d    irrigation profile
      DOUBLE PRECISION :: distreact(N) ! -     distance reoxidation with O2

!------------------------------------------
!------------------------------------------
! parameters, single numbers
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION ::                                                       &
! Fluxes
     & FePflux      , &! mmolP/m2/d    deposition rate of FeP (0.0)
     & CaPflux      , &! mmolP/m2/d    deposition rate of CaP (0.0)
     & Padsflux     , &! mmolP/m2/d    deposition rate of adsorbed P (0.0)
     & FeSflux      , &! mmolS/m2/d    deposition rate of FeS (0.0)
     & FeS2flux     , &! mmolS/m2/d    deposition rate of FeS2 (0.0)
     & S0flux       , &! mmolS/m2/d    deposition rate of S0 (0.0)
     & rRefrac      , &! /d            decay rate refractory detritus

     & rFast        , &! /d           decay rate FDET (6.849315e-02)
     & rSlow        , &! /d           decay rate SDET (1.369863e-04)

! organic matter composition 
     & NCrFdet      , &! molN/molC     NC ratio FDET (1.509434e-01)
     & NCrSdet      , &! molN/molC     NC ratio SDET (1.509434e-01)
     & NCrRdet      , &! molN/molC     NC ratio RDET (1.509434e-01)
     & PCrFdet      , &! molP/molC     PC ratio FDET (9.433962e-03)
     & PCrSdet      , &! molP/molC     PC ratio SDET (9.433962e-03)
     & PCrRdet      , &! molP/molC     PC ratio RDET (9.433962e-03)

! boundary conditions for solutes
     & BCup_O2      , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_NO3     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_NO2     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_NH3     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_Mn      , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_Fe      , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_H2S     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_SO4     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_CH4     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_PO4     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_DIC     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_Alk     , &! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     & BCup_Ca         ! -    upper boundary liq. 1:flux, 2:conc, 3:0-grad default: (2)
     

      DOUBLE PRECISION ::                                                       &
     & BCdwn_O2     , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_NO3    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_NO2    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_NH3    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_Mn     , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_Fe     , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_H2S    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_SO4    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_CH4    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_PO4    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_DIC    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_Alk    , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)
     & BCdwn_Ca     , &! -    lower boundary liq. 1:flux, 2:conc, 3:0-grad default: (3)

! deep water concentrations for solutes
     & dwO2         , &! mmol/m3       lower boundary O2   -if BC=1: flux, 2:conc        
     & dwNO3        , &! mmol/m3       lower boundary NO3  -if BC=1: flux, 2:conc          
     & dwNO2        , &! mmol/m3       lower boundary NO2  -if BC=1: flux, 2:conc          
     & dwNH3        , &! mmol/m3       lower boundary NH3  -if BC=1: flux, 2:conc          
     & dwMn         , &! mmol/m3       lower boundary Mn2+ -if BC=1: flux, 2:conc          
     & dwFe         , &! mmol/m3       lower boundary Fe2+ -if BC=1: flux, 2:conc         
     & dwH2S        , &! mmol/m3       lower boundary H2S  -if BC=1: flux, 2:conc          
     & dwSO4        , &! mmol/m3       lower boundary SO4  -if BC=1: flux, 2:conc          
     & dwCH4        , &! mmol/m3       lower boundary CH4  -if BC=1: flux, 2:conc          
     & dwPO4        , &! mmol/m3       lower boundary PO4  -if BC=1: flux, 2:conc          
     & dwDIC        , &! mmol/m3       lower boundary DIC  -if BC=1: flux, 2:conc          
     & dwALK           ! mmol/m3       lower boundary alk  -if BC=1: flux, 2:conc          

! diffusion coefficients

      DOUBLE PRECISION ::                                                       &
     & a_dispO2     , &! m2/d          diff. coeff at 0 degC of O2             
     & a_dispNO3    , &! m2/d          diff. coeff at 0 degC of NO3 
     & a_dispNO2    , &! m2/d          diff. coeff at 0 degC of NO2 
     & a_dispNH3    , &! m2/d          diff. coeff at 0 degC of NH3 
     & a_dispMn     , &! m2/d          diff. coeff at 0 degC of Mn2+
     & a_dispFe     , &! m2/d          diff. coeff at 0 degC of Fe2+
     & a_dispH2S    , &! m2/d          diff. coeff at 0 degC of H2S 
     & a_dispSO4    , &! m2/d          diff. coeff at 0 degC of SO4 
     & a_dispCH4    , &! m2/d          diff. coeff at 0 degC of CH4 
     & a_dispPO4    , &! m2/d          diff. coeff at 0 degC of PO4 
     & a_dispDIC    , &! m2/d          diff. coeff at 0 degC of DIC 
     & a_dispALK    , &! m2/d          diff. coeff at 0 degC of alkalinity
 
     & b_dispO2     , &! m2/d/dg       T-dependece par for diff coeff of O2 
     & b_dispNO3    , &! m2/d/dg       T-dependece par for diff coeff of NO3 
     & b_dispNO2    , &! m2/d/dg       T-dependece par for diff coeff of NO2 
     & b_dispNH3    , &! m2/d/dg       T-dependece par for diff coeff of NH3 
     & b_dispMn     , &! m2/d/dg       T-dependece par for diff coeff of Mn2+
     & b_dispFe     , &! m2/d/dg       T-dependece par for diff coeff of Fe2+
     & b_dispH2S    , &! m2/d/dg       T-dependece par for diff coeff of H2S 
     & b_dispSO4    , &! m2/d/dg       T-dependece par for diff coeff of SO4 
     & b_dispCH4    , &! m2/d/dg       T-dependece par for diff coeff of CH4 
     & b_dispPO4    , &! m2/d/dg       T-dependece par for diff coeff of PO4 
     & b_dispDIC    , &! m2/d/dg       T-dependece par for diff coeff of DIC 
     & b_dispALK       ! m2/d/dg       T-dependece par for diff coeff of alkalinity

! coefficients

      DOUBLE PRECISION ::                                                       &
     & TOC0         , &! %             refractory Carbon conc (5.0e-01)
     & Q10          , &! -             temperature multiplication factor for rates 
     & Treference   , &! dgC           reference temperature (at which rates are defined)

     & Dwater       , &! kg/m3         seawater density
     
     & ksO2oxic     , &! mmolO2/m3     half-sat O2 in oxic mineralisation (3.0)
     & ksNO3denit   , &! mmolNO3/m3    half-sat NO3 in denitrification (3.0e+01)
     & kinO2denit   , &! mmolO2/m3     half-sat O2 inhib denitrification (1.0)
     & kinO2anox    , &! mmolO2/m3     half-sat O2 inhib anoxic min (1.0e-03)
     & kinNO3anox   , &! mmolNO3/m3    half-sat NO3 inhib anoxic degr (1.0)
     & ksMnO2       , &! mmolMnO2/m3   half-sat MnO2 in manganese red (5.0e+03)
     & kinMnO2      , &! mmolMnO2/m3   half-sat MnO2 inhibition (5.0e+03)
     & ksFeOH3      , &! mmolFeOH3/m3  half-sat FeOH3 conc in iron reduction (1.25e+04)
     & kinFeOH3     , &! mmolFeOH3/m3  half-sat FeOH3 inhibition S reduction (1.25e+04)
     & ksSO4BSR     , &! mmolSO4/m3    half-sat SO4 conc in sulphate reduction (1.6e+03)
     & kinSO4Met    , &! mmolSO4/m3    half-sat SO4 inhibition methanogenesis (1.0e+03)

     & NH3Ads       , &! -             Adsorption coeff ammonium (1.3)
     & rnitri1      , &! /d            Max nitrification rate step1 (NH3ox) (2.0e+01)
     & rnitri2      , &! /d            Max nitrification rate step2 (NO2ox) (2.0e+01)
     & ksO2nitri    , &! mmolO2/m3     half-sat O2 in nitrification (1.0)
     & ranammox     , &! /(mmol/m3)/d  Anammox rate (1.0e-01)

     & rFePadsorp   , &! /(mmolLiq/m3)/d  rate FeP adsorption (1.0e-06)
     & rCaPprod     , &! /(mmolLiq/m3)/d  rate CaP production (0.0)
     & rCaPdiss     , &! /d               rate CaP dissolution (0.0)
     & CPrCaP       , &! molC:molP     C:Pratio in CaP (2.869565e-01)
     & rPads        , &! /d            adsorption rate PO4 (0.0)
     & rPdes        , &! /d            desorption rate of adsorbed P (0.0)
     & maxPads         ! mmolP/m3 sol. max adsorbed P concentration (1.0e+03)

      DOUBLE PRECISION ::                                                       &
     
     & rFeSprod     , &! /d/mmol/m3    rate FeS production (1.0e-03)
     & rFeS2prod_S0 , &! /d/mmol/m3    rate FeS2 production with S0 (1.0e-03)
     & rFeS2prod_HS , &! /d/mmol/m3    rate FeS2 production with HS (1.0e-03)
     & rMnCO3prod   , &! m3/mmol/d     MnCO3 production rate (0.0)
     & rFeCO3prod   , &! m3/mmol/d     FeCO3 production rate (0.0)
     
     & rMnox        , &! m3/mmol/d     Manganese oxidation rate with O2 (0.0)
     & rFeox        , &! /d/mmol/m3    max rate Fe oxidation (3.0e-01)
     & rH2Sox       , &! /d/mmol/m3    max rate H2S oxidation (5.0e-04)
     & rCH4ox       , &! /d/mmol/m3    max rate CH4 oxidation with O2 (2.7e+01)
     & rAOM         , &! /d/mmol/m3    max rate anaerobic oxidation Methane (3.0e-05)

     & rH2SMnox     , &! m3/mmol/d     rate of H2S oxidation by MnO2 (0.0)
     & rH2SFeox     , &! m3/mmol/d     rate of H2S oxidation by FeOH3 (0.0)
     & rFeMnox      , &! m3/mmol/d     rate of Fe + MnOx reaction (0.0)
     & rFeSox       , &! m3/mmol/d     FeS oxidation rate (0.0)
     & rFeS2ox      , &! m3/mmol/d     FeS2 oxidation rate (0.0)
     & rSurfH2Sox   , &! /d            max rate H2S oxidation with BW O2 (0.0)
     & rSurfCH4ox   , &! /d            max rate CH4 oxidation with BW O2 (0.0)
     & ksSurfALK    , &! mmol/m3       half-sat Alkalinity in oxid of H2S/CH4 with bwO2 (3000)
     & ksO2reox        ! mmolO2/m3     half-sat Oxygen in oxid of H2S/CH4 with bwO2 (1.0)

      DOUBLE PRECISION ::                                                       &
     
     & formationtype, &! -             formationfactor, 1=sand,2=fine sand,3=general (1.0)
     & dilution     , &! /d            relaxation towards background conc  (0.0)
     & Cfall        , &! m/d           fall speed of organic C (FDET, SDET) (1.0)
     & FePfall      , &! m/d           fall speed of FeP (when Hwater > 0) (1.0)
     & FeOH3fall    , &! m/d           fall speed of FeOH3 (when Hwater > 0) (1.0)
     & CaPfall      , &! m/d           fall speed of CaP (when Hwater > 0) (1.0
     & MnO2fall     , &! m/d           fall speed of MnO2 (1.0)

! (simple) MPB dynamics     
     & kdSed        , &! /m            sedimentary light extinction coefficient (2.0e+03)
     & kNH3upt      , &! mmol/m3       DIN limitation constant MPB (1.0e-02)
     & kPO4upt      , &! mmol/m3       P limitation constant MPB (1.0e-03)
     & kDICupt      , &! mmol/m3       C limitation constant MPB (1.0)

! Parameters relating to pH dynamics
     & rCALCdiss    , &! /d         Calcite dissolution rate (1.095890e-01)
     & pCa          , &! -          Calcite dissolution/precipitation power (2.74)
     & rARAGdiss    , &! /mmol/m3/d Aragonite dissolution/precipitation rate (3.013699e-01)
     & pAr          , &! -          Aragonite dissolution/precipitation power (2.43)
     & rCALCprod    , &! d          Calcite precipitation rate (0)
     & dwCa         , &! mmol/m3    deep Ca2+ concentration
     & CALCfall     , &! m/day      fall speed of suspended calcite (1)
     & ARAGfall     , &! m/day      fall speed of suspended aragonite (1)
     & a_DispHCO3   , &! m2/d       diffusion coefficient at 0 degC for HCO3
     & a_DispCO3    , &! m2/d       diffusion coefficient at 0 degC for CO3
     & a_DispCa     , &! m2/d       diffusion coefficient at 0 degC for Ca
     & b_DispHCO3   , &! m2/d/dgC   T dependece for diff coeff for HCO3
     & b_DispCO3    , &! m2/d/dgC   T dependece for diff coeff for CO3
     & b_DispCa        ! m2/d/dgC   T dependece for diff coeff for Ca

! Parameter common block: a combination of FEMSDIA and pHDIA parameters-
  
      COMMON /cbfemsdiapar /FePflux, CaPflux, Padsflux,                         &
     &  FeSflux, FeS2flux, S0flux, rFast, rSlow, rRefrac,                       &
     &  NCrFdet, NCrSdet, NCrRdet, PCrFdet, PCrSdet, PCrRdet,                   &
     &  dwO2, dwNO3, dwNO2, dwNH3, dwMn, dwFe, dwH2S, dwSO4,                    &
     &  dwCH4, dwPO4, dwDIC, dwALK, TOC0, Q10, Treference,                      & 
     &  ksO2oxic, ksNO3denit, kinO2denit, kinO2anox, kinNO3anox,                &
     &  ksMnO2, kinMnO2, ksFeOH3, kinFeOH3, ksSO4BSR, kinSO4Met,                &
     &  NH3Ads, rnitri1, rnitri2, ksO2nitri, ranammox,                          &
     &  rFePadsorp, rCaPprod, rCaPdiss, CPrCaP, rPads, rPdes,                   &
     &  maxPads, rFeSprod, rFeS2prod_S0, rFeS2prod_HS,                          & 
     &  rMnCO3prod, rFeCO3prod, rMnox, rFeox, rH2Sox, rCH4ox,                   &
     &  rAOM, rH2SMnox, rH2SFeox, rFeMnox, rFeSox, rFeS2ox,                     & 
     &  rSurfH2Sox, rSurfCH4ox, ksSurfALK, ksO2reox, dilution,                  &
     &  Cfall, FePfall, FeOH3fall, CaPfall, MnO2fall,                           & 
     &  kdSed, kNH3upt, kPO4upt, kDICupt, rCALCdiss, pCa,                       &
     &  rARAGdiss, pAr, rCALCprod, dwCa, CALCfall, ARAGfall,                    &  
     &  a_DispO2, a_DispNO3, a_DispNO2, a_DispNH3, a_DispMn,                    &
     &  a_DispFe, a_DispH2S, a_DispSO4, a_DispCH4, a_DispPO4,                   &    
     &  a_DispDIC, a_DispAlk, a_DispHCO3, a_DispCO3, a_DispCa,                  &
     &  b_DispO2, b_DispNO3, b_DispNO2, b_DispNH3, b_DispMn,                    &
     &  b_DispFe, b_DispH2S, b_DispSO4, b_DispCH4, b_DispPO4,                   &    
     &  b_DispDIC, b_DispAlk, b_DispHCO3, b_DispCO3, b_DispCa,                  &
     &  Dwater, BCup_O2, BCup_NO3, BCup_NO2, BCup_NH3,                          &
     &  BCup_Mn, BCup_Fe, BCup_H2S, BCup_SO4, BCup_CH4, BCup_PO4,               &
     &  BCup_DIC, BCup_ALK, BCup_Ca, BCdwn_O2, BCdwn_NO3, BCdwn_NO2,            &
     &  BCdwn_NH3, BCdwn_DIC, BCdwn_Mn, BCdwn_Fe, BCdwn_H2S,                    &
     &  BCdwn_SO4, BCdwn_CH4, BCdwn_PO4, BCdwn_ALK, BCdwn_Ca,                   &
     &  dx, dxint, x, Aint, por, intpor, porfac,                                &
     &  Db0, Dirr0, distreact                                                    

!------------------------------------------
!------------------------------------------
! forcings
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION  ::                                                      &
     & Carbonflux   , &! mmolC/m2/d   total organic C deposition (4.56621e+00)
     & pFast        , &! -            part FDET (fast-decay detritus) in carbon flux (9.0e-01() 
     & RDETflux     , &! mmolC/m2/d    deposition rate of RDET (0.5)
     & MnO2flux     , &! mmolMn/m2/d  deposition rate of MnO2    (0.0)
     & FeOH3flux    , &! mmolFe/m2/d  deposition rate of FeOH3 (1.0)
     & DBL          , &! m            diffusive boundary layer depth
     & flow         , &! m3/m2/d      water flow through pores
     & w            , &! m/d          advection rate (2.739726e-09)
     & biotfac      , &! -            bioturbation multiplication factor (1)
     & irrfac       , &! -            bio-irrigation multiplication factor (1)

     & bwO2         , &! mmol/m3      upper boundary O2  -if BC=1: flux, 2:conc (300)
     & bwNO3        , &! mmol/m3      upper boundary NO3 -if BC=1: flux, 2:conc (10)
     & bwNO2        , &! mmol/m3      upper boundary NO2 -if BC=1: flux, 2:conc (0.0)
     & bwNH3        , &! mmol/m3      upper boundary NH3 -if BC=1: flux, 2:conc (1.0)
     & bwMn         , &! mmol/m3      upper boundary Mn2+ if BC=1: flux, 2:conc (0.0)
     & bwFe         , &! mmol/m3      upper boundary Fe2+ if BC=1: flux, 2:conc (0.0)
     & bwH2S        , &! mmol/m3      upper boundary H2S -if BC=1: flux, 2:conc (0.0)
     & bwSO4        , &! mmol/m3      upper boundary SO4 -if BC=1: flux, 2:conc (31000)
     & bwCH4        , &! mmol/m3      upper boundary CH4 -if BC=1: flux, 2:conc (0.0)
     & bwPO4        , &! mmol/m3      upper boundary PO4 -if BC=1: flux, 2:conc (0.5)
     & bwDIC        , &! mmol/m3      upper boundary DIC -if BC=1: flux, 2:conc (210)
     & bwALK        , &! mmol/m3      upper boundary alk -if BC=1: flux, 2:conc (2400)
     & gasflux      , &! m/d          piston velocity for dry flats (0.0)
     & MPBprod      , &! mmol/m3/d    maximal MPB production rate (0.0)
     & Hwater       , &! m            water height
     & Twater       , &! degC         water temperature
     & Swater       , &! -             salinity
     

! Forcings relating to pH dynamics
     & CALCflux     , &! mmolC/m2/d   Calcite   deposition: (1.068)
     & ARAGflux     , &! mmolC/m2/d   Aragonite deposition: (0.575)
     & bwCa            ! mmol/m3      Ca++      conc in bottom water

! Common block
      COMMON /cbfemsdiaforc/ CarbonFlux, pFast, RDETflux,                       &
     &   MnO2flux, FeOH3flux, DBL, flow, w, biotfac, irrfac,                    &
     &   bwO2, bwNO3, bwNo2, bwNH3, bwMn, bwFe,                                 &
     &   bwH2S, bwSO4, bwCH4, bwPO4, bwDIC, bwALK,                              &
     &   gasflux, MPBprod, Hwater, Twater, Swater,                              &      
     &   CALCflux, ARAGflux, bwCa          

!------------------------------------------
!------------------------------------------
! 0-D output variables
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION  ::                                                      &
     & meanTemperature, &! deg C       mean sediment temperature  
     & O2flux        , &! mmolO2/m2/d  O2 influx sediment-water
     & O2deepflux    , &! mmolO2/m2/d  O2 efflux lower boundary
     & NO3flux       , &! mmolN/m2/d   NO3 influx sediment-water
     & NO3deepflux   , &! mmolN/m2/d   NO3 efflux lower boundary
     & NO2flux       , &! mmolN/m2/d   NO2 influx sediment-water
     & NO2deepflux   , &! mmolN/m2/d   NO2 efflux lower boundary
     & NH3flux       , &! mmolN/m2/d   NH3 influx sediment-water
     & NH3deepflux   , &! mmolN/m2/d   NH3 efflux lower boundary
     & Mnflux        , &! mmolMn/m2/d  Mn2+ influx sediment-water
     & Mndeepflux    , &! mmolMn/m2/d  Mn2+ efflux lower boundary
     & Feflux        , &! mmolFe/m2/d  Fe2+ influx sediment-water
     & Fedeepflux    , &! mmolFe/m2/d  Fe2+ efflux lower boundary
     & H2Sflux       , &! mmolS/m2/d   H2S influx sediment-water
     & H2Sdeepflux   , &! mmolS/m2/d   H2S efflux lower boundary
     & SO4flux       , &! mmolS/m2/d   SO4 influx sediment-water
     & SO4deepflux   , &! mmolS/m2/d   SO4 efflux lower boundary
     & CH4flux       , &! mmolC/m2/d   CH4 influx sediment-water
     & CH4deepflux   , &! mmolC/m2/d   CH4 efflux lower boundary
     & PO4flux       , &! mmolP/m2/d   PO4 influx sediment-water
     & PO4deepflux   , &! mmolP/m2/d   PO4 efflux lower boundary
     & DICflux       , &! mmolC/m2/d   DIC influx sediment-water
     & DICdeepflux   , &! mmolC/m2/d   DIC efflux lower boundary
     & ALKflux       , &! mmol/m2/d    Alkalinity influx sediment-water
     & ALKdeepflux      ! mmol/m2/d    Alkalinity efflux lower boundary

      DOUBLE PRECISION ::                                                       &
     
     & FDETflux      , &! mmolC/m2/d   FDET flux to sediment
     & FDETdeepflux  , &! mmolC/m2/d   FDET efflux lower boundary
     & SDETflux      , &! mmolC/m2/d   SDET flux to sediment
     & SDETdeepflux  , &! mmolC/m2/d   SDET efflux lower boundary
     & RDETdeepflux  , &! mmolC/m2/d   RDET efflux lower boundary
     & MnO2surfflux  , &! mmolMn/m2/d  MnO2 flux upper boundary
     & MnO2deepflux  , &! mmolMn/m2/d  MnO2 efflux lower boundary
     & FeOH3surfflux , &! mmolFe/m2/d  FeOH3 flux upper boundary
     & FeOH3deepflux , &! mmolFe/m2/d  FeOH3 efflux lower boundary
     & FePsurfflux   , &! mmolP/m2/d   FeP flux upper boundary
     & FePdeepflux   , &! mmolP/m2/d   FeP efflux lower boundary
     & CaPsurfflux   , &! mmolP/m2/d   CaP flux upper boundary
     & CaPdeepflux   , &! mmolP/m2/d   CaP efflux lower boundary
     & FeSsurfflux   , &! mmolFe/m2/d  FeS flux upper boundary
     & FeSdeepflux   , &! mmolFe/m2/d  FeS efflux lower boundary
     & FeS2surfflux  , &! mmolFe/m2/d  FeS2 flux upper boundary
     & FeS2deepflux  , &! mmolFe/m2/d  FeS2 efflux lower boundary
     & S0surfflux    , &! mmolS/m2/d   S0 flux upper boundary
     & S0deepflux    , &! mmolS/m2/d   S0 efflux lower boundary

     & OrgCflux      , &! mmolC/m2/d   OrgC influx to sediment
     & OrgNflux      , &! mmolN/m2/d   OrgN influx to sediment
     & OrgPflux      , &! mmolP/m2/d   OrgP influx to sediment
     & DINDIPflux    , &! molN/molP    DIN:DIP ratio flux sediment-water
     & DINDIPmean    , &! molN/molP    DIN:DIP mean concentration
     & DINDIPdeep       ! molN/molP    DIN:DIP deep concentration

      DOUBLE PRECISION ::                                                       &
     
     & TotMin        , &! mmolC/m2/d   Vertically integrated Mineralisation
     & TotOxic       , &! mmolC/m2/d   Vertically integrated oxic Mineralisation
     & TotDenit      , &! mmolC/m2/d   Vertically integrated Denitrification
     & TotMnred      , &! mmolC/m2/d   Vertically integrated Manganese reduction
     & TotFered      , &! mmolC/m2/d   Vertically integrated Iron reduction
     & TotBSR        , &! mmolC/m2/d   Vertically integrated Sulphate reduction
     & TotMeth       , &! mmolC/m2/d   Vertically integrated Methanogenesis
     & PartOxic      , &! -            Part of mineralisation by oxic min
     & PartDenit     , &! -            Part of mineralisation by denitrification
     & PartMnred     , &! -            Part of mineralisation by manganese reduction
     & PartFered     , &! -            Part of mineralisation by iron reduction
     & PartBSR       , &! -            Part of mineralisation by sulphate reduction
     & PartMethano   , &! -            Part of mineralisation by methanogenisis
     & TotNH3prodMin , &! mmolN/m2/d   Vertically integrated NH3 production by mineralisation
     & TotPO4prodMin , &! mmolP/m2/d   Vertically integrated PO4 production by mineralisation
     & TotALkprod    , &! mmol/m2/d    Vertically integrated alkalinity production

     & TotNH3adsorp  , &! mmolN/m2/d   Vertically integrated NH3 adsorption
     & TotNitri1     , &! mmolN/m2/d   Vertically integrated nitrification step 1 (NH3 ox)
     & TotNitri2     , &! mmolN/m2/d   Vertically integrated nitrification step 2 (NO2 ox)
     & TotAnammox    , &! mmolN/m2/d   Vertically integrated anammox

     & TotFePprod    , &! mmolFe/m2/d  Vertically integrated FeP production
     & TotCaPprod    , &! mmolP/m2/d   Vertically integrated CaP production
     & TotFePdesorp  , &! mmolP/m2/d   Vertically integrated FeP desorption
     & TotCaPdiss    , &! mmolP/m2/d   Vertically integrated CaP dissolution
     & TotPadsorp       ! mmolP/m2/d   Vertically integrated P adsorption

      DOUBLE PRECISION ::                                                       &
     
     & TotFeSprod    , &! mmolFe/m2/d  Vertically integrated FeS production
     & TotFeS2prod   , &! mmol/m2/d    Vertically integrated FeS2 prod using S0",
     & TotFeS2prodB  , &! mmol/m2/d    Vertically integrated FeS2 prod using HS",
     & TotMnCO3prod  , &! mmol/m2/d    Vertically integrated MnCO3 production",
     & TotFeCO3prod  , &! mmol/m2/d    Vertically integrated FeCO3 production",

     & TotMnoxid     , &! mmol/m2/d    Vertically integrated Mn2+ oxidation",
     & TotFeoxid     , &! mmolFe/m2/d  Vertically integrated Fe2+ oxidation
     & TotH2Soxid    , &! mmolS/m2/d   Vertically integrated H2S oxidation
     & TotCH4oxid    , &! mmolC/m2/d   Vertically integrated CH4 oxidation
     & TotAOM        , &! mmolS/m2/d   Vertically integrated Anaerobic oxidation methane

     & TotH2SMnoxid  , &! mmol/m2/d    Vertically integrated H2S oxidation by MnO2 to S0",
     & TotH2SFeoxid  , &! mmol/m2/d    Vertically integrated H2S oxidation by FeO2 to S0",
     & TotFeMnoxid   , &! mmol/m2/d    Vertically integrated Fe oxidation with MnOx",
     & TotFeSoxid    , &! mmol/m2/d    Vertically integrated FeS oxidation",
     & TotFeS2oxid   , &! mmol/m2/d    Vertically integrated FeS2 oxidation",

     & TotH2Soxsurf  , &! mmolS/m2/d   Vertically integrated H2S oxidation by surface O2
     & TotCH4oxsurf     ! mmolC/m2/d   Vertically integrated CH4 oxidation by surface O2

      DOUBLE PRECISION ::                                                       &
     
     & PartPremoved  , &! -            Part P removed
     & PartNremoved  , &! -            Part N removed
     & TotMPBNO3uptake, &! mmolN/m2/d  Vertically integrated MPB NO3 uptake
     & TotMPBNH3uptake, &! mmolN/m2/d  Vertically integrated MPB NH3 uptake
     & TotMPBPO4uptake, &! mmolP/m2/d  Vertically integrated MPB PO4 uptake
     & TotMPBDICuptake, &! mmolC/m2/d  Vertically integrated MPB DIC uptake
     & TotMPBO2prod  , &! mmolO2/m2/d  Vertically integrated MPB O2 production
     
     & TotalFDET    , &! mmolC/m2     Vertically integrated Fast decaying Detritus
     & TotalSDET    , &! mmolC/m2     Vertically integrated Slow decaying Detritus
     & TotalRDET    , &! mmolC/m2     Vertically integrated Slow decaying Detritus
     & TotalO2      , &! mmolO/m2     Vertically integrated Oxygen
     & TotalNO3     , &! mmolN/m2     Vertically integrated Nitrate
     & TotalNO2     , &! mmolN/m2     Vertically integrated Nitrite
     & TotalNH3     , &! mmolN/m2     Vertically integrated Ammonium/ammonia
     & TotalMn      , &! mmolMn/m2    Vertically integrated Mn2+
     & TotalMnO2    , &! mmolMn/m2    Vertically integrated MnO2
     & TotalFe      , &! mmolFe/m2    Vertically integrated Fe2+
     & TotalFeOH3   , &! mmolFe/m2    Vertically integrated FeOH3
     & TotalH2S     , &! mmolS/m2     Vertically integrated H2S
     & TotalSO4     , &! mmolS/m2     Vertically integrated SO4
     & TotalCH4     , &! mmolC/m2     Vertically integrated CH4
     & TotalPO4     , &! mmolP/m2     Vertically integrated Phosphate
     & TotalFeP     , &! mmolP/m2     Vertically integrated Iron-bound P
     & TotalCaP     , &! mmolP/m2     Vertically integrated Ca-bound P
     & TotalPads    , &! mmolP/m2     Vertically integrated Adsorbed P
     & TotalDIC     , &! mmolC/m2     Vertically integrated Dissolved Inorganic Carbon
     & TotalALK     , &! mmol/m2      Vertically integrated alkalinity
     & TotalFeS     , &! mmolFe/m2    Vertically integrated FeS
     & TotalFeS2    , &! mmolFe/m2    Vertically integrated FeS2
     & TotalS0         ! mmolS/m2     Vertically integrated S0

!------------------------------------------
!------------------------------------------
! 1-D output variables
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION, DIMENSION(N) ::                                         &
     & OCpercent    , &! %      Total Organic Carbon % profile
     & ONpercent    , &! %      Total Organic Nitrogen in % of dry sediment profile 
     & Ppercent     , &! %      Total P in % of dry sediment profile
     & Mnpercent    , &! %      Total Mn in % of dry sediment profile 
     & Fepercent    , &! %      Total Fe in % of dry sediment profile 
     & Spercent     , &! %      Total S in % of dry sediment profile
     & Solidpercent , &! %      Total solid Fe + S + Mn % profile
     
     & Temperature  , &! degC   Temperature

     & DICprodMin   , &! mmolC/m3 liquid/d   DIC production profile (mineralisation)
     & DINprodMin   , &! mmolN/m3 liquid/d   DIN production profile (mineralisation)
     & DIPprodMin   , &! mmolP/m3 liquid/d   DIP production profile (mineralisation)
     & DICprodCH4   , &! mmolC/m3 liquid/d   DIC production via Methane profile
     & DICprod      , &! mmolC/m3 liquid/d   Total DIC production
     & ALKprod      , &! mmol/m3 liquid/d    Alkalinity production profile
     
     & Oxicmin      , &! mmolC/m3 liquid/d   Oxic mineralisation profile
     & Denitrific   , &! mmolC/m3 liquid/d   Denitrification profile
     & MnredMin     , &! mmolC/m3 liquid/d   Mn reduction mineralisation profile
     & Feredmin     , &! mmolC/m3 liquid/d   Fe reduction mineralisation profile
     & BSRmin       , &! mmolC/m3 liquid/d   Sulphate reduction mineralisation profile
     & Methmin      , &! mmolC/m3 liquid/d   Methanogensis mineralisation profile

     & Nitri1       , &! mmolN/m3 liquid/d   Nitrification step1 profile (NH3 oxidation)
     & Nitri2       , &! mmolN/m3 liquid/d   Nitrification step2 profile (NO2 oxidation)
     & Anammox      , &! mmolN/m3 liquid/d   Anammox profile

     & FePadsorp    , &! mmolFe/m3 liquid/d  FeP adsorption profile
     & FePdesorp    , &! mmolP/m3 solid/d    FeP desorption profile
     & CaPprod      , &! mmolP/m3 liquid/d   CaP production profile
     & CaPdiss      , &! mmolP/m3 solid/d    CaP dissolution profile
     & Padsorp         ! mmolP/m3 solid/d    (net) P adsorption profile

      DOUBLE PRECISION, DIMENSION(N) ::                                         &

     & FeSprod      , &! mmolFe/m3 liquid/d  FeS production profile
     & FeS2prod     , &! mmolFe/m3 liquid/d  FeS2 production profile using S0
     & FeS2prodB    , &! mmolFe/m3 liquid/d  FeS2 production profile using HS
     & MnCO3prod    , &! mmolMn/m3 liquid/d  MnCO3 production profile
     & FeCO3prod    , &! mmolFe/m3 liquid/d  FeCO3 production profile

     & Mnoxid       , &! mmolMn/m3 liquid/d  Mn2+ oxidation profile
     & Feoxid       , &! mmolFe/m3 liquid/d  Fe2+ oxidation profile
     & H2Soxid      , &! mmolS/m3 liquid/d   H2S oxidaton profile
     & CH4oxid      , &! mmolC/m3 liquid/d   CH4 oxidation profile
     & AOM          , &! mmolS/m3 liquid/d   Anaerobic oxidation of methane profile

     & H2SMnoxid    , &! mmolFe/m3 liquid/d  H2S oxidation with MnO2 to S0 profile
     & H2SFeoxid    , &! mmolS/m3 liquid/d   H2S oxidation with FeO2 to S0 profile
     & FeMnoxid     , &! mmolS/m3 liquid/d   Fe oxidation with MnOx profile
     & FeSoxid      , &! mmolFe/m3 solid/d   FeS oxidation profile
     & FeS2oxid     , &! mmolFe/m3 solid/d   FeS2 oxidation profile

     & H2Soxsurf    , &! mmolS/m3 liquid/d   H2S oxidation with surface O2 profile
     & CH4oxsurf    , &! mmolC/m3 liquid/d   CH4 oxidation with surface O2 profile
     & O2distConsump, &! mmolO/m3 liquid/d   O2 uptake oxidation with surface O2 profile
    
     & MPBCprod     , &! mmolC/m3 solid/d    MPB C production profile
     & MPBO2prod    , &! mmolO2/m3 solid/d   MPB O2 production profile
     & MPBuptakeNO3 , &! mmolN/m3 liquid/d   MPB NO3 uptake profile
     & MPBuptakeNH3 , &! mmolN/m3 liquid/d   MPB NH3 uptake profile
     & MPBuptakePO4 , &! mmolP/m3 liquid/d   MPB PO4 uptake profile
     & MPBuptakeDIC    ! mmolC/m3 liquid/d   MPB DIC uptake profile

! Common block
   
      COMMON /cbfemsdiaout/meanTemperature,                                     &
     &  O2flux, O2deepflux, NO3flux, NO3deepflux, NO2flux,                      &
     &  NO2deepflux, NH3flux, NH3deepflux, Mnflux, Mndeepflux,                  &
     &  Feflux, Fedeepflux, H2Sflux, H2Sdeepflux, SO4flux,                      &
     &  SO4deepflux, CH4flux, CH4deepflux, PO4flux, PO4deepflux,                &
     &  DICflux, DICdeepflux, ALKflux, ALKdeepflux, FDETflux,                   &
     &  FDETdeepflux, SDETflux, SDETdeepflux, RDETdeepflux,                     &
     &  MnO2surfflux, MnO2deepflux, FeOH3surfflux, FeOH3deepflux,               &
     &  FePsurfflux, FePdeepflux, CaPsurfflux, CaPdeepflux,                     &
     &  FeSsurfflux, FeSdeepflux, FeS2surfflux, FeS2deepflux,                   &
     &  S0surfflux, S0deepflux, OrgCflux, OrgNflux, OrgPflux,                   &
     &  DINDIPflux, DINDIPmean, DINDIPdeep, TotMin,                             & 
     &  TotOxic, TotDenit, TotMnred, TotFered, TotBSR, TotMeth,                 &
     &  PartOxic, PartDenit, PartMnred, PartFered, PartBSR,                     &
     &  PartMethano, TotNH3prodMin, TotPO4prodMin, TotALkprod,                  &
     &  TotNH3adsorp, TotNitri1, TotNitri2, TotAnammox, TotFePprod,             &
     &  TotCaPprod, TotFePdesorp, TotCaPdiss, TotPadsorp, TotFeSprod,           &
     &  TotFeS2prod, TotFeS2prodB, TotMnCO3prod, TotFeCO3prod,                  &
     &  TotMnoxid, TotFeoxid, TotH2Soxid, TotCH4oxid,                           &
     &  TotAOM, TotH2SMnoxid, TotH2SFeoxid, TotFeMnoxid,                        &
     &  TotFeSoxid, TotFeS2oxid, TotH2Soxsurf, TotCH4oxsurf,                    &
     &  PartPremoved, PartNremoved, TotMPBNO3uptake, TotMPBNH3uptake,           &
     &  TotMPBPO4uptake, TotMPBDICuptake, TotMPBO2prod,                         &
     &  TotalFDET, TotalSDET, TotalRDET, TotalO2, TotalNO3, TotalNO2,           &
     &  TotalNH3, TotalMn, TotalMnO2, TotalFe, TotalFeOH3,                      &
     &  TotalH2S, TotalSO4, TotalCH4, TotalPO4, TotalFeP, TotalCaP,             &
     &  TotalPads, TotalFeS, TotalFeS2, TotalS0, TotalDIC, TotalALK,            &

     ! 1Dvar
     &  OCpercent, ONpercent, Ppercent, Mnpercent, Fepercent, Spercent,         &
     &  Solidpercent, Temperature,                                              &
     &  DICprodMin, DINprodMin, DIPprodMin, DICprodCH4, DICprod,                &
     &  ALKprod, Oxicmin, Denitrific, MnredMin, Feredmin,                       &
     &  BSRmin, Methmin, Nitri1, Nitri2, Anammox, FePadsorp, FePdesorp,         &
     &  CaPprod, CaPdiss, Padsorp, FeSprod, FeS2prod,                           &
     &  FeS2prodB, MnCO3prod, FeCO3prod, Mnoxid, Feoxid,                        &
     &  H2Soxid, CH4oxid, AOM, H2SMnoxid, H2SFeoxid, FeMnoxid,                  &
     &  FeSoxid, FeS2oxid, H2Soxsurf, CH4oxsurf, O2distConsump,                 &
     &  MPBCprod, MPBO2prod, MPBuptakeNO3, MPBuptakeNH3,                        &
     &  MPBuptakePO4, MPBuptakeDIC   

!------------------------------------------
! -----------------------------------
! local variables
! -----------------------------------
!------------------------------------------

      DOUBLE PRECISION  :: Flux(N+1)       ! Fluxes at interface
      DOUBLE PRECISION  :: intTemp(N+1)    ! Temperature at interface
      
! limitation factors for mineralisation processes
      DOUBLE PRECISION  ::                                                      &
     &  Oxicminlim(N), Denitrilim(N), Feredlim(N), BSRlim(N),                   &
     &  Methlim(N),    MnredLim(N)

! limitation factors for precipitation processes
      DOUBLE PRECISION :: Solid_inhib(N)     

! conversions from liquid to solid and vice versa
      DOUBLE PRECISION :: liquid2solid(N), solid2liquid(N)

! total flow for liquids (sum of accretion and porewater flow)      
      DOUBLE PRECISION :: v_liquid(N+1)

! rate factor taking into account temperature   
      DOUBLE PRECISION :: rateFac(N)

! Boundary conditions as integers      
      INTEGER :: BCup
      INTEGER ::  BCupO2, BCupNO3, BCupNO2, BCupNH3,                            &
     &   BCupMn,  BCupFe, BCupH2S, BCupSO4, BCupCH4, BCupPO4,                   &
     &   BCupDIC, BCupALK, BCupCa
      INTEGER ::  BCdwnO2, BCdwnNO3, BCdwnNO2, BCdwnNH3,                        &
     &  BCdwnMn,  BCdwnFe, BCdwnH2S, BCdwnSO4, BCdwnCH4, BCdwnPO4,              &
     &  BCdwnDIC, BCdwnALK, BCdwnCa
     
      END MODULE modulefemsdia
     
!==========================================================================
! module for dynamic bottom water modelling 
!==========================================================================

      MODULE modulebwfemsdia
      
      DOUBLE PRECISION ::  FdetBW, SdetBW, RdetBW, O2BW, NO3BW, NO2bw,          &
     &       NH3bw, PO4bw,FePBW, CaPBW, Mnbw, MnO2bw, FeBW, FeOH3bw,            &
     &       H2Sbw, SO4bw, CH4bw, Padsbw, FeSbw, FeS2bw, S0bw,                  &
     &       DICbw, ALKbw
      DOUBLE PRECISION :: dFdetBW, dSdetBW, dRdetBW, dO2BW, dNO3BW,             &
     &       dNO2BW, dNH3BW, dMnbw, dMnO2bw, dFeBW, dFeOH3bw,                   &
     &       dH2Sbw, dSO4bw, dCH4bw, dPO4BW, dFePBW, dCaPBW, dPadsbw,           &
     &       dFeSbw, dFeS2bw, dS0bw, dDICbw, dALKbw  

      END MODULE modulebwfemsdia
