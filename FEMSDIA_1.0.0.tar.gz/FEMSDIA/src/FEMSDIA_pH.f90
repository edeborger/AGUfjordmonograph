!==========================================================================
! pH dynamics, to be used with FEMSDIA
!
! Karline Soetaert, nioz-yerseke
!==========================================================================

!==========================================================================
! MODULES
!========================================================================== 

      MODULE dimphdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      LOGICAL            :: InitialisedPH

      INTEGER, PARAMETER :: noutpH   = 830

      END MODULE dimphdia

!==========================================================================

      MODULE modulephdia

      USE dimphdia
      USE dimfemsdia  !N, Nparms, Nout etc...
      
      IMPLICIT NONE

!......................... declaration section.............................
!------------------------------------------
!------------------------------------------
! state variables      
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION, DIMENSION(N) ::                                         &
     & CALC    , &! mmolC/m3 solid   Calcite calcium carbonate, solid
     & ARAG    , &! mmolC/m3 solid   Aragonite calcium carbonate, solid
     & Ca         ! mmolC/m3 liquid  Calcium ion Ca++, liquid

!------------------------------------------
! derivatives      
!------------------------------------------

      DOUBLE PRECISION  :: dCALC(N), dARAG(N), dCa(N)

!------------------------------------------
!------------------------------------------
! 0-D output variables
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION ::                                                       &
     &  CaFlux       , &! mmolC/m2/d     Ca++ influx sediment-water 
     &  Cadeepflux   , &! mmolC/m2/d     Ca++ efflux lower boundary
     &  CALCdeepflux , &! mmolC/m2/d     Calcite efflux lower boundary
     &  ARAGdeepflux , &! mmolC/m2/d     Aragonite efflux lower boundary
     &  TotCALCdiss  , &! mmolC/m2/d     Integrated Calcite dissolution
     &  TotARAGdiss  , &! mmolC/m2/d     Integrated Aragonate dissolution  
     &  TotCALCprod  , &! mmolC/m2/d     Integrated Calcite production
     &  TotalCALC    , &! mmolC/m2       Integrated Calcite concentration 
     &  TotalARAG    , &! mmolC/m2       Integrated Aragonite concentration
     &  TotalCa         ! mmolC/m2       Integrated Ca2+ (ion) concentration

!------------------------------------------
!------------------------------------------
! 1-D output variables
!------------------------------------------
!------------------------------------------

      DOUBLE PRECISION ::                                                       &
     &  ks(20)       , &! mol/kg-soln    dissociation constants  (*) 
     &  CALCdiss(N)  , &! mmolC/m3 sol/d Calcite dissolution profile   
     &  ARAGdiss(N)  , &! mmolC/m3 sol/d Aragonite dissolution profile  
     &  CALCprod(N)  , &! mmolC/m3 liq/d Calcite production profile
     &  pH(N)        , &! -              pH profile
     &  omegaCa(N)   , &! -              Calcite saturation state profile
     &  omegaAr(N)   , &! -              Aragonite saturation state profile
     &  CO3(N)       , &! mmolC/m3       CO3 concentration profile  
     &  CO2(N)          ! mmolC/m3       CO2 concentration profile

! (*)   ks contains: 
!       KH2O, KHF, KH2CO3, KHCO3, KBOH3, KNH4, KH2S, KHS, KH3PO4, KH2PO4 
!       KHPO4, KHSO4, KH2SO4, K0CO2, KspCalcite, KspAragonite, TotToFree, 
!       SWSToFree, Borate, Fluoride
     
      COMMON /myoutpH/CaFlux, Cadeepflux, CALCdeepflux,                         &
     &  ARAGdeepflux, TotCALCDiss, TotARAGDiss,  TotCALCprod,                   &
     &  TotalCALC, TotalARAG, TotalCa, ks, CALCdiss, ARAGdiss,                  &
     &  CALCprod, pH, omegaCa, omegaAr, CO3, CO2

!------------------------------------------
!------------------------------------------
! local variables
!------------------------------------------
!------------------------------------------

! Equilibrium constants and species, used in pH subroutine
      DOUBLE PRECISION  :: species(10) 
      
      END MODULE modulephdia

!==========================================================================
! initialise the common block with parameter values for the pH model 
!==========================================================================

      SUBROUTINE initphdia (pHparms)

      USE dimphdia
      USE modulephdia
      
      IMPLICIT NONE
      
!......................... declaration section.............................
      EXTERNAL         :: pHparms
      DOUBLE PRECISION :: parms(nparms)
      COMMON /cbfemsdiapar/parms
!............................ statements ..................................

        CALL pHparms(nparms, parms)
        CALL init_tran_por()

        InitialisedPH = .FALSE.
        DynamicpH     = .TRUE.
        
      RETURN
      END SUBROUTINE initphdia

! Note: Initialise the forcing function common block 
! is done in the main program same as initfemsforc

!==========================================================================
!==========================================================================
! subroutine calculating the rate of change of
! the DYNAMIC pH model - here the quantities in the common blocks are named
!==========================================================================
!==========================================================================

      SUBROUTINE pHdiamod (neq, t, Conc, dConc, yout, ip)
      
      USE modulefemsdia
      USE modulephdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      INTEGER           :: neq, ip(*), i
      DOUBLE PRECISION  :: t, Conc(26*N), dConc(26*N), yout(*)
!............................ statements ..................................

! --------------------------------------------------------------------------
!     check memory allocated to output variables and initialise pH
! --------------------------------------------------------------------------
       IF (.NOT. InitialisedPH) THEN 
       
         IF (ip(1) < noutdia + noutph + nforcs) THEN
           CALL rexit("nout too small")
         END IF
         InitialisedPH = .TRUE.
         pH(:) = 8.D0  ! initial guess of the pH
       
       END IF

! --------------------------------------------------------------------------
! from Conc to fdet, sdet, o2,...
! --------------------------------------------------------------------------
       DO I = 1, N
         Fdet(I) = Conc(     I)
         Sdet(I) = Conc(   N+I)
         Rdet(I) = Conc(2* N+I)
         O2(I)   = Conc(3 *N+I)
         NO3(I)  = Conc(4 *N+I)
         NO2(I)  = Conc(5 *N+I)
         NH3(I)  = Conc(6 *N+I)
         Mn(I)   = Conc(7 *N+I)  
         MnO2(I) = Conc(8 *N+I)  
         Fe(I)   = Conc(9 *N+I)
         FeOH3(I)= Conc(10*N+I)
         H2S(I)  = Conc(11*N+I)
         SO4(I)  = Conc(12*N+I)
         CH4(I)  = Conc(13*N+I)
         PO4(I)  = Conc(14*N+I)
         FeP(I)  = Conc(15*N+I)
         CaP(I)  = Conc(16*N+I)
         Pads(I) = Conc(17*N+I)
         FeS(I)  = Conc(18*N+I)  
         FeS2(I) = Conc(19*N+I)  
         S0(I)   = Conc(20*N+I)  
         DIC(I)  = Conc(21*N+I)
         ALK(I)  = Conc(22*N+I)
         CALC(I) = Conc(23*N+I)
         ARAG(I) = Conc(24*N+I)
         Ca(I)   = Conc(25*N+I)
       END DO

! --------------------------------------------------------------------------
! Set forcing functions (Temperature, a vector)
       Temperature    = Twater
       intTemp(1)     = Temperature(1)
       intTemp(2:N+1) = Temperature
      
! --------------------------------------------------------------------------
! Transport
! --------------------------------------------------------------------------
       FDETFLux = Carbonflux * pFast
       SDETflux = Carbonflux - FDETflux

       CALL FEMSDIAtransolid(FDETFLux, SDETFLux, RDETflux,                      &
     &                      MnO2flux, FeOH3flux, FePflux, CaPflux,              &
     &                      Padsflux, FeSflux,   FeS2flux, S0flux)      

       CALL PHDIAtransolid (CALCFLux, ARAGFLux)

       CALL FEMSDIAtranliquid(bwO2, bwNO3, bwNO2, bwNH3, bwMn, bwFe,            &
     &                      bwH2S, bwSO4, bwCH4, bwPO4)      
       CALL FEMSDIAtranDIC_ALK(bwDIC, bwALK) 
       
       CALL PHDIAtranliquid(bwCa)

! --------------------------------------------------------------------------
! biogeochemistry and MPB dynamics
! --------------------------------------------------------------------------
       CALL FEMSDIAbiochem 
       CALL MPBFEMSDIAsimple 
       CALL PHDIAbiochem 

! --------------------------------------------------------------------------
! output
! --------------------------------------------------------------------------
       CALL MPBFEMSDIAsimpleout
       CALL femsdiaout     
       CALL getoutFES(yout)  ! output in one long vector
       CALL PHDIAout (yout, Noutdia + Nforcsdia)

! --------------------------------------------------------------------------
! from dfdet, dsdet, drdet, do2,... to dconc
! --------------------------------------------------------------------------
       DO I = 1, N
         dConc(     I) =  dFdet(I)
         dConc(   N+I) =  dSdet(I) 
         dConc(2 *N+I) =  dRdet(I) 
         dConc(3 *N+I) =  dO2(I)  
         dConc(4 *N+I) =  dNO3(I) 
         dConc(5 *N+I) =  dNO2(I) 
         dConc(6 *N+I) =  dNH3(I) 
         dConc(7 *N+I) =  dMn(I)     
         dConc(8 *N+I) =  dMnO2(I)   
         dConc(9 *N+I) =  dFe(I)
         dConc(10*N+I) =  dFeOH3(I)
         dConc(11*N+I) =  dH2S(I)
         dConc(12*N+I) =  dSO4(I)
         dConc(13*N+I) =  dCH4(I)
         dConc(14*N+I) =  dPO4(I)
         dConc(15*N+I) =  dFeP(I)
         dConc(16*N+I) =  dCaP(I)
         dConc(17*N+I) =  dPADS(I)
         dConc(18*N+I) =  dFeS(I)    
         dConc(19*N+I) =  dFeS2(I)   
         dConc(20*N+I) =  dS0(I)     
         dConc(21*N+I) =  dDIC(I)
         dConc(22*N+I) =  dALK(I)
         dConc(23*N+I) =  dCalc(I)
         dConc(24*N+I) =  dArag(I)
         dConc(25*N+I) =  dCa(I)
      
       END DO
       
      RETURN
      END SUBROUTINE pHdiamod

!==========================================================================
!==========================================================================
! STEADY-STATE PH subroutines
!==========================================================================
!==========================================================================

!==========================================================================
! initialise the forcing variables for the
! *STEADY-STATE* solution of the model
!==========================================================================

      SUBROUTINE setpHforcvars(rpar, ipar)

      USE modulefemsdia, only: N, NO3, NO2, NH3, PO4, H2S, SO4,                 &
    &                          temperature, DICprod, ALKprod, Dwater

      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION  :: rpar(*)
      INTEGER           :: ipar(*)
      INTEGER           :: I, ir
!............................ statements ..................................
      
      ir   = ipar(1)
      
      DO I = 1, N
        NO3(I)           = rpar(ir + 0*N + I)
        NO2(I)           = rpar(ir + 1*N + I)
        NH3(I)           = rpar(ir + 2*N + I)
        H2S(I)           = rpar(ir + 3*N + I)
        SO4(I)           = rpar(ir + 4*N + I)
        PO4(I)           = rpar(ir + 5*N + I)
        temperature(I)   = rpar(ir + 6*N + I) 
        DICprod(I)       = rpar(ir + 7*N + I) 
        ALKprod(I)       = rpar(ir + 8*N + I) 
      END DO
      
      END SUBROUTINE setpHforcvars
      
!==========================================================================
!==========================================================================
! subroutine calculating the rate of change of
! the STEADY-STATE pH model
!==========================================================================
!==========================================================================

      SUBROUTINE pHsteady (neq, t, Conc, dConc, yout, ip)
      
      USE modulefemsdia
      USE modulephdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      INTEGER           :: neq, ip(*) 
      DOUBLE PRECISION  :: t, Conc(5*N), dConc(5*N), yout(*)
      
      INTEGER           :: i
!............................ statements ..................................

! --------------------------------------------------------------------------
!     check memory allocated to output variables and initialise pH
! --------------------------------------------------------------------------
       IF (.NOT. InitialisedPH) THEN 
         IF (ip(1) < noutph) THEN
           CALL rexit("nout too small")
         END IF
         
         CALL setpHforcvars(yout, ip)
       
         InitialisedPH = .TRUE.
         pH(:) = 8.D0  ! initial guess of the pH
       
       END IF

! --------------------------------------------------------------------------
! from Conc to DIC, ALK,...
! --------------------------------------------------------------------------
       DO I = 1, N
         DIC(I)  = Conc(0*N + I)
         ALK(I)  = Conc(1*N + I)
         CALC(I) = Conc(2*N + I)
         ARAG(I) = Conc(3*N + I)
         Ca(I)   = Conc(4*N + I)
       END DO

! --------------------------------------------------------------------------
! Transport
! --------------------------------------------------------------------------

       CALL PHDIAtransolid (CALCFLux, ARAGFLux)

       CALL FEMSDIAtranDIC_ALK(bwDIC, bwALK) 
       
       CALL PHDIAtranliquid   (bwCa)

! --------------------------------------------------------------------------
! biogeochemistry and pH dynamics
! --------------------------------------------------------------------------

       dDIC  = dDIC    + DICprod  ! DICy production not due to CaCO3
       dALK  = dALK    + ALKprod  ! alkalinity production not due to CaCO3
       
       CALL PHDIAbiochem 

! --------------------------------------------------------------------------
! output
! --------------------------------------------------------------------------

       CALL PHDIAsteadyout (yout, 0)

! --------------------------------------------------------------------------
! from dDIC, dALK, ... to dconc
! --------------------------------------------------------------------------
       DO I = 1, N
         dConc(0*N + I) =  dDIC(I)
         dConc(1*N + I) =  dALK(I)
         dConc(2*N + I) =  dCalc(I)
         dConc(3*N + I) =  dArag(I)
         dConc(4*N + I) =  dCa(I)
      
       END DO
       
      RETURN
      END SUBROUTINE pHsteady

!==============================================================================
! Transport of PH-related solid substances
!==============================================================================

      SUBROUTINE PHDIAtransolid(CALCdepo, ARAGdepo)

      USE modulefemsdia
      USE modulephdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION :: CALCdepo, ARAGdepo
      DOUBLE PRECISION :: Db(N+1)      
!............................ statements ..................................
      
! --------------------------------------------------------------------------
! Rate of change due to transport for calcite and aragonite
! --------------------------------------------------------------------------
        Db   = Db0   * biotfac   ! Bioturbation profile

        CALL transolid (N,  CALC,   CALCdepo,  0.d0,                            &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dCALC)
        CALCdeepflux  = Flux(N+1)

! ----------------------
        CALL transolid (N, ARAG,  ARAGdepo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dARAG)
        ARAGdeepflux  = Flux(N+1)

      RETURN
      END SUBROUTINE PHDIAtransolid
      
!==============================================================================
! Transport of pH-related liquid substances
!==============================================================================

      SUBROUTINE pHDIATranliquid(Cabw)

      USE modulefemsdia
      USE modulephdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION :: Cabw
      
      DOUBLE PRECISION :: Dirr(N)
      DOUBLE PRECISION :: DS(N+1), irrf, DBW
!............................ statements ..................................

! ----------------------------------------------------------------------------
! transport parameters
! ----------------------------------------------------------------------------
! irrigation profile
        Dirr = Dirr0 * irrfac

! liquid flow = sum of sediment accretion and porewater flow        
        v_liquid = w + flow/intpor
        
! ----------------------------------------------------------------------------
! transport of Ca++ 
! if gasflux > 0: dry flat and no exchange
        BCup  = BCupCa
        if (gasflux > 0) BCup = 5

        Ds  = (a_dispCa + b_dispCa * intTemp)*porfac 
        DBW = Ds(1) / porfac(1)  
        
        CALL tranliquid (N, Ca, Cabw, dwCa, 0.d0,    0.d0, DBL,                 &
     &     BCup   ,  BCdwnCa, v_liquid, Ds, DBW, Dirr, Aint,                    &
     &     intpor, por, dx, dxint, Flux, dCa, irrf)
        
        Caflux     = Flux(1) + irrf
        Cadeepflux = Flux(N+1)

      RETURN
      END SUBROUTINE phdiatranliquid

!==============================================================================
! pH biogeochemistry
!==============================================================================

      SUBROUTINE PHDIABiochem
      
      USE modulefemsdia
      USE modulephdia
      
      IMPLICIT NONE
      
!......................... declaration section.............................
      INTEGER :: I
      DOUBLE PRECISION :: depth, dens, tmol, omega_lim 
      DOUBLE PRECISION :: ksCa, pow, solid_lim
      DOUBLE PRECISION :: liqfac, solfac
!............................ statements ..................................

! --------------------------------------------------------------------------
! estimate pH based on temperature, salinity, density, depth, 
! alkalinity, lumpsum of species.
! --------------------------------------------------------------------------

       depth = Hwater            ! depth of water column
       dens  = Dwater            ! density of water
       tmol  = 1.d0/dens/1000d0  ! convert from mmol/m3 to mol/kg

       ! 2.7e7mmol/m3 = 100% CaCO3 -> convert to mmol/cm3 (smaller number for power)
       ! high CaCO3 concentration, -> slows down carbonate prod. 
       ! At 50% of solid fraction, precipitation rate = 50% of maximum  
       
       ksCa = 27.d0 / 2.d0  ! in mmol/cm3
       pow  = 5.d0
       
       DO I = 1, N
       
         CALL EstimatePH_one (temperature(I), Swater, depth,                    &
     &                    ALK(I)*tmol, DIC(I)*tmol, PO4(I)*tmol,                &
     &                    NH3(I)*tmol, H2S(I)*tmol, SO4(I)*tmol,                &
     &                    100, pH(I), Ks)
       
! --------------------------------------------------------------------------
! carbonate speciation 
! --------------------------------------------------------------------------
! CO3 concentration

         CALL CalcCO3(10d0**(-pH(I)), DIC(I), CO3(I))

! --------------------------------------------------------------------------
! solubility product for calcite and aragonite
! --------------------------------------------------------------------------
         omegaCa(I) = (Ca(I) * tmol) * (CO3(I) * tmol) /Ks(15)
         omegaAr(I) = (Ca(I) * tmol) * (CO3(I) * tmol) /Ks(16)

! --------------------------------------------------------------------------
! dissolution (calcite and aragonite) and precipitation (calcite)
! --------------------------------------------------------------------------

         IF (omegaCa(I) < 1.D0) THEN   ! will be > 0
            omega_lim   = max(0.d0, min(1.d0 , (1.d0 - omegaCa(I)) **pCa)) 
            CALCdiss(I) = rCALCdiss * omega_lim * CALC(I)
             
            CALCprod(I) = 0.D0
            
         ELSE                          ! omegaCa > 1
            CALCdiss(I) = 0.D0
             
            ! Factor to ensure that not too much CaCO3 is produced
            solid_lim   = ksCa**pow / (ksCa**pow + (CALC(I)*1e-6)**pow)
            omega_lim   = max(0.d0, min(1.d0, (omegaCa(I) - 1.d0) **pCa))

            CALCprod(I) = rCALCprod * omega_lim * solid_lim * Ca(I) * CO3(I)
             
         END IF

         IF (omegaAr(I) < 1.D0) THEN

             omega_lim    = max(0.d0, min(1.d0 , (1.d0 - omegaAr(I)) **pAr)) 
             ARAGdiss(I)  = rARAGdiss * omega_lim * ARAG(I)
           
         ELSE
             ARAGdiss(I)  = 0.D0
           
         END IF

       END DO
       
! --------------------------------------------------------------------------
! Update the rate of change  
! --------------------------------------------------------------------------
      
       dCALC   = dCALC                                                          &
     &         + CALCprod * por/(1.d0-por)                                      &
     &         - CALCdiss
     
       dARAG   = dARAG                                                          &
     &         - ARAGdiss
       
       dDIC   = dDIC                                                            &
     &        - CALCprod                                                        &
     &        + (CALCdiss + ARAGdiss) * (1.d0-por)/por
     
       dALK   = dALK                                                            &
     &        - 2.D0 * CALCprod                                                 &
     &        + 2.D0 * (CALCdiss + ARAGdiss)*(1.d0-por)/por

       dCa    = dCa                                                             &
     &        -  CALCprod                                                       &
     &        + (CALCdiss + ARAGdiss)*(1.d0-por)/por

! integrated rates
       TotCALCdiss   = 0.d0
       TotARAGdiss   = 0.d0
       TotCALCprod   = 0.d0
       TotalCALC     = 0.d0
       TotalARAG     = 0.d0
       TotalCa       = 0.d0
       
       DO I = 1, N
         liqfac        = por(I)       * dx(I) ! from /m3 liquid -> m2 bulk
         solfac        = (1.d0-por(I))* dx(I) ! from /m3 solid  -> m2 bulk
         
         TotCALCdiss = TotCALCdiss  + CALCdiss(I)  * solfac 
         TotARAGdiss = TotARAGdiss  + ARAGdiss(I)  * solfac
         TotCALCprod = TotCALCprod  + CALCprod(I)  * liqfac
         TotalCALC   = TotalCALC    + CALC(I)      * solfac 
         TotalARAG   = TotalARAG    + ARAG(I)      * solfac 
         TotalCa     = TotalCa      + Ca(I)        * liqfac
         
       END DO
       
      RETURN 
      END SUBROUTINE PHDIABiochem  

!==========================================================================
! put output variables in one vector
!==========================================================================
       
      SUBROUTINE PHDIAout(yout, ii)
      
      USE dimfemsdia
      USE dimphdia
      
      IMPLICIT NONE
      
!......................... declaration section.............................
      DOUBLE PRECISION :: yout(*), outPH(noutpH), forc(nforcs) 
      
      INTEGER :: i, ii

      COMMON /myoutPH      /outPH
      COMMON /cbfemsdiaforc/forc
!............................ statements ..................................

      DO i = 1, NoutPH
        yout(ii + i) = outPH(i)
      END DO
      
      DO i = 1, NforcsPH
        yout(ii + NoutpH + i) = forc (nforcsdia + i)
      END DO
      
      RETURN
      END SUBROUTINE PHDIAout

       
      SUBROUTINE PHDIAsteadyout(yout, ii)
      
      USE dimfemsdia
      USE dimphdia
      
      IMPLICIT NONE
      
!......................... declaration section.............................
      DOUBLE PRECISION :: yout(*), outPH(noutpH)
      
      INTEGER :: i, ii

      COMMON /myoutPH      /outPH
!............................ statements ..................................

      DO i = 1, NoutPH
        yout(ii + i) = outPH(i)
      END DO
      
      RETURN
      END SUBROUTINE PHDIAsteadyout


! Alkalinity is defined as:
! HCO3 +2*CO3 + BOH4 + OH + HPO4 + 2*PO4 + SiOOH3 
! + HS + 2*S2min + NH3 - H - HSO4 - HF - H3PO4
!
! BOH4, HF, SiOOH3 are assumed to have zero gradient (and transport)

! thus transport should be solved for 
! HCO3, CO3, OH, HPO4, PO4, H3PO4, HS, S2min, NH3, H, HSO4

