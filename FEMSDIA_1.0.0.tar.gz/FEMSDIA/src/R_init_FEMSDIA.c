#ifndef R_R_H
# include <R.h>
#endif

#ifndef R_EXT_DYNLOAD_H_
# include <R_ext/Rdynload.h>
#endif


#include <Rinternals.h>
#include <stdlib.h> // for NULL

/* register native routines ------------------------------------------------ */


/* NO .C calls */
/* NO .Call calls */
 
/* .Fortran calls */
void F77_NAME(initfemsdia)  (void (* steadyparms)(int *, double *));
void F77_NAME(initphdia)    (void (* steadyparms)(int *, double *));
void F77_NAME(initfemsforc) (void (* steadyforcs)(int *, double *));

void F77_NAME(femsdiamod)  (int *, double *, double *, double *, double *, int *);
void F77_NAME(femsdiamodbw)(int *, double *, double *, double *, double *, int *);
void F77_NAME(phdiamod)    (int *, double *, double *, double *, double *, int *);

//void F77_NAME(initmpbdia)  (void (* steadyparms)(int *, double *));
//void F77_NAME(mpbdiamod)  (int *, double *, double *, double *, double *, int *);
//void F77_NAME(mpbdiamodbw)(int *, double *, double *, double *, double *, int *);
 
R_FortranMethodDef FEntries[] = {
    {"initfemsdia",     (DL_FUNC) &F77_SUB(initfemsdia),     1},
    {"initphdia",       (DL_FUNC) &F77_SUB(initphdia),       1},
    {"initfemsforc",    (DL_FUNC) &F77_SUB(initfemsforc),    1},
    {"femsdiamod",      (DL_FUNC) &F77_SUB(femsdiamod),      6},
    {"phdiamod",        (DL_FUNC) &F77_SUB(phdiamod),        6},
    {"femsdiamodbw",    (DL_FUNC) &F77_SUB(femsdiamodbw),    6},
//    {"initmpbdia",     (DL_FUNC) &F77_SUB(initmpbdia),     1},
//    {"mpbdiamod",      (DL_FUNC) &F77_SUB(mpbdiamod),      6},
//    {"mpbdiamodbw",    (DL_FUNC) &F77_SUB(mpbdiamodbw),    6},
    {NULL, NULL, 0}
};

/* Initialization ---------------------------------------------------------- */
void R_init_CNPDIA(DllInfo *dll) {

  R_registerRoutines(dll, NULL, NULL, FEntries, NULL);

  // the following line protects against accidentially finding entry points

  R_useDynamicSymbols(dll, FALSE); // disable dynamic searching
}
