!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! transport
!
! Karline Soetaert, nioz-yerseke
!==========================================================================

!==============================================================================
! Transport of solid substances
!==============================================================================

      SUBROUTINE FEMSDIAtransolid(FDETdepo, SDETdepo, RDETdepo,                 &
     &                           MnO2depo, FeOH3depo, FePdepo, CaPdepo,         &
     &                           Padsdepo, FeSdepo, FeS2depo, S0depo) 
     
      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION :: FDETdepo, SDETdepo, RDETdepo,                         &
     &                    MnO2depo, FeOH3depo, FePdepo, CaPdepo,                &
     &                    Padsdepo, FeSdepo, FeS2depo, S0depo
      
      DOUBLE PRECISION :: Db(N+1)      
!............................ statements ..................................
      
! --------------------------------------------------------------------------
! Rate of change due to transport 
! --------------------------------------------------------------------------
        Db   = Db0 * biotfac  ! Bioturbation profile

        CALL transolid (N, FDET,  FDETdepo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dFDET)
        FDETdeepflux  = Flux(N+1)
! ----------------------
        CALL transolid (N, SDET,  SDETdepo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dSDET)
        SDETdeepflux  = Flux(N+1)
! ----------------------
        CALL transolid (N, RDET,  RDETdepo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dRDET)
        RDETdeepflux  = Flux(N+1)
! ----------------------
        MnO2surfflux  = MnO2depo                                                   
        CALL transolid (N, MnO2,  MnO2depo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dMnO2)
        MnO2deepflux  = Flux(N+1)        
! ----------------------        
        FeOH3surfflux = FeOH3depo
        CALL transolid (N, FeOH3, FeOH3depo, 0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dFeOH3)
        FeOH3deepflux = Flux(N+1)
! ----------------------        
        FePsurfflux   = FePdepo
        CALL transolid (N, FeP,   FePdepo,   0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dFeP)
        FePdeepflux   = Flux(N+1)
! ----------------------
        CaPsurfflux   = CaPdepo
        CALL transolid (N, CaP,   CaPdepo,   0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dCaP)
        CaPdeepflux   = Flux(N+1)
! ----------------------
        CALL transolid (N, Pads,  Padsdepo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dPads)
!        Padsdeepflux = Flux(N+1)
! ----------------------
        FeSsurfflux   = FeSdepo                                                     
        CALL transolid (N, FeS,   FeSdepo,   0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dFeS)
        FeSdeepflux   = Flux(N+1)
! ----------------------
        FeS2surfflux  = FeS2depo                                                   
        CALL transolid (N, FeS2,  FeS2depo,  0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dFeS2)
        FeS2deepflux  = Flux(N+1)
! ----------------------        
        S0surfflux    = S0depo                                                       
        CALL transolid (N, S0,    S0depo,    0.d0,                              &
     &                  1, 3, w, Db, Aint, 1.d0-intpor, 1.d0 - por,             &
     &                  dx, dxint, Flux, dS0)
        S0deepflux    = Flux(N+1)
      
      RETURN
      END SUBROUTINE FEMSDIAtransolid

!==============================================================================
! Transport of liquid substances - DIC and Alkalinity
!==============================================================================

      SUBROUTINE FEMSDIAtranDIC_ALK(DICbw, ALKbw) 
      
      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION :: DICbw, ALKbw
     
      DOUBLE PRECISION :: Dirr(N)
      DOUBLE PRECISION :: irrf, DS(N+1), DBW
!............................ statements ..................................

! ----------------------------------------------------------------------------
! transport parameters
! ----------------------------------------------------------------------------
! irrigation profile
        Dirr = Dirr0 * irrfac

! liquid flow = sum of sediment accretion and porewater flow        
        v_liquid = w + flow/intpor
        
! ----------------------------------------------------------------------------
! transport of DIC depends on gasflux; 
! if gasflux > 0: dry flat and piston-like exchange

        Ds = (a_dispDIC + b_dispDIC * intTemp) * porfac  
        DBW = Ds(1) / porfac(1)  
        
        BCup = BCupDIC
        if (gasflux > 0) BCup = 4
        
        CALL tranliquid (N, DIC, DICbw, dwDIC, gasflux, 0.d0, DBL,              &
     &     BCup,     BCdwnDIC, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dDIC, irrf)
        
        DICflux     = Flux(1) + irrf
        DICdeepflux = Flux(N+1)

! ----------------------
        Ds  = (a_dispAlk + b_dispAlk * intTemp)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupAlk
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, Alk, ALKbw, dwAlk, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnAlk, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por,dx, dxint, Flux, dAlk, irrf)
        
        Alkflux     = Flux(1) + irrf
        Alkdeepflux = Flux(N+1)
        
      RETURN
      END SUBROUTINE FEMSDIAtranDIC_ALK
       
!==============================================================================
! Transport of liquid substances - all except DIC and ALK
!==============================================================================

      SUBROUTINE FEMSDIAtranliquid(O2BW, NO3bw, NO2bw, NH3bw, Mnbw,             &
     &                Febw, H2Sbw, SO4bw, CH4bw, PO4bw)
     
      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION :: O2BW, NO3bw, NO2bw, NH3bw, Mnbw, Febw,                &
     &                    H2Sbw, SO4bw, CH4bw, PO4bw
     
      DOUBLE PRECISION :: Dirr(N)
      DOUBLE PRECISION :: irrf, DS(N+1), DBW
!............................ statements ..................................

! ----------------------------------------------------------------------------
! transport parameters
! ----------------------------------------------------------------------------
! irrigation profile
        Dirr = Dirr0 * irrfac

! liquid flow = sum of sediment accretion and porewater flow        
        v_liquid = w + flow/intpor
        
! ----------------------------------------------------------------------------
! transport of O2 depends on gasflux; 
! if gasflux > 0: dry flat and piston-like exchange

        Ds  = (a_dispO2 + b_dispO2 * intTemp) * porfac  
        DBW = Ds(1) / porfac(1)     ! bottom water diffusion
        
        BCup = BCupO2
        if (gasflux > 0) BCup = 4
        
        CALL tranliquid (N, O2,  O2bw,  dwO2,  gasflux, 0.d0, DBL,              &
     &     BCup  ,  BCdwnO2, v_liquid, Ds, DBW, Dirr, Aint,                     &
     &     intpor, por, dx, dxint, Flux, dO2, irrf)
        
        O2flux      = Flux(1) + irrf
        O2deepflux  = Flux(N+1)
                        
! ----------------------
        Ds = (a_dispCH4 + b_dispCH4 * intTemp)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup = BCupCH4
        if (gasflux > 0) BCup = 4
        
        CALL tranliquid (N, CH4, CH4bw, dwCH4, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnCH4, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dCH4, irrf)
        
        CH4flux     = Flux(1) + irrf
        CH4deepflux = Flux(N+1)

! Other substances: if dry flat: zero-flux
! ----------------------
        BCup  = BCupNO3
        if (gasflux > 0) BCup = 5

        Ds  = (a_dispNO3 + b_dispNO3 * intTemp)*porfac 
        DBW = Ds(1) / porfac(1)  
        
        CALL tranliquid (N, NO3, NO3bw, dwNO3, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnNO3, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dNO3, irrf)
        
        NO3flux     = Flux(1) + irrf
        NO3deepflux = Flux(N+1)

! ----------------------
        Ds  = (a_dispNO2 + b_dispNO2 * intTemp)*porfac 
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupNO2
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, NO2, NO2bw, dwNO2, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnNO2, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dNO2, irrf)
        NO2flux     = Flux(1) + irrf
        NO2deepflux = Flux(N+1)

! ----------------------
        Ds = (a_dispNH3 + b_dispNH3 * intTemp)/(1.d0+NH3Ads)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupNH3
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, NH3, NH3bw, dwNH3, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnNH3, v_liquid, Ds, DBW, Dirr/ (1.d0+NH3Ads),          &
     &     Aint, intpor, por, dx, dxint, Flux, dNH3, irrf)
        
        NH3flux     = (Flux(1)+ irrf)*(1.d0+NH3Ads) 
        NH3deepflux = Flux(N+1)*(1.d0+NH3Ads)

! ----------------------
        Ds  = (a_dispPO4 + b_dispPO4 * intTemp)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupPO4
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, PO4, PO4bw, dwPO4, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnPO4, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dPO4, irrf)
        
        PO4flux     = Flux(1) + irrf
        PO4deepflux = Flux(N+1)
                
! ----------------------
        Ds  = (a_dispMn  + b_dispMn  * intTemp)*porfac   
        DBW = Ds(1) / porfac(1)  

        BCup  = BCupMn
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, Mn,  Mnbw,  dwMn,  0.d0,    0.d0, DBL,              &
     &     BCup  ,  BCdwnMn, v_liquid, Ds, DBW, Dirr, Aint,                     &
     &     intpor, por, dx, dxint, Flux, dMn, irrf)

        Mnflux     = Flux(1) + irrf
        Mndeepflux = Flux(N+1)

! ----------------------
        Ds  = (a_dispFe + b_dispFe * intTemp)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupFe
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, Fe,  Febw , dwFe , 0.d0,    0.d0, DBL,              &
     &     BCup  ,  BCdwnFe, v_liquid, Ds, DBW, Dirr, Aint,                     &
     &     intpor, por, dx, dxint, Flux, dFe, irrf)
        Feflux     = Flux(1) + irrf
        Fedeepflux = Flux(N+1)

! ----------------------
        Ds  = (a_dispH2S + b_dispH2S * intTemp)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupH2S
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, H2S, H2Sbw, dwH2S, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnH2S, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dH2S, irrf)
        
        H2Sflux     = Flux(1) + irrf
        H2Sdeepflux = Flux(N+1)

! ----------------------
        Ds  = (a_dispSO4 + b_dispSO4 * intTemp)*porfac
        DBW = Ds(1) / porfac(1)  
        
        BCup  = BCupSO4
        if (gasflux > 0) BCup = 5
        
        CALL tranliquid (N, SO4, SO4bw, dwSO4, 0.d0,    0.d0, DBL,              &
     &     BCup   ,  BCdwnSO4, v_liquid, Ds, DBW, Dirr, Aint,                   &
     &     intpor, por, dx, dxint, Flux, dSO4, irrf)
        
        SO4flux     = Flux(1) + irrf
        SO4deepflux = Flux(N+1)

      RETURN
      END SUBROUTINE FEMSDIAtranliquid

!==============================================================================
! Transport in a 1-dimensional finite difference grid - liquid
! all inputs are vectors
! subroutine from ReacTran in isnt\doc\fortran directory
!==============================================================================

      SUBROUTINE tranliquid (N, C, Cup, Cdown, aup, adown,                      &
     &                   DBL, BcUp, BcDown,                                     &
     &                   v, D, D_BW, Dirr, Aint, VF, VFmid,                     &
     &                   dx, dxaux,                                             &
     &                   Flux, dC, irrf)
      
      IMPLICIT NONE

!......................... declaration section.............................
! input
      INTEGER N                  ! length of C

      ! concentration to transport
      DOUBLE PRECISION C(N)      

      ! boundary concentrations (used if Bc.. = 2,4), or fluxes (if Bc= 1)
      DOUBLE PRECISION Cup, Cdown     ! concentration or flux

      ! convection coefficients (used if Bc=4) 
      DOUBLE PRECISION aup, adown

      ! size of the diffusive boundary layer (DBL)
      DOUBLE PRECISION DBL        ! m

      ! diffusion coefficient in the DBL
      DOUBLE PRECISION D_BW       ! m2/d

      ! sediment diffusion coefficient, corrected for tortuosity 
      DOUBLE PRECISION D(N+1)     ! m2/d

      ! irrigation rate
      DOUBLE PRECISION Dirr(N)    ! /d

      ! surface area at interface - usually 1
      DOUBLE PRECISION Aint(N+1)  ! m

      ! volume fraction at interface and in middle (porosity)
      DOUBLE PRECISION VF(N+1), VFmid(N)  ! -

      ! advection rate (accretion plus porewater flow)  
      DOUBLE PRECISION v(N+1)     ! m/d

      ! grid size, distance from mid to mid
      DOUBLE PRECISION dx(N), dxaux(N+1)  ! m

      ! boundary concitions (1 = flux, 2 = conc, 3 = 0-grad, 4 = convective)
      INTEGER BcUp, BcDown

! output
      ! fluxes at interface
      DOUBLE PRECISION Flux(N+1)   ! mmol/m2/d

      ! rate of change 
      DOUBLE PRECISION dC(N)       ! mmol/m3/d

      ! integrated irrigation flux
      DOUBLE PRECISION irrf        ! mmol/m2/d

! locals
      INTEGER I
      DOUBLE PRECISION Amid, irrigation, Cbnd, BW_up
!............................ statements ..................................

! Flux - first internal cells

       
       DO I = 2, N
         IF (v(I) >= 0) THEN
           Flux(I) = - VF(I) * D(I) * (C(I)-C(I-1)) /dxaux(I)                   &
     &               + VF(I) * v(I) * C(I-1)
         ELSE
           Flux(I) = - VF(I) * D(I) * (C(I)-C(I-1)) /dxaux(I)                   &
     &               + VF(I) * v(I) *  C(I)

         END IF
       END DO
      
! Then the outer cells
! upstream boundary
      
      IF (v(1) >= 0) THEN
        Cbnd = Cup
      
      ELSE
        Cbnd = C(1)
      
      END IF
      
      IF (BcUp .EQ. 1) THEN         ! Flux boundary
        Flux(1) = Cup

      ELSE IF (BcUp .EQ. 2) THEN    ! concentration boundary

! Estimate concentration at sediment-water interface, in case DBL > 0
! O2_0 = (O2BW * D/DBL + O2(1) * Dstar * por_0 / dx_int_0) / 
!        (Dstar * por_0 / dx_int_0 + D/DBL + w*por_0)
      
        IF (DBL > 0.D0) THEN
          BW_up = (Cup * D_BW/DBL + C(1)*D(1)*VF(1) / dxaux(1)) /               &
                  (D(1) * VF(1) / dxaux(1) + D_BW/DBL + v(1)*VF(1))
        ELSE
          BW_up = Cup 
        
        END IF
        
        IF (v(1) >= 0) THEN
          Cbnd = BW_up
        
        END IF
        
        Flux(1) = - VF(1) * D(1) * (C(1)-BW_up) /dxaux(1)                       &
     &            + VF(1) * v(1) * Cbnd

      ELSE IF (BcUp .EQ. 3) THEN
        Flux(1) = VF(1) * v(1) * Cbnd

      ELSE IF (BcUp .EQ. 4) THEN
        Flux(1) = aup * (Cup - C(1))
      ELSE
      
        Flux(1) = 0.d0
      END IF


! downstream boundary
      IF (v(N+1) >= 0 .OR. BcDown .eq. 3) THEN
        Cbnd = C(N)
      ELSE
        Cbnd = Cdown
      END IF

      IF (BcDown .EQ. 1) THEN
        Flux(N+1) = Cdown

      ELSE IF (BcDown .EQ. 2) THEN
        Flux(N+1) = - VF(N+1) * D(N+1) * (Cdown-C(N)) /dxaux(N+1)               &
     &              + VF(N+1) * v(N+1) * Cbnd

      ELSE IF (BcDown .EQ. 3) THEN
        Flux(N+1) = VF(N+1) * v(N+1) * Cbnd

      ELSE IF (BcDown .EQ. 3) THEN
        Flux(N+1) = -adown * (Cdown-C(N))

      ELSE
        Flux(N+1) = 0.d0
      END IF

! Rate of change = negative flux gradient
      DO I = 1, N
        Amid  = 0.5 * (Aint(I)+Aint(I+1))
        dC(I) = -(Aint(I+1)*Flux(I+1) - Aint(I)*Flux(I))/                       &
     &            Amid / VFmid(I) / dx(I)
      END DO

! bioirrigation
      irrf = 0.d0
      IF (sum(Dirr) > 0) THEN
        DO I = 1, N
          irrigation = Dirr(I)*(Cup - C(I)) 
          irrf       = irrf + Irrigation*dx(I)*VFmid(I)
          dC(I)      = dC(I) + irrigation
        END DO
      END IF

      RETURN
      END SUBROUTINE tranliquid

!==============================================================================
! Solid phase transport in a 1-dimensional finite difference grid
! all inputs are vectors
!==============================================================================

      SUBROUTINE transolid (N, C, Cup, Cdown,                                   &
     &                      BcUp, BcDown,                                       &
     &                      v, D, Aint, VF, VFmid,                              &
     &                      dx, dxaux,                                          &
     &                      Flux, dC)
      
      IMPLICIT NONE

!......................... declaration section.............................
! input
      INTEGER N                  ! length of C

      ! concentration to transport
      DOUBLE PRECISION C(N)      

      ! boundary concentrations (used if Bc.. = 2,4), or fluxes (if Bc= 1)
      DOUBLE PRECISION Cup, Cdown     ! concentration or flux

      ! sediment bioturbation coefficient
      DOUBLE PRECISION D(N+1)     ! m2/d

      ! surface area at interface - usually 1
      DOUBLE PRECISION Aint(N+1)  ! m

      ! volume fraction at interface and in middle (1-porosity)
      DOUBLE PRECISION VF(N+1), VFmid(N)  ! -

      ! advection rate (sediment accretion)
      DOUBLE PRECISION v          ! m/d

      ! grid size, distance from mid to mid
      DOUBLE PRECISION dx(N), dxaux(N+1)  ! m

      ! boundary concitions (1 = flux, 2 = conc, 3 = 0-grad, 4 = convective)
      INTEGER BcUp, BcDown

! output

      ! fluxes at interface
      DOUBLE PRECISION Flux(N+1)   ! mmol/m2/d

      ! rate of change 
      DOUBLE PRECISION dC(N)       ! mmol/m3/d

! locals
      INTEGER I
      DOUBLE PRECISION Amid, Cbnd
!............................ statements ..................................

! Flux - first internal cells

      IF (v >= 0) THEN
       
       DO I = 2, N
        Flux(I) = -VF(I)*D(I) * (C(I) - C(I-1)) /dxaux(I)                       &
     &           + VF(I)*v*C(I-1)
       END DO

      ELSE
      
       DO I = 2, N
        Flux(I) = -VF(I)*D(I) * (C(I) - C(I-1)) /dxaux(I)                       &
     &           + VF(I)*v*C(I)
       END DO

      END IF
      
! Then the outer cells
! upstream boundary
      
      IF (v >= 0) THEN
        Cbnd = Cup
      
      ELSE
        Cbnd = C(1)
      
      END IF
      
      IF (BcUp .EQ. 1) THEN         ! Flux boundary
        Flux(1) = Cup

      ELSE IF (BcUp .EQ. 2) THEN    ! concentration boundary

        Flux(1) = -VF(1)*D(1) * (C(1) - Cbnd) /dxaux(1)                         &
     &           + VF(1)*v*Cbnd

      ELSE IF (BcUp .EQ. 3) THEN
        Flux(1) = VF(1)*v*Cbnd

      ELSE
      
        Flux(1) = 0.d0
      END IF


! downstream boundary
      IF (v >= 0 .OR. BcDown .eq. 3) THEN
        Cbnd = C(N)
      ELSE
        Cbnd = Cdown
      END IF

      IF (BcDown .EQ. 1) THEN
        Flux(N+1) = Cdown

      ELSE IF (BcDown .EQ. 2) THEN
        Flux(N+1) = -VF(N+1)*D(N+1) * (Cdown - C(N)) /dxaux(N+1)                &
     &              + VF(N+1) * v * Cbnd

      ELSE IF (BcDown .EQ. 3) THEN
        Flux(N+1) = VF(N+1) * v * Cbnd

      ELSE
        Flux(N+1) = 0.d0
      END IF


! Rate of change = negative flux gradient
      DO I = 1, N
        Amid  = 0.5 * (Aint(I)+Aint(I+1))
        dC(I) = -(Aint(I+1)*Flux(I+1) - Aint(I)*Flux(I))/                       &
     &            Amid / VFmid(I) / dx(I)
      END DO

      RETURN
      END SUBROUTINE transolid
