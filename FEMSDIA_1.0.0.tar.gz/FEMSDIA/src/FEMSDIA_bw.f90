!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! version with dynamic water concentrations
!
! Karline Soetaert, nioz-yerseke
!==========================================================================

!==========================================================================
! initialisation = same as FEMSDIAmod - see file FEMSDIA_main.f
!==========================================================================

!==========================================================================
!==========================================================================
! subroutine calculating the rate of change of
! the FEMSDIA model - here the quantities in the common blocks are named
!==========================================================================
!==========================================================================

      SUBROUTINE FEMSDIAmodbw (neq, t, Conc, dConc, yout, ip)
      
      USE modulefemsdia
      USE modulebwfemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      INTEGER           :: neq, ip(*), i
      
      DOUBLE PRECISION :: t, Conc(23*NP1), dConc(23*NP1), yout(*)      
      DOUBLE PRECISION :: FDETdepo, SDETdepo, RDETdepo, FePdepo,                &
     &                    CaPdepo, FeOH3depo 
      DOUBLE PRECISION :: MnO2depo                                              

     ! local declaration for use in FEMSDIA_bw
      DOUBLE PRECISION :: FeS2fall = 0.d0, FeSfall = 0.d0  
      DOUBLE PRECISION :: FeS2depo, FeSdepo 
!............................ statements ..................................

!     check memory allocated to output variables
       IF (ip(1)< noutdia+nforcsdia) THEN
         CALL rexit("nout should be at least nout")
       END IF  

! from Conc to fdet, sdet, o2,...
       DO I = 1, N
        Fdet(I) = Conc(       1 +I)
        Sdet(I) = Conc(   Np1+1 +I)
        Rdet(I) = Conc(2 *Np1+1 +I)
        O2(I)   = Conc(3 *Np1+1 +I)
        NO3(I)  = Conc(4 *Np1+1 +I)
        NO2(I)  = Conc(5 *Np1+1 +I)
        NH3(I)  = Conc(6 *Np1+1 +I)
        Mn(I)   = Conc(7 *Np1+1 +I) 
        MnO2(I) = Conc(8 *Np1+1 +I) 
        Fe(I)   = Conc(9 *Np1+1 +I)
        FeOH3(I)= Conc(10*Np1+1 +I)
        H2S(I)  = Conc(11*Np1+1 +I)
        SO4(I)  = Conc(12*Np1+1 +I)
        CH4(I)  = Conc(13*Np1+1 +I)
        PO4(I)  = Conc(14*Np1+1 +I)
        FeP(I)  = Conc(15*Np1+1 +I)
        CaP(I)  = Conc(16*Np1+1 +I)
        Pads(I) = Conc(17*Np1+1 +I)
        FeS(I)  = Conc(18*Np1+1 +I)  
        FeS2(I) = Conc(19*Np1+1 +I)  
        S0(I)   = Conc(20*Np1+1 +I) 
        DIC(I)  = Conc(21*Np1+1 +I)
        ALK(I)  = Conc(22*Np1+1 +I)

       END DO
       
       Fdetbw = Conc(       1)
       Sdetbw = Conc(   Np1+1)
       Fdetbw = Conc(2* Np1+1)
       O2bw   = Conc(3* Np1+1)
       NO3bw  = Conc(4* Np1+1)
       NO2bw  = Conc(5* Np1+1)
       NH3bw  = Conc(6* Np1+1)
       Mnbw   = Conc(7* Np1+1) 
       MnO2bw = Conc(8* Np1+1) 
       Febw   = Conc(9 *Np1+1)
       FeOH3bw= Conc(10*Np1+1)
       H2Sbw  = Conc(11*Np1+1)
       SO4bw  = Conc(12*Np1+1)
       CH4bw  = Conc(13*Np1+1)
       PO4bw  = Conc(14*Np1+1)
       FePbw  = Conc(15*Np1+1)
       CaPbw  = Conc(16*Np1+1)
       Padsbw = Conc(17*Np1+1)
       FeSbw  = Conc(18*Np1+1) 
       FeS2bw = Conc(19*Np1+1) 
       S0bw   = Conc(20*Np1+1) 
       DICbw  = Conc(21*Np1+1)
       Alkbw  = Conc(22*Np1+1)

! --------------------------------------------------------------------------
       FDETFLux = Carbonflux * pFast
       SDETflux = Carbonflux - FDETflux

       FDETdepo  = FdetBW  * Cfall  ! Cfall = sinking rate of Detritus
       SDETdepo  = SdetBW  * Cfall
       RDETdepo  = RdetBW  * Cfall
       FePdepo   = FePBW   * FePfall
       FeOH3depo = FeOH3BW * FeOH3fall
       CaPdepo   = CaPBW   * CaPfall
       FeSdepo   = FeSBW   * FeSfall    
       FeS2depo  = FeS2BW  * FeS2fall   
       MnO2depo  = MnO2BW  * MnO2fall   

       CALL FEMSDIAtransolid(FDETdepo, SDETdepo, RDETdepo,                      &
      &                      MnO2depo, FeOH3depo, FePdepo, CaPdepo,             &
      &                      0.d0,   0.d0, 0.d0, 0.d0)                  
                        

       if (Hwater > 0) THEN
       
        dFDETBW  = (FDETflux -   FDETdepo)/ Hwater
        dSDETBW  = (SDETflux -   SDETdepo)/ Hwater
        dRDETBW  = (RDETflux -   RDETdepo)/ Hwater
        dMnO2BW  = (MnO2flux -   MnO2depo)/ Hwater  
        dFeOH3BW = (FeOH3flux-  FeOH3depo)/ Hwater
        dFePBW   = (FePflux  -    FePdepo)/ Hwater
        dCaPBW   = (CaPflux  -    CaPdepo)/ Hwater
        dFesBW   = (FeSflux  -    FeSdepo)/ Hwater  
        dFeS2BW  = (FeS2flux -   FeS2depo)/ Hwater  

       ELSE
        
        dFDETBW  = 0.D0
        dSDETBW  = 0.D0
        dRDETBW  = 0.D0
        dFePBW   = 0.D0
        dMnO2BW  = 0.D0   
        dFeOH3BW = 0.D0
        dCaPBW   = 0.D0
        dFeSBW   = 0.d0   
        dFeS2BW  = 0.D0   

       END IF
       
       dPadsBW = 0.D0
       
       CALL FEMSDIAtranliquid(O2bw, NO3bw, NO2bw, NH3bw, Mnbw, Febw,            &
     &                 H2Sbw, SO4bw, CH4bw, PO4bw)        

       CALL FEMSDIAtranDIC_ALK(DICbw, ALKbw) 
       
       IF (Hwater > 0) THEN
        dO2BW   = (bwO2  -  O2BW) * dilution - O2flux  /Hwater
        dNO3BW  = (bwNO3 - NO3BW) * dilution - NO3flux /Hwater
        dNO2BW  = (bwNO2 - NO2BW) * dilution - NO2flux /Hwater
        dNH3BW  = (bwNH3 - NH3BW) * dilution - NH3flux /Hwater
        dCH4BW  = (bwCH4 - CH4BW) * dilution - CH4flux /Hwater
        dPO4BW  = (bwPO4 - PO4BW) * dilution - PO4flux /Hwater
        dMnBW   = (bwMn  - MnBW)  * dilution - Mnflux  /Hwater   
        dFeBW   = (bwFe  - FeBW ) * dilution - Feflux  /Hwater
        dH2SBW  = (bwH2S - H2SBW) * dilution - H2Sflux /Hwater
        dSO4BW  = (bwSO4 - SO4BW) * dilution - SO4flux /Hwater
        dDICBW  = (bwDIC - DICBW) * dilution - DICflux /Hwater
        dALKBW  = (bwALK - ALKBW) * dilution - ALKflux /Hwater
       
       ELSE
        dO2BW   = (bwO2  -  O2BW) * dilution
        dNO3BW  = (bwNO3 - NO3BW) * dilution
        dNO2BW  = (bwNO2 - NO2BW) * dilution
        dNH3BW  = (bwNH3 - NH3BW) * dilution
        dCH4BW  = (bwCH4 - CH4BW) * dilution
        dPO4BW  = (bwPO4 - PO4BW) * dilution
        dMnBW   = (bwMn  - MnBW)  * dilution    
        dFeBW   = (bwFe  - FeBW ) * dilution
        dH2SBW  = (bwH2S - H2SBW) * dilution
        dSO4BW  = (bwSO4 - SO4BW) * dilution
        dDICBW  = (bwDIC - DICBW) * dilution
        dALKBW  = (bwALK - ALKBW) * dilution
       END IF
        
       CALL FEMSDIAbiochem
       CALL MPBFEMSDIAsimple 

! output
       CALL MPBFEMSDIAsimpleout
       CALL FEMSDIAout     
       CALL getoutFES(yout)  ! output in one long vector

! --------------------------------------------------------------------------

! from dfdet, dsdet, do2,... to dconc
       DO I = 1, N
         dConc(       1+I) =  dFdet(I)
         dConc(   NP1+1+I) =  dSdet(I)
         dConc(2 *NP1+1+I) =  dRdet(I)
         dConc(3 *NP1+1+I) =  dO2(I)
         dConc(4 *NP1+1+I) =  dNO3(I)
         dConc(5 *NP1+1+I) =  dNO2(I)
         dConc(6 *NP1+1+I) =  dNH3(I)
         dConc(7 *Np1+1+I) =  dMn(I)    
         dConc(8 *Np1+1+I) =  dMnO2(I)  
         dConc(9 *NP1+1+I) =  dFe(I)
         dConc(10*NP1+1+I) =  dFeOH3(I)
         dConc(11*NP1+1+I) =  dH2S(I)
         dConc(12*NP1+1+I) =  dSO4(I)
         dConc(13*NP1+1+I) =  dCH4(I)
         dConc(14*NP1+1+I) =  dPO4(I)
         dConc(15*NP1+1+I) =  dFeP(I)
         dConc(16*NP1+1+I) =  dCaP(I)
         dConc(17*NP1+1+I) =  dPads(I)
         dConc(18*Np1+1+I) =  dFeS(I)  
         dConc(19*Np1+1+I) =  dFeS2(I) 
         dConc(20*Np1+1+I) =  dS0(I)   
         dConc(21*NP1+1+I) =  dDIC(I)
         dConc(22*NP1+1+I) =  dALK(I)

       END DO 
       dConc(       1) =  dFdetBW
       dConc(   NP1+1) =  dSdetBW
       dConc(2 *NP1+1) =  dRdetBW
       dConc(3 *NP1+1) =  dO2BW
       dConc(4 *NP1+1) =  dNO3BW
       dConc(5 *NP1+1) =  dNO3BW
       dConc(6 *NP1+1) =  dNH3BW
       dConc(7 *Np1+1) =  dMnBW    
       dConc(8 *Np1+1) =  dMnO2BW  
       dConc(9 *NP1+1) =  dFeBW
       dConc(10*Np1+1) =  dFeOH3BW
       dConc(11*NP1+1) =  dH2SBW
       dConc(12*NP1+1) =  dSO4BW
       dConc(13*NP1+1) =  dCH4BW
       dConc(14*NP1+1) =  dPO4BW
       dConc(15*NP1+1) =  dFePBW
       dConc(16*NP1+1) =  dCaPBW
       dConc(17*NP1+1) =  0.d0    !dPads
       dConc(18*Np1+1) =  dFeSBW   
       dConc(19*Np1+1) =  dFeS2BW  
       dConc(20*Np1+1) =  0.d0    ! dS0  
       dConc(21*NP1+1) =  dDICBW
       dConc(22*NP1+1) =  dALKbw

      RETURN
      END SUBROUTINE FEMSDIAmodBW
