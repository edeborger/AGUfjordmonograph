!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! biogeochemistry
!
! Karline Soetaert, nioz-yerseke
!==========================================================================

!==========================================================================
!==========================================================================
! subroutine for calculating the biogeochemical rates of
! the FEMSDIA model 
!==========================================================================
!==========================================================================
 
      SUBROUTINE FEMSDIAbiochem
      
      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION :: Rescale(N), mPads
      DOUBLE PRECISION :: pO2(N)
      
! molar mass (g/mol)
      DOUBLE PRECISION, PARAMETER :: wC = 12.0107,                              &
    &                                wO = 15.9994,                              &
    &                                wH  = 1,                                   &
    &                                wN  = 14.007,                              &
    &                                wP  = 30.97,                               &
    &                                wFe = 55.845,                              &
    &                                wMn = 54.94,                               &
    &                                wS  = 32.07      
! density at 20 grades C (mg/m3) MARTA: should be mg /m3 and not g/m3?
     DOUBLE PRECISION, PARAMETER :: pFeOH3 = 3.4e9,                             &
    &                               pMnO2  = 5.03e9,                            &
    &                               pS0    = 2.07e9,                            &
    &                               pFeS   = 4.3e9,                             &
    &                               pFeS2  = 4.9e9

      INTEGER :: I 
!............................ statements ..................................
   
        
! --------------------------------------------------------------------------
! Solid phases in percent 
!         (Spercent, Ppercent, Cpercent, Npercent, Fepercent, Mnpercent)
! inhibition factor due to too many solids 
!         (Solid_inhib)
! --------------------------------------------------------------------------
      
      CALL solid_fraction()
       
       
! --------------------------------------------------------------------------
! Rate of change due to biogeochemistry 
! --------------------------------------------------------------------------

! Production of DIC and DIN, expressed per cm3 LIQUID/day
! --------------------------------------------------------------------------

       DICprodMin = (rFast   * FDET            +                                &
     &               rSlow   * SDET            +                                &
     &               rRefrac * RDET          ) * solid2liquid
       DINprodMin = (rFast   * FDET * NCrFdet  +                                &
     &               rSlow   * SDET * NCrSdet  +                                &
     &               rRefrac * RDET * NCrRdet) * solid2liquid
       DIPprodMin = (rFast   * FDET * PCrFdet  +                                &
     &               rSlow   * SDET * PCrSdet  +                                &
     &               rRefrac * RDET * PCrRdet) * solid2liquid

! Oxic mineralisation, denitrification, anoxic mineralisation
! --------------------------------------------------------------------------

! limitation terms
       Oxicminlim =            O2/(O2    + ksO2oxic)
       
       Denitrilim = (1.d0 -    O2/(O2    + kinO2denit)) *                       &
     &                        NO3/(NO3   + ksNO3denit)

       Mnredlim   = (1.d0 -    O2/(O2    + kinO2denit)) *                       &
     &              (1.d0 -   NO3/(NO3   + ksNO3denit)) *                       &
     &                       MnO2/(MnO2  + ksMnO2)                                            
     
       Feredlim   = (1.d0 -    O2/(O2    + kinO2denit)) *                       &
     &              (1.d0 -   NO3/(NO3   + ksNO3denit)) *                       &
     &              (1.d0 -  MnO2/(MnO2  + kinMnO2))    *                       &  
     &                      FeOH3/(FeOH3 + ksFeOH3) 
     
       BSRlim     = (1.d0 -    O2/(O2    + kinO2anox))  *                       &
     &              (1.d0 -   NO3/(NO3   + kinNO3anox)) *                       &
     &              (1.d0 -  MnO2/(MnO2  + kinMnO2))    *                       &  
     &              (1.d0 - FeOH3/(FeOH3 + kinFeOH3))   *                       &
     &                        SO4/(SO4   + ksSO4BSR)
     
       Methlim    = (1.d0 -    O2/(O2    + kinO2anox))  *                       &
     &              (1.d0 -   NO3/(NO3   + kinNO3anox)) *                       &
     &              (1.d0 -  MnO2/(MnO2  + kinMnO2))    *                       & 
     &              (1.d0 - FeOH3/(FeOH3 + kinFeOH3))   *                       &
     &              (1.d0 -   SO4/(SO4   + kinSO4Met))

       Rescale   = 1.d0/(Oxicminlim + Denitrilim + Mnredlim +                   &  
     &                  Feredlim + BSRlim + Methlim)

! mineralisation rates - per m3 LIQUID/day
! --------------------------------------------------------------------------

       OxicMin    = DICprodMin * Oxicminlim * Rescale  ! oxic mineralisation
       Denitrific = DICprodMin * Denitrilim * Rescale  ! denitrification
       MnredMin   = DICprodMin * Mnredlim   * Rescale  ! MnO2 reduction   
       FeredMin   = DICprodMin * FeRedlim   * Rescale  ! FeOH3 reduction
       BSRMin     = DICprodMin * BSRlim     * Rescale  ! bacterial sulfate reduction
       MethMin    = DICprodMin * Methlim    * Rescale  ! Methanogenesis

! reoxidation rates - mmol /m3Liq/d
! --------------------------------------------------------------------------
       Nitri1     = rnitri1  * NH3 * O2 / (O2 + ksO2nitri)  
       Nitri2     = rnitri2  * NO2 * O2 / (O2 + ksO2nitri)   
       Anammox    = ranammox * NH3 * NO2                      
       Mnoxid     = rMnox    * Mn  * O2 * Solid_inhib                      
       Feoxid     = rFeox    * Fe  * O2 * Solid_inhib                          
       H2Soxid    = rH2Sox   * H2S * O2                     
       CH4oxid    = rCH4ox   * CH4 * O2                     
       AOM        = rAOM     * CH4 * SO4                    
       
! other redox rates - in mmol/m3Solid/d
         FeSoxid    = rFeSox   * FeS  * O2                     
         FeS2oxid   = rFeS2ox  * FeS2 * O2                     
       H2SMnoxid  = rH2SMnox * H2S  * MnO2    
         H2SFeoxid  = rH2SFeox * H2S  * FeOH3   
         FeMnoxid   = rFeMnox  * Fe   * MnO2    
       
! long-distance reoxidation
       pO2(:) = 0.d0
       
       IF (rSurfH2Sox + rSurfCH4ox .GT. 0) THEN 
          CALL long_distance(pO2)
       END IF        
 
! precipitation and dissolution rates
! --------------------------------------------------------------------------

! precipitation of FeS and FeS2
       FeSprod   = rFeSprod     * Fe  * H2S * Solid_inhib ! mmol liq/m3/d
       
       FeS2prod  = rFeS2prod_S0 * FeS *  S0 * Solid_inhib ! mmol solid/m3/d 

       FeS2prodB = rFeS2prod_HS * FeS * H2S * Solid_inhib ! mmol liq/m3/d 

! precipitation MnCO3 AND FeCO3               inhibited by O2 
! in mmol liq/m3/d
       MnCO3prod  = rMnCO3prod * Mn * DIC * Solid_inhib                         &
      &                                   * (1.d0 - O2/(O2+0.001d0))
       
       FeCO3prod  = rFeCO3prod * Fe * DIC * Solid_inhib                         &
      &                                   * (1.d0 - O2/(O2+0.001d0)) 

! adsorption and desorption rates
! --------------------------------------------------------------------------

! P adsorption to Fe-oxides if sufficient O2, P desorption other way around
       FePadsorp  = 0.d0

       DO I = 1, N
       
        IF (FeOH3(I) > 0.1d0) THEN
         FePadsorp(I)  = rFePadsorp * FeOH3(I) * PO4(I)      ! mmol liq/m3/d
        END IF
        
        FePdesorp(I) = 4.d0 * FeredMin(I) *                                     &
      &                       FeP(I) / max(1.d-8, FeOH3(I))  ! mmol liq/m3/d
       END DO

! P adsorption
       mPads = max(1D-8, maxPads)
       
       DO I = 1, N
         IF (Pads(I) <  maxPads) THEN
            Padsorp(I) = rPads *PO4(I) *(1.d0 - Pads(I)/ mPads) ! mmol liq/m3/d
         ELSE
            Padsorp(I) = -rPdes*Pads(I)*(1.d0-por(I))/por(I)    ! mmol liq/m3/d
         END IF   
       END DO   

! P binding to Ca and P-release
       CaPprod  = rCaPprod * PO4 * DIC/(DIC+1.d0) * Solid_inhib ! mmol liq/m3/d
       CaPdiss  = rCaPdiss * CaP                                ! mmol solid/m3/d

! --------------------------------------------------------------------------
! the increase/decrease of rates due to temperature (rateFac)
!
       Temperature = Twater
       
       IF (abs(Q10 - 1.d0) >  1d-10) THEN
         rateFac      = dexp((Temperature - Treference)/10.d0 * dlog(Q10))
         DICprodMin   = DICprodMin   * rateFac
         DINprodMin   = DINprodMin   * rateFac
         DIPprodMin   = DIPprodMin   * rateFac
         
         OxicMin      = OxicMin      * rateFac
         Denitrific   = Denitrific   * rateFac
         MnredMin     = MnredMin     * rateFac  
         FeredMin     = FeredMin     * rateFac
         MethMin      = MethMin      * rateFac
         BSRMin       = BSRMin       * rateFac
         
         Nitri1       = Nitri1       * rateFac
         Nitri2       = Nitri2       * rateFac
         Anammox      = Anammox      * rateFac
         
         Mnoxid       = Mnoxid       * rateFac 
         Feoxid       = Feoxid       * rateFac
         H2Soxid      = H2Soxid      * rateFac
         CH4oxid      = CH4oxid      * rateFac
         AOM          = AOM          * rateFac
         
         FeSoxid      = FeSoxid      * rateFac  
         FeS2oxid     = FeS2oxid     * rateFac 
         H2SMnoxid    = H2SMnoxid    * rateFac  
         H2SFeoxid    = H2SFeoxid    * rateFac  
         FeMnoxid     = FeMnoxid     * rateFac 
             
         FeSprod      = FeSprod      * rateFac  
         FeS2prod     = FeS2prod     * rateFac  
         FeS2prodB    = FeS2prodB    * rateFac  
         MnCO3prod    = MnCO3prod    * rateFac       
         FeCO3prod    = FeCO3prod    * rateFac  

! no temp dependence for FePadsorp, Padsorp and Pdesorp, 
! no temp dependence for CaPprod and CaPdiss
         FePdesorp    = FePdesorp    * rateFac
         
         TotH2Soxsurf = TotH2Soxsurf * rateFac(1)
         TotCH4oxsurf = TotCH4oxsurf * rateFac(1)
         H2Soxsurf    = H2Soxsurf    * rateFac(1)
         CH4oxsurf    = CH4oxsurf    * rateFac(1)
       ELSE
         rateFac      = 1.D0
       END IF
       
! --------------------------------------------------------------------------
! Update the rate of change with rates due to biogeochemical processes
! --------------------------------------------------------------------------

       dFDET = dFDET   - rFast   * FDET * rateFac 
       dSDET = dSDET   - rSlow   * SDET * rateFac
       dRDET = dRDET   - rRefrac * RDET * rateFac
      
       dO2   = dO2     - OxicMin                                                &
     &                 - 1.5d0 * Nitri1                                         &
     &                 - 0.5d0 * Nitri2                                         &
     &                 - 0.5d0 * Mnoxid                                         &
     &                 - 0.25  * Feoxid                                         &
     &                 - 2.d0  * H2Soxid                                        &
     &                 - 2.d0  * CH4oxid                                        &
     &                 - 2.d0  * FeSoxid  * solid2liquid                        &
     &                 - 3.5d0 * FeS2oxid * solid2liquid             
     
       dNH3  = dNH3 + (  DINprodMin                                             &
     &                 - Nitri1                                                 &
     &                 - Anammox   ) / (1.d0 + NH3Ads)
     
       dNO3  = dNO3    - 0.8d0 * Denitrific                                     &
     &                 + Nitri2 
     
       dNO2  = dNO2    - Anammox                                                &
     &                 + Nitri1                                                 &
     &                 - Nitri2 

       DICprodCH4 =    - 0.5d0 * MethMin                                        &
     &                 + CH4oxid                                                &
     &                 + AOM  

       dCH4  = dCH4    - DICprodCH4

       DICprod   =     + DICprodMin                                             &
     &                 + DICprodCH4                                             &
     &                 + CPrCaP*(  CaPdiss * solid2liquid                       &
     &                           - CaPprod                 )                    &
     &                 - MnCO3prod                                              &
     &                 - FeCO3prod
          
       dDIC  = dDIC    + DICprod
       
       dPO4  = dPO4    + DIPprodMin                                             &
     &                 + FePdesorp                                              &
     &                 - Padsorp                                                &
     &                 - FePadsorp                                              &
     &                 - CaPprod                                                &
     &                 + CaPdiss * solid2liquid 
     
       dFeP  = dFeP    + (  FePadsorp                                           &
     &                    - FePdesorp ) * liquid2solid
       
       dCaP  = dCaP    + CaPprod * liquid2solid                                 &
     &                 - CaPdiss
       
       dMn   = dMn     + 2.d0 *  MnredMin                                       &
     &                 -         Mnoxid                                         &
     &                 -         MnCO3prod                                      &
     &                 +         H2SMnoxid * solid2liquid                       &
     &                 + 0.5d0 * FeMnoxid  * solid2liquid                          
     
       dMnO2 = dMnO2   +         Mnoxid    * liquid2solid                       &
     &                 - 2.d0  * MnredMin  * liquid2solid                       &
     &                 - 0.5d0 * FeMnoxid                                       &
     &                 -         H2SMnoxid        
     
       dFe   = dFe     + 4.d0 * FeredMin                                        &
     &                 -        Feoxid                                          &
     &                 -        FeSprod                                         &
     &                 +        FeSoxid   * solid2liquid                        &
     &                 +        FeS2oxid  * solid2liquid                        &
     &                 -        FeMnoxid  * solid2liquid                        &
     &                 + 2.d0 * H2SFeoxid * solid2liquid                        &
     &                 -        FeCO3prod
       
       dFeOH3 = dFeOH3 +        FeOxid    * liquid2solid                        &
     &                 - 4.d0 * FeredMin  * liquid2solid                        &
     &                 +        FeMnoxid                                        &
     &                 - 2.d0 * H2SFeoxid                                   
       
       dH2S  = dH2S    + 0.5d0 * BSRMin                                         &
     &                 -         H2Soxid                                        &
     &                 -         FeSprod                                        &
     &                 +         AOM                                            &
     &                 -         H2SMnoxid *solid2liquid                        &
     &                 -         H2SFeoxid *solid2liquid                        &
     &                 -         FeS2prodB
     
       dSO4  = dSO4    - 0.5d0 * BSRMin                                         &
     &                 +         H2Soxid                                        &
     &                 +         FeSoxid  * solid2liquid                        &
     &                 + 2.d0  * FeS2oxid * solid2liquid                        &
     &                 -         AOM
       
       dPads = dPads   + Padsorp * liquid2solid
       
       dFeS  = dFeS    + FeSprod * liquid2solid                                 &
     &                 - FeS2prod                                               &
     &                 - FeSoxid                                                &
     &                 - FeS2prodB*liquid2solid
       
       dFeS2  = dFeS2  + FeS2prod                                               &
     &                 + FeS2prodB*liquid2solid                                 &
     &                 - FeS2oxid                                              

       dS0    = dS0    - FeS2prod                                               &
     &                 + H2SMnoxid                                              &
     &                 + H2SFeoxid                

! longdistance HSoxidation: effect on alkalinity is split in two parts
! O2 + 4e + 4H+ -> 2H2O                  dALK = +4 (per mmol O)   OR +8 per mmol S
! H2S + 4H2O    -> SO42- + 2e + 10H+     dALK = -10 (per mmol S)

       O2distConsump = 2.d0*(TotH2Soxsurf + TotCH4oxsurf) * pO2
       
       IF (rSurfH2Sox .GT. 0) THEN         ! long-distance reoxidation
        
        dO2  = dO2  - 2.d0*TotH2Soxsurf*pO2/dx/por
        dH2S = dH2S - H2Soxsurf
        dSO4 = dSO4 + H2Soxsurf
       
       END IF
       
       IF (rSurfCH4ox .GT. 0) THEN         ! long-distance reoxidation
        dO2  = dO2 - 2.d0*TotCH4oxsurf*pO2/dx/por
        dCH4 = dCH4 - CH4oxsurf
        dDIC = dDIC + CH4oxsurf
        DICprod    = DICprod    + CH4oxsurf
        DICprodCH4 = DICprodCH4 + CH4oxsurf
       END IF

! Alkalinity production       
! Alkalinity = HCO3 +2*CO3 + BOH4 + OH + HPO4 + 2*PO4 + SiOOH3 
! + HS + 2*S2min + NH3 - H - HSO4 - HF - H3PO4

! note: dTA = dNH3 - dNO3 - dNO2 - dPO4 - 2*dSO4 + dFe + dMn - dF  ! change
! equation nrs from Soetaert et al., Marine Chemistry 105, 30-51, table 3 (p40)

       AlkProd  = DINprodMin                                                    & !1-7
     &          - DIPprodMin                                                    & !1-7 
     &          + 0.8d0 * Denitrific                                            & !2 
     &          + 8.d0 * FeredMin                                               & !4
     &          + 4.d0 * MnredMin                                               & !5
     &          +        BSRMin                                                 & !6
     &          - 2* Nitri1                                                     & !8 
     &          - 2.d0 * Mnoxid                                                 & !10 
     &          - 2.d0 * Feoxid                                                 & !11
     &          - 1.d0 * FeMnoxid                                               & !13
     &          - 2.d0 * H2Soxid                                                & !14
     &          + 2.d0 * AOM                                                    & !16
     &          - 2.d0 * FeSoxid                                                & !17
     &          - 2.d0 * FeSprod                                                & !21
     &          - 2.d0 * MnCO3prod                                              & !23
     &          - 2.d0 * FeCO3prod                                              & !24
     &          + 4.d0 * H2SFeoxid                                              & !26
     &          + 2.d0 * H2SMnoxid                                              & !27
     &          - FePdesorp                                                     &
     &          + Padsorp                                                       &
     &          + FePadsorp                                                     & 
     &          + (CaPprod - CaPdiss*solid2liquid) * (1.d0+1.8/4.6)             &
     &          - 4.d0 * FeS2oxid

! Note : 1. NH3 escape to air : -1 
!
! Note : 2. No impact on alkalinity, except for N and P release: eqs, 1, 7, 15
!
! Note : 3. No impact on alkalinity: 
! nitri2 eq 9, Methoxid, eq 15, H2SFeoxid eq 20, FeS2prod, eq 22
!
! Note : 4. equation not in model: 
! Fe+0.2HNO3          -> FeOOH + N2 +2H+             , eq12  
! FeS + 4MnO2 + 10H+  -> 4Mn2+ + H2SO4 + Fe2+ + 4H2O , eq18
! FeS + 2FeOH3 + 6H+  -> 3Fe2+ + S0                  , eq19
! FeS + H2S           -> FeS2 + H2                   , eq22

! for CaP production:
!  4.6*H3PO4+1.3H2CO3+1.8*HF+1.45H2O -> CaP     =>> 1pO4 ~ 1.8/4.6 F => 4.6???
        
        IF (rSurfH2Sox .GT. 0) THEN         ! long-distance reoxidation
          Alkprod = Alkprod + 8.d0*TotH2Soxsurf*pO2/dx/por                      &
     &                      - 8.d0*H2Soxsurf                 ! or -10???
        END IF
       
        dAlk = dAlk + Alkprod

      RETURN 
      END SUBROUTINE FEMSDIAbiochem

!==========================================================================
! Solid phases in percent 
! inhibition factor due to too many solids 
!==========================================================================
      
      SUBROUTINE solid_fraction 

      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
! molar mass (g/mol)
      DOUBLE PRECISION, PARAMETER :: wC = 12.0107,                              &
    &                                wO = 15.9994,                              &
    &                                wH  = 1,                                   &
    &                                wN  = 14.007,                              &
    &                                wP  = 30.97,                               &
    &                                wFe = 55.845,                              &
    &                                wMn = 54.94,                               &
    &                                wS  = 32.07      
! density at 20 grades C (mg/m3) MARTA: should be mg /m3 and not g/m3?
     DOUBLE PRECISION, PARAMETER :: pFeOH3 = 3.4e9,                             &
    &                               pMnO2  = 5.03e9,                            &
    &                               pS0    = 2.07e9,                            &
    &                               pFeS   = 4.3e9,                             &
    &                               pFeS2  = 4.9e9
!............................ statements ..................................
      
       OCpercent = (FDET            +                                           &
     &              SDET            +                                           &
     &              RDET)           * wC  * 100d0*1e-9/2.5           
       
       ONpercent = (FDET * NCrFDET  +                                           &
     &              SDET * NCrSDET  +                                           &
     &              RDET * NCrRDET) * wN  * 100d0*1e-9/2.5
       
       Mnpercent = MnO2             * wMn * 100d0*1e-9/2.5 ! % Mn  
       
       Fepercent = (FeOH3                                                       &
     &            + FeS                                                         &
     &            + FeS2          ) * wFe * 100d0*1e-9/2.5 ! % Fe  
       
       Ppercent  = (FDET * PCrFDET                                              &
     &            + SDET * PCrSDET                                              &
     &            + RDET * PCrRDET                                              &
     &            + FeP                                                         &
     &            + CaP           ) * wP  * 100d0*1e-9/2.5 ! % P  
     
       Spercent  = (FeS                                                         &
     &            + 2*FeS2                                                      &
     &            + S0            ) * wS  * 100d0*1e-9/2.5 ! % S  
       
! total solid in m3 REACTIVE SOLIDS / m3 SOLID
         ! m3 FeOH3 per  m3 SOLID + FeS + FeS2 + MnO2 + S0
        Solidpercent =                                                          &
     &             (1.d0*wFe + 3.d0*(wO+wH)) * FeOH3 / pFeOH3                   &
     &           + (1.d0*wFe + 1.d0*wS)      * FeS   / pFeS                     &
     &           + (1.d0*wFe + 2.d0*wS)      * FeS2  / pFeS2                    &
     &           + (1.d0*wMn + 2.d0*wO)      * MnO2  / pMnO2                    & 
     &           + (1.d0*wS           )      * S0    / pS0

       Solidpercent  =  Solidpercent * 100.d0   ! in percent

       ! inhibition switches on around 10 % 
       Solid_inhib = 1.d0 - Solidpercent **3.0 /                                &
     &                     (Solidpercent **3.0 + 10.d0**3.0)

      END SUBROUTINE solid_fraction
      
!==========================================================================
! Long-distance reaction
!==========================================================================
      
    SUBROUTINE long_distance(pO2)

      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION, INTENT(out) ::  pO2(N)
      DOUBLE PRECISION ::  totalpo2, sum 

      INTEGER :: I 
!............................ statements ..................................

       TotalpO2 = 0.d0
       Sum     = 0.d0
       DO I = 1, N
          PO2(I)   = O2(I)*dx(I)*por(I)
          Sum      = Sum + dx(I)*por(I)
          totalpo2 = totalpo2 + pO2(I)
       END DO
       pO2 = pO2/totalpo2
       
       TotH2Soxsurf = 0.d0
       H2Soxsurf(:) = 0.d0
       
       IF (rSurfH2Sox .GT. 0) THEN  
        H2Soxsurf = rSurfH2Sox * H2S           *                                &
     &              ALK**2/(ALK**2 + ksSurfALK**2) *                            &
     &              (1.d0-O2/(O2+0.01))        *                                &
     &              totalpo2/(totalpo2+ksO2reox) * distreact
        
        DO I = 1, N
          TotH2Soxsurf = TotH2Soxsurf + H2Soxsurf(I) * por(I)*dx(I)
        END DO
       
       END IF

       TotCH4oxsurf  = 0.d0
       CH4oxsurf (:) = 0.d0
       
       IF (rSurfCH4ox .GT. 0) THEN  
        CH4oxsurf = rSurfCH4ox * CH4           *                                &
     &              ALK**2/(ALK**2 + ksSurfALK**2) *                            &
     &              (1.d0-O2/(O2+0.01))        *                                &
     &              totalpo2/(totalpo2+ksO2reox) * distreact
        
        DO I = 1, N
          TotCH4oxsurf = TotCH4oxsurf  + CH4oxsurf(I) * por(I)*dx(I)
        END DO
       
       END IF
    
    RETURN
    END SUBROUTINE long_distance    
      
!==========================================================================
! Methane ebullition
!==========================================================================
      
    SUBROUTINE Methane_solubility(CH4sol)

      USE modulefemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      DOUBLE PRECISION, INTENT(out) ::  CH4sol(N)
      DOUBLE PRECISION :: tK, P0
      DOUBLE PRECISION :: PP(N), PP2(N), ccA(N), cB(N), cD(N)
!............................ statements ..................................

! Methane solubility in seawater

      tK = Twater + 273.15d0 ! temperature [K]
  
! -----------------------------------
! pressure, taking into account:
!  water depth (Hwater) and 
!  depth in sediment (x)
! -----------------------------------
      P0  = 1.013d0                               ! atmospheric pressure [bar]
      ! Dwater is density of water
      ! convert from Pa to bar (1 bar = 1e5 Pa)
      PP  = P0 + (Hwater + x)*9.8d0 * Dwater / 1d5 
      PP2 = PP**2.d0
  
  ! Methane solubiliy  (Mogollon et al., GRL, 2013)
      cB = (2.269174d3  * PP**(-7.794562d-1) + 2.611d3)*tK
      
      ccA = cB ** (-1.186056d-1 * PP **(-6.026738d-1) - 2.314900)
      
      cD =  (-4.372018d-9 * PP2 + 8.278747d-7 * PP - 1.478806d-8 )*tK**2 +      &
    &        (2.699539d-6 * PP2 - 5.148083d-4 * PP + 6.761301d-6 )*tK    +      &
    &       (-4.205982d-4 * PP2 + 8.132632d-2 * PP - 7.307755e-4 ) 
    
      CH4sol =  cD * exp(-ccA * Swater)  ! in mol kg-1 sw
  
!  ebullition = rEbul * (CH4-CH4sol) * (CH4>CH4sol)  ! [mol m-3 pw yr-1]

    RETURN
    END SUBROUTINE Methane_solubility    
                        
                    