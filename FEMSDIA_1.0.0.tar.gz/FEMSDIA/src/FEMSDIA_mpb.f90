!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! simple MPB dynamics
! Karline Soetaert, nioz-yerseke
!==========================================================================


!==========================================================================
!==========================================================================
! subroutine for calculating the biogeochemical rates of
! microphytobenthos (simple)
!==========================================================================
!==========================================================================
 
      SUBROUTINE MPBFEMSDIAsimple
      
      USE modulefemsdia
      IMPLICIT NONE
      
!......................... declaration section.............................
      DOUBLE PRECISION :: DIN, MPBlim, pNH3(N)
      
      INTEGER :: I
!............................ statements ..................................

! --------------------------------------------------------------------------
! Rate of change due to Microphytobenthos
! --------------------------------------------------------------------------
! MPB production without explicitly describing MPB 
! no inhibition of NO3 uptake by NH3

      IF (MPBprod > 0.D0) THEN

        DO I = 1, N
         DIN     = NH3(I) + NO3(I)
         pNH3(I) = NH3(I)/ max(DIN, 1D-10)
         MPBlim  = min (DIN    / (DIN    + kNH3upt),                            &
     &                  PO4(I) / (PO4(I) + kPO4upt),                            &
     &                  DIC(I) / (DIC(I) + kDICupt))
     
       ! per solid
         MPBCprod(I) = max(0.D0,                                                &
     &                     MPBprod * exp(-kdSed*x(I)) * MPBlim) 
        END DO   

       ! multiplication factor (eg temperature)
        Temperature = Twater   
        
        IF (abs(Q10 - 1.d0) >  1d-10) THEN  ! Q10 is not equal to 1
          rateFac =  dexp((Temperature - Treference)/10.d0*dlog(Q10))
          MPBCprod = MPBCprod*ratefac
        END IF
                                ! change units: /m3 liquid/d    
        MPBO2prod    = MPBCprod  * solid2liquid    
        MPBuptakeNO3 = MPBO2prod * NCrFdet * (1.d0-pNH3)
        MPBuptakeNH3 = MPBO2prod * NCrFdet *  pNH3
        MPBuptakePO4 = MPBO2prod * PCrFdet
        MPBuptakeDIC = MPBO2prod 

        dFDET = dFDET + MPBCprod

      ! Note extra oxygen production related to the reduction of nitrate 
      ! (2 moles per NO3 uptake)
      
        dO2   = dO2   + MPBO2prod                                               &
     &                + 2.D0 * MPBuptakeNO3

        dNH3  = dNH3  - MPBuptakeNH3/(1.D0+NH3Ads)
       
        dNO3  = dNO3  - MPBuptakeNO3 

        dDIC  = dDIC  - MPBuptakeDIC

        dPO4  = dPO4  - MPBuptakePO4
        
! note: dTA = dNH3 - dNO3 - dNO2 - dPO4 - 2*dSO4 
! impact on alkalinity
        dAlk     = dAlk    + MPBuptakeNO3                                     &
     &                     - MPBuptakeNH3                                     &
     &                     + MPBuptakePO4
     
        AlkProd  = AlkProd + MPBuptakeNO3                                     &
     &                     - MPBuptakeNH3                                     &
     &                     + MPBuptakePO4 

        DICprod  = DICprod - MPBuptakeDIC
        
       ELSE    ! No MPB dynamics
       
        MPBCprod         = 0.D0
        MPBO2prod        = 0.D0
        MPBuptakeNO3     = 0.D0
        MPBuptakeNH3     = 0.D0
        MPBuptakePO4     = 0.D0
        MPBuptakeDIC     = 0.D0
       
       END IF
       
      RETURN
      END SUBROUTINE MPBFEMSDIAsimple
     
!==========================================================================
! Integrated rates for MPB production
!==========================================================================
      
      SUBROUTINE MPBFEMSDIAsimpleout
      USE modulefemsdia
      IMPLICIT NONE
      
!......................... declaration section.............................
      INTEGER :: I
!............................ statements ..................................

      TotMPBO2prod    = 0.D0
      TotMPBPO4uptake = 0.D0
      totMPBNH3uptake = 0.D0
      totMPBNO3uptake = 0.D0

      DO I = 1, N
        TotMPBO2prod    = TotMPBO2prod    + MPBO2prod(I)    *por(I)*dx(I)
        TotMPBNO3uptake = TotMPBNO3uptake + MPBuptakeNO3(I) *por(I)*dx(I)
        TotMPBNH3uptake = TotMPBNH3uptake + MPBuptakeNH3(I) *por(I)*dx(I)
        TotMPBPO4uptake = TotMPBPO4uptake + MPBuptakePO4(I) *por(I)*dx(I)
      END DO

      TotMPBDICuptake = TotMPBO2prod
      totNH3adsorp = totNH3adsorp - TotMPBNH3uptake *                           &
     &               (1.d0-1.d0/(1.d0+NH3Ads))

      RETURN
      END SUBROUTINE MPBFEMSDIAsimpleout
