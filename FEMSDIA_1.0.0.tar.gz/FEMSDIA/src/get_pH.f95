
!===============================================================================
!===============================================================================
! Function to estimate pH based on lumpsums and alkalinity
! will be called from R (FEMSDIA_get_pH)
!===============================================================================
!===============================================================================

  SUBROUTINE EstimatePH (Temp, Sal, depth, Alk, SumCO2, SumH3PO4,               &
                         SumNH4, SumH2S, SumH2SO4, maxIter, N,                  &
                         pH, Ks, cts, iter)

  USE pHenvironment
  
  IMPLICIT NONE

!......................... declaration section.............................
  INTEGER          :: maxIter, N, iter(N)
  DOUBLE PRECISION :: Temp(N), Sal, depth
  DOUBLE PRECISION :: pH(N), Alk(N), SumCO2(N), SumH3PO4(N), SumH2S(N) 
  DOUBLE PRECISION :: SumNH4(N), SumH2SO4(N)
  DOUBLE PRECISION :: pHI, Hguess, H
  DOUBLE PRECISION :: Ks(20), Cts(12)
  
  LOGICAL          :: finished, found
  INTEGER          :: I, II
  DOUBLE PRECISION, EXTERNAL  :: EstimateH, RootFun, Zeroin 
  DOUBLE PRECISION, PARAMETER :: tolerance = 1D-12
!............................ statements ..................................

  SumB      = 1.1878788D-5 * Sal
  SumF      = 1.952167D-06 * Sal
  KS(17)    = TotToFree
  KS(18)    = SWSToFree
  KS(19)    = SumB*1e6
  KS(20)    = SumF*1e6
  
  DO I = 1, N
    CALL initialize (Temp(I), Sal, depth, Cts)
    PHI       = PH(I)
    TA        = Alk(I)
    SumS      = SumH2SO4(I)
    SumC      = SumCO2(I)
    SumN      = SumNH4(I)
    SumP      = SumH3PO4(I)
    SumHS     = SumH2S(I)

    CALL dissociation (Temp, Sal, depth, KS)

! first guess of H+ concentration

    IF (phI .LT. 1 .OR. pHI .GT. 10.5) pHI = 8.D0
    H        = 10.d0**(-phI)
    finished = .FALSE.       
    found    = .FALSE. ! Will be true when convergence is reached
    II       = 0

    DO WHILE (.NOT. finished)
       II = II+1
       Hguess = EstimateH(H)
       IF (ABS(HGuess - H)*1e12 .LT. Tolerance) THEN
          finished = .TRUE.
          found    = .TRUE.
       END IF
       
       IF (II .GE. maxiter)        Finished = .TRUE.
       IF (Hguess .LE. 0)          Finished = .TRUE.
       H = Hguess
     END DO
     
     iter(I) = II

     IF (.NOT. found .OR. H .LE. 0 .OR. II .GE. maxiter) THEN
       H = zeroin(10.D0**(-10), 10.D0**(-2), rootfun, Tolerance)
     END IF
    
     IF (H .GT. 0.d0) THEN
         pH(I)   = -LOG10(H)
     ELSE
         pH(I) = -99.
     END IF

     pHI   = pH(I)
     
   END DO
  
  RETURN 
  END SUBROUTINE EstimatePH
