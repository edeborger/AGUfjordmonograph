!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! output
!
! Karline Soetaert, nioz-yerseke
!==========================================================================

!==========================================================================
!==========================================================================
! subroutine for calculating integrated rates and writing the output
!==========================================================================
!==========================================================================
      
      SUBROUTINE FEMSDIAout
      USE modulefemsdia
      IMPLICIT NONE
      
!......................... declaration section.............................
      DOUBLE PRECISION  ::  liqfac, solfac, DIN, sumDIN, sumPO4
      INTEGER :: I
!............................ statements ..................................

! organic matter fluxes
       OrgCflux = CarbonFlux
       OrgNflux = OrgcFlux * pFast        * NCrFDET +                           &
      &           Orgcflux * (1.d0-pFast) * NCrSDET
       OrgPflux = OrgcFlux * pFast        * PCrFDET +                           &
      &           Orgcflux * (1.d0-pFast) * PCrSDET

! integrated rates
       TotOxic       = 0.d0
       TotDenit      = 0.d0
       TotMnred      = 0.d0
       TotFered      = 0.d0
       TotBSR        = 0.d0
       TotMeth       = 0.d0
       
       TotNH3prodMin = 0.d0
       TotPO4prodMin = 0.d0
       TotALkprod    = 0.d0
       
       TotNH3adsorp  = 0.d0
       TotNitri1     = 0.d0
       TotNitri2     = 0.d0
       TotAnammox    = 0.d0
       
       TotFePprod    = 0.d0
       TotCaPprod    = 0.d0
       TotFePdesorp  = 0.d0
       TotCaPdiss    = 0.d0  
       TotPadsorp    = 0.d0
       
       TotFeSprod    = 0.d0
       TotFeS2prod   = 0.d0 
       TotFeS2prodB  = 0.d0 
       TotMnCO3prod  = 0.d0 
       TotFeCO3prod  = 0.d0 
       
       TotMnoxid     = 0.d0 
       TotFeoxid     = 0.d0
       TotH2Soxid    = 0.d0
       TotCH4oxid    = 0.d0
       TotAOM        = 0.d0
       TotH2SMnoxid  = 0.d0
       TotH2SFeoxid  = 0.d0 
       TotFeMnoxid   = 0.d0 
       TotFeSoxid    = 0.d0
       TotFeS2oxid   = 0.d0
       
       sumDIN        = 0.d0
       sumPO4        = 0.d0
       partPremoved  = 0.d0

       
! Mean concentrations
       TotalFDET     = 0.d0
       TotalSDET     = 0.d0 
       TotalRDET     = 0.d0 
       TotalMnO2     = 0.d0 
       TotalFeOH3    = 0.d0
       TotalFeP      = 0.d0 
       TotalCaP      = 0.d0 
       TotalPads     = 0.d0      
       
       TotalO2       = 0.d0 
       TotalNO3      = 0.d0  
       TotalNO2      = 0.d0 
       TotalNH3      = 0.d0 
       TotalMn       = 0.d0 
       TotalFe       = 0.d0 
       TotalH2S      = 0.d0 
       TotalSO4      = 0.d0 
       TotalCH4      = 0.d0 
       TotalPO4      = 0.d0 
       TotalFeS      = 0.d0
       TotalFeS2     = 0.d0
       TotalS0       = 0.d0
       TotalDIC      = 0.d0 
       TotalAlk      = 0.d0

       DO I = 1, N
         liqfac        =  por(I)      *dx(I)  ! from /m3 liquid -> m2 bulk
         solfac        = (1.d0-por(I))*dx(I)  ! from /m3 solid  -> m2 bulk
       
         TotOxic       = TotOxic       + OxicMin(I)    * liqfac
         TotDenit      = TotDenit      + Denitrific(I) * liqfac
         TotMnRed      = TotMnRed      + MnredMin(I)   * liqfac
         TotFeRed      = TotFeRed      + FeredMin(I)   * liqfac
         TotBSR        = TotBSR        + BSRMin(I)     * liqfac
         TotMeth       = TotMeth       + MethMin(I)    * liqfac
         
         TotNH3prodMin = TotNH3prodMin + DINprodMin(I) * liqfac
         TotPO4prodMin = TotPO4prodMin + DIPprodMin(I) * liqfac
         TotALkprod    = TotALkprod    + AlkProd(I)    * liqfac
         
         TotNitri1     = TotNitri1     + Nitri1(I)     * liqfac
         TotNitri2     = TotNitri2     + Nitri2(I)     * liqfac
         TotAnammox    = TotAnammox    + Anammox(I)    * liqfac
         
         TotFePprod    = TotFePprod    + FePadsorp(I)  * liqfac
         TotCaPprod    = TotCaPprod    + CaPprod(I)    * liqfac
         TotFePdesorp  = TotFePdesorp  + FePdesorp(I)  * solfac
         TotCaPdiss    = TotCaPdiss    + CaPdiss(I)    * solfac
         TotPadsorp    = TotPadsorp    + Padsorp(I)    * liqfac
         
         TotFeSprod    = TotFeSprod    + FeSprod(I)    * liqfac
         TotFeS2prod   = TotFeS2prod   + FeS2prod(I)   * solfac 
         TotFeS2prodB  = TotFeS2prodB  + FeS2prodB(I)  * liqfac 
         TotMnCO3prod  = TotMnCO3prod  + MnCO3prod(I)  * liqfac 
         TotFeCO3prod  = TotFeCO3prod  + FeCO3prod(I)  * liqfac 
         
         TotMnoxid     = TotMnoxid     + Mnoxid(I)     * liqfac 
         TotFeoxid     = TotFeoxid     + Feoxid(I)     * liqfac
         TotH2Soxid    = TotH2Soxid    + H2Soxid(I)    * liqfac
         TotCH4oxid    = TotCH4oxid    + CH4oxid(I)    * liqfac
         TotAOM        = TotAOM        + AOM(I)        * liqfac
         
         TotH2SMnoxid  = TotH2SMnoxid  + H2SMnoxid(I)  * liqfac
         TotH2SFeoxid  = TotH2SFeoxid  + H2SFeoxid(I)  * liqfac 
         TotFeMnoxid   = TotFeMnoxid   + FeMnoxid(I)   * liqfac 
         TotFeSoxid    = TotFeSoxid    + FeSoxid(I)    * solfac
         TotFeS2oxid   = TotFeS2oxid   + FeS2oxid(I)   * solfac

         DIN           = NH3(I) + NO3(I) + NO2(I)
         sumDIN        = sumDIN        + DIN           * liqfac
         sumPO4        = sumPO4        + PO4(I)        * liqfac

         partPremoved = partPremoved  + (FePdesorp(I) + CaPdiss(I))* solfac

         TotalFDET    = TotalFDET  + FDET(I)  * solfac
         TotalSDET    = TotalSDET  + SDET(I)  * solfac
         TotalRDET    = TotalRDET  + RDET(I)  * solfac
         TotalMnO2    = TotalMnO2  + MnO2(I)  * solfac 
         TotalFeOH3   = TotalFeOH3 + FeOH3(I) * solfac
         TotalFeP     = TotalFeP   + FeP(I)   * solfac
         TotalCaP     = TotalCaP   + CaP(I)   * solfac
         TotalPads    = TotalPads  + Pads(I)  * solfac
         TotalO2      = TotalO2    + O2(I)    * liqfac
         TotalNO3     = TotalNO3   + NO3(I)   * liqfac
         TotalNO2     = TotalNO2   + NO2(I)   * liqfac
         TotalNH3     = TotalNH3   + NH3(I)   * liqfac
         TotalMn      = TotalMn    + Mn(I)    * liqfac
         TotalFe      = TotalFe    + Fe(I)    * liqfac
         TotalH2S     = TotalH2S   + H2S(I)   * liqfac
         TotalSO4     = TotalSO4   + SO4(I)   * liqfac
         TotalCH4     = TotalCH4   + CH4(I)   * liqfac
         TotalPO4     = TotalPO4   + PO4(I)   * liqfac
         TotalFeS     = TotalFeS   + FeS(I)   * solfac
         TotalFeS2    = TotalFeS2  + FeS2(I)  * solfac
         TotalS0      = TotalS0    + S0(I)    * liqfac
         TotalDIC     = TotalDIC   + DIC(I)   * liqfac
         TotalAlk     = TotalAlk   + ALK(I)   * liqfac

       END DO

       TotMin      =  TotOxic + TotDenit + TotMnred +                           &
     &                TotFered + TotBSR + TotMeth  
    
       partDenit   = TotDenit / TotMin
       partOxic    = TotOxic  / TotMin
       partMnred   = TotMnred / TotMin
       partFered   = TotFered / TotMin
       partBSR     = TotBSR   / TotMin
       partMethano = TotMeth  / TotMin
       
       partPremoved = TotCaPprod + TotFePprod + TotPadsorp - partPremoved
       partPremoved = partPremoved / TotPO4prodMin
       
       partNremoved = (TotDenit*0.8d0 + TotAnammox*2.d0)/TotNH3prodMin
       
       DINDIPflux   = (NO3flux + NO2flux + NH3flux) / PO4flux
       DINDIPmean   = sumDIN/max(1D-8, sumPO4)
       DINDIPdeep   = (NH3(N) + NO2(N) + NO3(N)) / max(1d-8, PO4(N))
       
       TotNH3adsorp = (TotNH3prodMin - TotNitri1 - TotAnammox) *                &
     &               (1.d0-1.d0/(1.d0+NH3Ads))

      RETURN
      END SUBROUTINE FEMSDIAout

!==========================================================================
! put output variables in one vector
!==========================================================================

      SUBROUTINE getoutFES(yout)
      USE dimfemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      INTEGER :: i
      DOUBLE PRECISION :: yout(*), out(noutdia), forc(nforcs)

      COMMON /cbfemsdiaout /out
      COMMON /cbfemsdiaforc/forc
!............................ statements ..................................

      DO i = 1, Noutdia
       yout(i) = out (i)
      END DO  
      
      DO i = 1, Nforcsdia
       yout(noutdia+i) = forc (i)
      END DO       
 
      RETURN
      END SUBROUTINE getoutFES
