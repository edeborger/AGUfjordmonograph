!==========================================================================
! FEMSDIA, diagenetic model describing 
! C, N, O2, P, Mn, Fe, and S biogeochemistry 
!
! implemented in FORTRAN
!
! Main functions
!
! Karline Soetaert, nioz-yerseke
!==========================================================================


!==========================================================================
! initialise the common block with parameter values, 
! followed by thicknesses, surface, porosities, bioturbation values
!==========================================================================

      SUBROUTINE initfemsdia (steadyparms)
      USE dimfemsdia
      
      IMPLICIT NONE

!......................... declaration section.............................
      EXTERNAL steadyparms

      DOUBLE PRECISION parms(nparms)
      COMMON /cbfemsdiapar/parms
!............................ statements ..................................

        CALL steadyparms(nparms, parms)
        
        DynamicpH   = .FALSE.
        CALL init_tran_por()
        initialized = .FALSE.
        
      RETURN
      END SUBROUTINE initfemsdia

!==========================================================================
! Initialise transport parameters
!==========================================================================

      SUBROUTINE init_tran_por
      USE modulefemsdia
      
      IMPLICIT NONE
        
!............................ statements ..................................
        ! conversions between phases
        liquid2solid =  por/(1.d0-por)    ! from /m3 liquid -> /m3 solid
        solid2liquid = (1.d0-por)/por     ! from /m3 solid  -> /m3 liquid
        
        ! Boundary conditions, as integer
        BCupO2    = INT(BCup_O2    + 0.1)  
        BCupNO3   = INT(BCup_NO3   + 0.1) 
        BCupNO2   = INT(BCup_NO2   + 0.1) 
        BCupNH3   = INT(BCup_NH3   + 0.1) 
        BCupMn    = INT(BCup_Mn    + 0.1) 
        BCupFe    = INT(BCup_Fe    + 0.1) 
        BCupH2S   = INT(BCup_H2S   + 0.1) 
        BCupSO4   = INT(BCup_SO4   + 0.1) 
        BCupCH4   = INT(BCup_CH4   + 0.1) 
        BCupPO4   = INT(BCup_PO4   + 0.1) 
        BCupDIC   = INT(BCup_DIC   + 0.1) 
        BCupALK   = INT(BCup_Alk   + 0.1) 
        BCupCa    = INT(BCup_Ca    + 0.1) 

        BCdwnO2   = INT(BCdwn_O2   + 0.1)   
        BCdwnNO3  = INT(BCdwn_NO3  + 0.1)   
        BCdwnNO2  = INT(BCdwn_NO2  + 0.1)   
        BCdwnNH3  = INT(BCdwn_NH3  + 0.1)   
        BCdwnMn   = INT(BCdwn_Mn   + 0.1)   
        BCdwnFe   = INT(BCdwn_Fe   + 0.1)   
        BCdwnH2S  = INT(BCdwn_H2S  + 0.1)   
        BCdwnSO4  = INT(BCdwn_SO4  + 0.1)   
        BCdwnCH4  = INT(BCdwn_CH4  + 0.1)   
        BCdwnPO4  = INT(BCdwn_PO4  + 0.1)   
        BCdwnDIC  = INT(BCdwn_Fe   + 0.1)   
        BCdwnALK  = INT(BCdwn_ALK  + 0.1)   
        BCdwnCa   = INT(BCdwn_Ca   + 0.1)   
        
      RETURN
      END SUBROUTINE init_tran_por

!==========================================================================
! Initialise the forcing function common block  
!==========================================================================

      SUBROUTINE initfemsforc (steadyforcs)
      
      USE dimfemsdia
      IMPLICIT NONE

!......................... declaration section.............................
      EXTERNAL steadyforcs

      DOUBLE PRECISION forcs(nforcs)
      COMMON /cbfemsdiaforc/forcs
!............................ statements ..................................

       CALL steadyforcs(nforcs, forcs)
       
      RETURN
      END SUBROUTINE initfemsforc

!==========================================================================
!==========================================================================
! subroutine calculating the rate of change of
! the FEMSDIA model - here the quantities in the common blocks are named
!==========================================================================
!==========================================================================

      SUBROUTINE femsdiamod (neq, t, Conc, dConc, yout, ip)
      
      USE modulefemsdia
      IMPLICIT NONE

!......................... declaration section.............................
      INTEGER           :: neq, ip(*), i ! ip vector integers
      DOUBLE PRECISION  :: t, Conc(23*N), dConc(23*N), yout(*)   
!............................ statements ..................................

! --------------------------------------------------------------------------
!     check memory allocated to output variables
! --------------------------------------------------------------------------
      
      IF (.NOT. initialized) THEN
        IF (ip(1) < noutdia+nforcsdia) THEN
           CALL rexit("nout should be at least nout")
        END IF  
        initialized = .TRUE.
      END IF

! --------------------------------------------------------------------------
! from Conc to fdet, sdet, rdet, o2,...
! --------------------------------------------------------------------------
      DO I = 1, N
        Fdet(I) = Conc(     I)
        Sdet(I) = Conc(   N+I)
        Rdet(I) = Conc(2* N+I)
        O2(I)   = Conc(3 *N+I)
        NO3(I)  = Conc(4 *N+I)
        NO2(I)  = Conc(5 *N+I)
        NH3(I)  = Conc(6 *N+I)
        Mn(I)   = Conc(7 *N+I)  
        MnO2(I) = Conc(8 *N+I)  
        Fe(I)   = Conc(9 *N+I)
        FeOH3(I)= Conc(10*N+I)
        H2S(I)  = Conc(11*N+I)
        SO4(I)  = Conc(12*N+I)
        CH4(I)  = Conc(13*N+I)
        PO4(I)  = Conc(14*N+I)
        FeP(I)  = Conc(15*N+I)
        CaP(I)  = Conc(16*N+I)
        Pads(I) = Conc(17*N+I)
        FeS(I)  = Conc(18*N+I)  
        FeS2(I) = Conc(19*N+I)  
        S0(I)   = Conc(20*N+I)  
        DIC(I)  = Conc(21*N+I)
        ALK(I)  = Conc(22*N+I)
      END DO
      
! --------------------------------------------------------------------------
! Set forcing functions (Temperature, a vector)
! --------------------------------------------------------------------------
      Temperature    = Twater
      intTemp(1)     = Temperature(1)
      intTemp(2:N+1) = Temperature
      
! --------------------------------------------------------------------------
! Transport
! --------------------------------------------------------------------------
      FDETFLux = Carbonflux * pFast
      SDETflux = Carbonflux - FDETflux

      CALL FEMSDIAtransolid(FDETFLux, SDETFLux, RDETflux,                       &
     &                      MnO2flux, FeOH3flux, FePflux, CaPflux,              &
     &                      Padsflux, FeSflux,   FeS2flux, S0flux)      

      CALL FEMSDIAtranliquid(bwO2, bwNO3, bwNO2, bwNH3, bwMn, bwFe,             &
     &                      bwH2S, bwSO4, bwCH4, bwPO4)      
     
      CALL FEMSDIAtranDIC_ALK(bwDIC, bwALK) 
       

! --------------------------------------------------------------------------
! biogeochemistry and MPB dynamics
! --------------------------------------------------------------------------
      CALL FEMSDIAbiochem 
      CALL MPBFEMSDIAsimple 

! --------------------------------------------------------------------------
! output
! --------------------------------------------------------------------------
      CALL MPBFEMSDIAsimpleout
      CALL FEMSDIAout     
      CALL getoutFES(yout)  ! output in one long vector
       
! --------------------------------------------------------------------------
! from dfdet, dsdet, drdet, do2,... to dconc
! --------------------------------------------------------------------------
      DO I = 1, N
         dConc(     I) =  dFdet(I)
         dConc(   N+I) =  dSdet(I) 
         dConc(2 *N+I) =  dRdet(I) 
         dConc(3 *N+I) =  dO2(I)  
         dConc(4 *N+I) =  dNO3(I) 
         dConc(5 *N+I) =  dNO2(I) 
         dConc(6 *N+I) =  dNH3(I) 
         dConc(7 *N+I) =  dMn(I)     
         dConc(8 *N+I) =  dMnO2(I)   
         dConc(9 *N+I) =  dFe(I)
         dConc(10*N+I) =  dFeOH3(I)
         dConc(11*N+I) =  dH2S(I)
         dConc(12*N+I) =  dSO4(I)
         dConc(13*N+I) =  dCH4(I)
         dConc(14*N+I) =  dPO4(I)
         dConc(15*N+I) =  dFeP(I)
         dConc(16*N+I) =  dCaP(I)
         dConc(17*N+I) =  dPADS(I)
         dConc(18*N+I) =  dFeS(I)    
         dConc(19*N+I) =  dFeS2(I)   
         dConc(20*N+I) =  dS0(I)     
         dConc(21*N+I) =  dDIC(I)
         dConc(22*N+I) =  dALK(I)

      END DO 
      
      RETURN 
      END SUBROUTINE femsdiamod
