################################################################################
######            FEMSDIA: C, N, P, Fe, Mn, S, O2 diagenesis              ######
################################################################################

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Initial conditions
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIA_set_yini <- function(
     FDET = 1e2, SDET = 1e4, RDET = 1e5, O2 = 10, NO3 = 5, NO2 = 1, 
     NH3 = 1e3, Mn = 1e3, 
     MnO2 = 1e2, Fe = 1e4, FeOH3 = 1e3,  
     H2S = 1e2, SO4 = 1e3, CH4 = 1e2, 
     PO4 = 30,  FeP = 1e4, CaP = 1e2, Pads = 0,  
     FeS = 1e-6, FeS2 = 1e-6, S0 = 1e-6, 
     DIC = 1e4, ALK = 1e4, CALC = 1e2, ARAG = 1e2, Ca = 1e4,
  dynamicpH = FALSE)  
{  
  y1 <- c(FDET, SDET, RDET, O2, NO3, NO2, NH3, 
         Mn, MnO2, Fe, FeOH3, H2S, SO4, CH4, 
         PO4, FeP, CaP, Pads, 
         FeS, FeS2, S0, DIC, ALK
         )
  ns <-   length(.FEMSDIA$y_names)
  
  if (length(y1) != ns) 
    stop("state variable initial condition should be one number per species")
  
  names(y1) <- c("FDET", "SDET", "RDET", "O2", "NO3", "NO2", "NH3", 
                  "Mn", "MnO2", "Fe", "FeOH3", "H2S", "SO4", "CH4", 
                  "PO4", "FeP", "CaP", "Pads", 
                  "FeS", "FeS2", "S0", "DIC", "ALK")
  y1 <- y1[.FEMSDIA$y_names]  # in case the ordering changes
  
  if (dynamicpH){
     y1 <- c(y1, CALC, ARAG, Ca)
     ny1 <- c(ny1, "CALC", "ARAG", "Ca")
     ns <- ns + 3
  }   
   
   Yini <- as.vector(sapply(y1, FUN = function(x) rep(x, times = .FEMSDIA$N)))
   Yini
}

## -----------------------------------------------------------------------------

FEMSDIA_get_diffcoeff <- function(S = 30){
  
  tt <- 0:20
  DF <- diffcoeff(S = S, 
                  t = tt)      
  DF <- DF[, c("O2", "NO3", "NO2", "NH4",   
                         "Mn", "Fe", "HS", "SO4", "CH4", 
                         "H2PO4", "HCO3", "HCO3", 
                         "HCO3", "CO3", "Ca"  # for pH calculation   
                         )]*86400  #  from m2/s -> m2/d

  c_Db <- apply(DF, MARGIN = 2, FUN = function(x) coef(lm(x ~ tt)))
  c_Db
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Initialisation: 
##   grid generations (layers, bioturbation, irrigation), parameters
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

initFEMSDIA <- function (parms = list(), gridtype = 1, 
                        ff, times = NULL, 
                        Grid = NULL, porosity = NULL, bioturbation = NULL, 
                        irrigation = NULL, surface = NULL, 
                        diffusionfactor = NULL, dynamicbottomwater = NULL,
                        dynamicpH = FALSE)  {
  

  if (is.null(Grid))
    Grid  <- setup.grid.1D(x.up = 0, dx.1 = 0.0001, N = .FEMSDIA$N, L = 1)
  
  else {
    if (is.list (Grid)) {
      nms <- names(Grid)
      if (! "dx" %in%  nms)
          stop ("'Grid' should be a list containing 'dx' and 'dx.aux'")
      if (! "dx.aux" %in%  nms)
          stop ("'Grid' should be a list containing 'dx' and 'dx.aux'")
      if (length(Grid$dx.aux) != .FEMSDIA$N +1)
            stop ("Checking 'Grid': 'dx.aux' should be a vector of length ", .FEMSDIA$N+1)
      if (length(Grid$dx) != .FEMSDIA$N){
        stop ("Checking 'Grid': 'dx' should be a vector of length ", .FEMSDIA$N)
      }
    } else {
      if (length(Grid) != .FEMSDIA$N +1)
        stop ("Checking 'Grid': should be a vector of length ", .FEMSDIA$N+1)
      Grid <- list(dx.aux = Grid, mid = 0.5*(Grid[-1] + Grid[-(.FEMSDIA$N+1)]))
    }
  }   

## check parameter inputs
  Parms <- c(.FEMSDIA$parms, .PHDIA$parms)
  nms   <- names(Parms)
  Parms[(namc <- names(parms))] <- parms
  
  if (length(noNms <- namc[!namc %in% nms]) > 0)
    warning("unknown names in parms: ", paste(noNms, collapse = ", "))
  PP    <- unlist(Parms)
  Parms <- CreateAllMeanPars(Parms, ff, times)

## upper boundary condition for liquids - defaults to 0-gradient  
  bc <-  Parms[["BCupLiq"]]
  BCup <- c(O2  = bc, NO3 = bc, NO2 = bc,
            NH3 = bc,  Mn = bc,  Fe = bc,
            H2S = bc, SO4 = bc, CH4 = bc, PO4 = bc, 
            DIC = bc, ALK = bc, Ca = bc) 
  
  PP <- unlist(Parms)
  
  ii <- which(is.na(PP[c("O2bw", "NO3bw", "NO2bw",
                         "NH3bw", "Mnbw",  "Febw",
                         "H2Sbw", "SO4bw", "CH4bw", "PO4bw", 
                         "DICbw", "ALKbw", "Cabw")])) 
  if (length(ii))
      BCup[ii] <- 3   # 0-grdient

# lower boundary condition for liquids - defaults to 0-gradient  
  BCdown <- c(O2  = 3, NO3 = 3, NO2 = 3,
              NH3 = 3,  Mn = 3,  Fe = 3,
              H2S = 3, SO4 = 3, CH4 = 3, PO4 = 3, 
              DIC = 3, ALK = 3,  Ca = 3) 
  if (Parms[["BCdownLiq"]] != 3) { # not the default
    
    ii <- which(is.na(PP[c("O2dw", "NO3dw", "NO2dw",
                           "NH3dw", "Mndw",  "Fedw",
                           "H2Sdw", "SO4dw", "CH4dw", "PO4dw", 
                           "DICdw", "ALKdw",  "Cadw")])) 
    if (length(ii))
      BCdown[ii] <- Parms[["BCdownLiq"]]
    else
      stop("some deep water concentrations should have a value ", 
           "if BCdownLiq is 'flux' (1) or 'concentration' (2)")
  }
  
  Parms[which(is.na(Parms))] <- 0
  
  if (! is.null(surface)) {
    Aint <- CheckProfile (surface, "surface", interface = TRUE)$int
  
  }  else {
    if (gridtype == 1)                        # cartesian
      Aint <- rep(1, .FEMSDIA$N+1)
    else if (gridtype == 2)                   # cylindrical
      Aint <- rev(2*pi*Grid$x.int)
    else if (gridtype == 3)                   # spherical
     Aint <- rev(pi*(Grid$x.int)^2)
  }

  # get diffusion coefficients: a and b-values as a function of temperature
  # DC = a_DF + b_DF*T, in m2/day, for O2, NO3, NO2, NH4, HCO3,  
  #     Mn, Fe, HS, SO4, CH4, H2PO4, HCO3
  # first row: DF at 0dg c, second row: temperature dependence coefficient
  
   DF <- FEMSDIA_get_diffcoeff(S = Parms[["Swater"]]) 
   
   Parms    <- c(Parms, DF[1,], DF[2, ])
   Parms    <- c(Parms, dens = sw_dens(S = Parms[["Swater"]], 
                                       t = Parms[["Twater"]]))
  
# porosity gradients
  exp.profile <- function(x, y.0, y.inf, x.att = 1, L = 0)
           return(y.inf + (y.0 - y.inf) * exp(-pmax(0, x-L)/x.att))

# Bioturbation profile
  if (is.null(bioturbation)) 
    bioturbation <- setup.prop.1D(func = exp.profile,
                           grid = Grid,
                           y.0 = Parms[["biot"]], y.inf = 0.,
                           L = Parms[["biotdepth"]], x.att = Parms[["biotatt"]])
  else
    bioturbation <- CheckProfile (bioturbation, "bioturbation", interface = TRUE)

  Db <- bioturbation$int

# Irrigation profile  
  if (is.null(irrigation))
    irrigation <- setup.prop.1D(func = exp.profile,
                         grid = Grid,
                         y.0 = Parms[["irr"]], y.inf = 0.,
                         L = Parms[["irrdepth"]], x.att = Parms[["irratt"]])
  else
    irrigation <- CheckProfile(irrigation,"irrigation", interface = FALSE)
  
  Dirr <- irrigation$mid

# porosity profile
  if (is.null(porosity))
    porGrid <- setup.prop.1D(func = exp.profile,
                         grid = Grid,
                         y.0 = Parms[["por0"]], y.inf = Parms[["pordeep"]], L = 0,
                         x.att = Parms[["porcoeff"]])

  else 
    porGrid <- CheckProfile (porosity, "porosity", interface = TRUE)

# Long-distance reactions - with oxygen in surface layer
  if (Parms[["rSurfH2Sox"]] > 0 | Parms[["rSurfCH4ox"]] > 0 )
    distreact <- setup.prop.1D(func = exp.profile,
                               grid = Grid,
                               y.0 = 1, y.inf = 0.,
                               L = Parms[["ODUoxdepth"]], x.att = Parms[["ODUoxatt"]])$mid 
  else 
    distreact <- rep(0, .FEMSDIA$N)

# factor to multiply with the diffusion to estimate effective diffusion  
  if (is.null(diffusionfactor)){
    formationtype <- Parms[["formationtype"]]
    if (formationtype == 1) #sand
      diffusionfactor <- porGrid$int
    else if (formationtype == 2) #mud/fine sand
      diffusionfactor <- porGrid$int^2
    else   #general
      diffusionfactor <- 1/(1-log(porGrid$int^2))
  } else
    diffusionfactor <- CheckProfile (diffusionfactor, "diffusionfactor", interface = TRUE)$int
 
  # remove parameters that became forcing functions or used to generate profiles
  
  toremove <- c("biot", "biotdepth", "biotatt", 
                "irr", "irrdepth", "irratt",
                "ODUoxdepth", "ODUoxatt", 
                "por0", "pordeep", "porcoeff", "formationtype",  
                "Cflux", "MnO2flux", "FeOH3flux", "RDETflux", 
                "DBL", "flow", "w", "pFast", 
                "BCdownLiq", "BCupLiq", 
                "MPBprod", "gasflux", 
                "Hwater", "Twater", "Swater", 
                "O2bw", "NO3bw", "NO2bw", "NH3bw", "DICbw", 
                "Mnbw", "Febw", "H2Sbw", "SO4bw", "CH4bw", 
                "PO4bw", "ALKbw") 
               
    toremove <- c(toremove, "CALCflux", "ARAGflux", "Cabw")   

   parms <- unlist(Parms[-which(nms %in%toremove)])
   parms <- c(parms, BCup, BCdown)
#   cat(names(parms),"\n")   TO CHECK THE PARAMETERS PASSED TO R
# parameters to pass to model DLL
  initpar <- c(parms, Grid$dx, Grid$dx.aux, Grid$x.mid, Aint, porGrid$mid,  
              porGrid$int, diffusionfactor, Db, Dirr, distreact)
  

  list(initpar = initpar, other = Parms[c("biot", "irr")], parms = PP, 
       Grid = Grid, porGrid = porGrid, Isirr = sum(Dirr) > 0, 
       Dirr = Dirr, bioturbationGrid = bioturbation, 
       diffcoeff = DF,   
       depth = Grid$x.mid, dx = Grid$dx, porosity = porGrid$mid, porint = porGrid$int, 
       bioturbation = bioturbation$mid, bioturbint = bioturbation$int, 
       irrigation = Dirr, diffusionfactor = diffusionfactor, Aint = Aint,
       DistReact = distreact, isDistReact = (max(distreact) > 0))

}
