################################################################################
######            FEMSDIA: C, N, P, Fe, Mn, S, O2 diagenesis              ######
################################################################################

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## solve the dynamic condition - main function
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIA_run_dyna <- function (parms = list(), times = 0:365, spinup = NULL, 
   yini = NULL, gridtype = 1, Grid = NULL, porosity = NULL, 
   bioturbation = NULL, irrigation = NULL, surface = NULL,  
   diffusionfactor = NULL, 
   dynamicpH = FALSE, dynamicbottomwater = FALSE, 
   f_Cflux  = NULL,   f_pFast  = NULL,  f_RDETflux = NULL,  
   f_MnO2flux = NULL, f_FeOH3flux = NULL, 
   f_O2bw   = NULL,   f_NO3bw  = NULL,  f_NO2bw  = NULL, 
   f_NH3bw  = NULL,   f_Mnbw   = NULL,  f_Febw   = NULL,    
   f_H2Sbw  = NULL,  f_SO4bw  = NULL,  
   f_CH4bw  = NULL,   f_PO4bw  = NULL,  
   f_DICbw  = NULL,   f_ALKbw  = NULL,   
   f_DBL    = NULL,    f_flow  = NULL,  
   f_w      = NULL,   
   f_MPBprod = NULL,  f_gasflux = NULL, 
   f_Hwater = NULL,   f_Twater = NULL, f_Swater  = NULL,  
   f_Bioturbationfactor = NULL,  f_Irrigationfactor = NULL,  
   f_CALCflux = NULL, f_ARAGflux = NULL,  f_Cabw = NULL,
   verbose = FALSE, ...)  {

  
  
  ff <- list(f_Cflux     = f_Cflux,   f_pFast   = f_pFast,    
             f_RDETflux  = f_RDETflux, 
             f_MnO2flux  = f_MnO2flux, 
             f_FeOH3flux = f_FeOH3flux, 
             f_O2bw      = f_O2bw,    f_NO3bw   = f_NO3bw,  f_NO2bw = f_NO2bw, 
             f_NH3bw     = f_NH3bw,   f_Mnbw    = f_Mnbw,   
             f_Febw      = f_Febw,    f_H2Sbw   = f_H2Sbw,  f_SO4bw = f_SO4bw,  
             f_CH4bw     = f_CH4bw,   f_PO4bw   = f_PO4bw,    
             f_DICbw     = f_DICbw,   f_ALKbw   = f_ALKbw,   
             f_DBL       = f_DBL,     f_flow    = f_flow,   f_w     = f_w,       
             f_MPBprod   = f_MPBprod, f_gasflux = f_gasflux, 
             f_Hwater    = f_Hwater,  f_Twater  = f_Twater, f_Swater = f_Swater,  
             f_Bioturbationfactor = f_Bioturbationfactor,  
             f_Irrigationfactor   = f_Irrigationfactor,
             f_CALCflux  = f_CALCflux, f_ARAGflux = f_ARAGflux, 
             f_Cabw      = f_Cabw)

  dyn <- FEMSDIAdyna_Full (parms = parms, 
     times = times, spinup = spinup, yini = yini, 
     gridtype = gridtype, Grid = Grid, porosity = porosity, 
     bioturbation = bioturbation, irrigation = irrigation, surface = surface, 
     diffusionfactor = diffusionfactor, 
     ff = ff, verbose = verbose, 
     dynamicbottomwater = dynamicbottomwater,
     dynamicpH = dynamicpH, ...) 
  
  attr(dyn, "units")  <- .FEMSDIA$outunits
  
  class(dyn) <- unique(c("FEMSDIAdyn", class(dyn)))
  dyn
}  

## -----------------------------------------------------------------------------
## general dynamic function
## -----------------------------------------------------------------------------

FEMSDIAdyna_Full <- function (parms = list(), times = 0:365, spinup = NULL, yini = NULL, 
   gridtype = 1, Grid = NULL, porosity = NULL, bioturbation = NULL, 
   dynamicbottomwater = FALSE,
   irrigation = NULL, surface = NULL, diffusionfactor = NULL, model = 1, 
   ff = ff,
   verbose = FALSE, 
   dynamicpH = FALSE, ...)  {
  
   ff <- checkAllForcings(ff)
     
   initforc <- "initfemsforc"
   N <- .FEMSDIA$N
   
   if (!dynamicpH){
     nspec    <- length(.FEMSDIA$y_names)
     ynames   <- .FEMSDIA$y_names
     nout     <- .FEMSDIA$nout
     outnames <- .FEMSDIA$outnames
     
     initfunc <- "initfemsdia"
     func     <- "femsdiamod"
   } else {
     nspec    <- length(.FEMSDIA$y_names) + length(.PHDIA$y_names)
     ynames   <- c(.FEMSDIA$y_names,.PHDIA$y_names) 
     nout     <- .FEMSDIA$nout + .PHDIA$nout
     outnames <- c(.FEMSDIA$outnames, .PHDIA$outnames)
     
     initfunc <- "initphdia"
     func     <- "phdiamod"
   }
     
   if (is.null(spinup)) Times <- times else Times <- spinup

   iniP <- initFEMSDIA(parms, gridtype = gridtype, ff = ff,
                      times = Times, Grid = Grid, 
                      porosity = porosity, bioturbation = bioturbation, 
                      irrigation = irrigation, surface = surface, 
                      diffusionfactor = diffusionfactor, 
                      dynamicbottomwater = dynamicbottomwater,
                      dynamicpH = dynamicpH)
  
    if (is.null(yini)) {  # try finding the steady state
       STD <- FEMSDIAsteady_full(parms, gridtype = gridtype, ff = ff,
                      times = Times, Grid = Grid, 
                      porosity = porosity,  bioturbation = bioturbation, 
                      irrigation = irrigation, surface = surface, 
                      diffusionfactor = diffusionfactor, 
                      dynamicbottomwater = dynamicbottomwater,
                      dynamicpH = dynamicpH, verbose = verbose, iniP = iniP)
       yini <- STD$y
    }   

    yini <- checkYini(yini, dynamicpH, dynamicbottomwater)
    
    initpar = unlist(iniP$initpar)
  
    band   <- ifelse(iniP$isDistReact | dynamicbottomwater, 0, 1)
  
    if (! dynamicbottomwater) {
      func <-"femsdiamod"
      N <- .FEMSDIA$N
    } else {
      func <- "femsdiamodbw"
      N    <- .FEMSDIA$N + 1  
    }
    if (dynamicpH) func <- "phdiamod"
  
  #lrw <- 170000
  #if(iniP$isDistReact | dynamicpH) lrw <- 500000
  
    lrw <- 300000 # MTM
    if (iniP$isDistReact | dynamicpH) lrw <- 600000 # MTM
    

    ZZ <- NULL
    is.spinup <- ! is.null(spinup)
    if (is.spinup)
      is.spinup <- (length(spinup) > 1)
  
    if (is.spinup) {
      forcings <- createForcings(iniP, spinup, ff = ff)
      
      ZZ <- c(ZZ, capture.output(suppressWarnings(   
        DYN <- ode.1D(y = as.double(yini), times = spinup, 
                   func = func, initfunc = initfunc, initforc = initforc,
                   dllname = "FEMSDIA", 
                   initpar = initpar, forcings = forcings,  
                   names = ynames, nout = nout, outnames = outnames,
                   method = "lsodes", lrw = lrw, bandwidth = band,
                   nspec = nspec, ...)
      )))
      yini <- DYN[nrow(DYN),2:(nspec*N+1)]
    }

    forcings <- createForcings(iniP, times, ff)
      
    ZZ <- c(ZZ, capture.output(suppressWarnings(   
    DYN <- ode.1D(y = as.double(yini), times = times, 
                  func = func, initfunc = initfunc, initforc = initforc, 
                  dllname = "FEMSDIA", 
                  initpar = initpar, forcings = forcings, 
                  names = ynames, nout = nout, outnames = outnames,
                  method = "lsodes", lrw = lrw, bandwidth = band,
                  nspec = nspec, ...)
    )))
    colnames(DYN)[2:(nspec*N+1)] <- as.vector(
                    sapply(ynames, 
                           FUN = function(x) rep(x, times = N)))
    if (dynamicbottomwater) {
      cn <- colnames(DYN)
      cn[seq(2, by = N, length.out = nspec)] <- paste(ynames, "_bw", sep ="")
      colnames(DYN) <- cn
    }
  
    attr(DYN, "depth")               <- iniP$depth
    attr(DYN, "dx")                  <- iniP$dx
    attr(DYN, "Aint")                <- iniP$Aint
    attr(DYN, "Grid")                <- iniP$Grid
    attr(DYN, "porosity")            <- iniP$porosity
    attr(DYN, "porint")              <- iniP$porint
    attr(DYN, "bioturbation")        <- iniP$bioturbation
    attr(DYN, "bioturbint")          <- iniP$bioturbint
    attr(DYN, "irrigation")          <- iniP$irrigation
    attr(DYN, "warnings")            <- ZZ
    attr(DYN, "parms")               <- iniP$parms
    attr(DYN, "diffcoeff")           <- iniP$diffcoeff
    attr(DYN, "diffusionfactor")     <- iniP$diffusionfactor
    attr(DYN, "dynamicpH")           <- dynamicpH
    attr(DYN, "dynamicbottomwater")  <- dynamicbottomwater
    attr(DYN, "model")               <- "FEMSDIA_run_dyna"

    class(DYN) <- unique(c("FEMSDIAdyn", class(DYN)))

    ###################### CHANGE THIS -> DYNAMIC RUN #########################
#    if (calcpH) {
#      pH  <- FEMSDIA_get_pH(DYN)
    
#      att <- attributes(DYN)  
#      cl  <- class(DYN)
 #     lv1 <- att$lengthvar[1]  
  #    i1  <- 1:(lv1+1)
#      DYN <- cbind(DYN[ ,i1], pH = pH, DYN[ ,-i1])
#      att$dim <- dim(DYN)
#      att$nspec  <- att$nspec+1
#      att$ynames <- c(att$ynames, "pH")
#      att$lengthvar[1] <- lv1 + N
#      attributes(DYN) <- c(attributes(DYN)[1:2], 
#                           att[-(1:2)], 
#                           attributes(pH)[-(1:2)]) 
 #     class(DYN) <- cl
#    }
  
   return(DYN)
} 

