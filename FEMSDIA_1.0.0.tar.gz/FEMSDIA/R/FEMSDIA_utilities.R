######################################################################################
######              FEMSDIA: C, N, P, Fe, S, O2 diagenesis                      ######
######################################################################################
## --------------------------------------------------------------------------------------------------
## Checks a profile and returns a list with int and mid.
## --------------------------------------------------------------------------------------------------

CheckProfile <- function(prof, Name, interface = TRUE) {  
  if (is.null(prof)) prof <- 0 
  nms <- names(prof)
  if (is.list (prof)) {
    if (! "int" %in%  nms)
      stop (Name, " should be a list containing 'int' and 'mid'")
    if (! "mid" %in%  nms)
      stop (Name, " should be a list containing 'int' and 'mid'")
    if (length(prof$int) != .FEMSDIA$N +1)
      stop ("Checking", Name, ": 'int' should be a vector of length ", .FEMSDIA$N +1)
    if (length(prof$mid) != .FEMSDIA$N )
      stop ("Checking", Name, ": 'mid' should be a vector of length ", .FEMSDIA$N )
    return(prof)
  }
  if (interface) {
    if (length(prof) == 1) prof <- rep(prof, .FEMSDIA$N+1)
    if (length(prof) != .FEMSDIA$N+1)
      stop ("Checking", Name, ": 'should be a vector of length ", .FEMSDIA$N +1)
    new <- list(int = prof, mid = 0.5*(prof[-1] + prof[-(.FEMSDIA$N+1)]))
  } else {
    if (length(prof) == 1) prof <- rep(prof, .FEMSDIA$N)
    if (length(prof) != .FEMSDIA$N)
      stop ("Checking", Name, ": 'should be a vector of length ", .FEMSDIA$N)
    new <- list(mid = prof, ind = c(prof[1], 0.5*(prof[-1] + prof[-(.FEMSDIA$N)]),prof[.FEMSDIA$N]))
  }  
  return (new)
}  

