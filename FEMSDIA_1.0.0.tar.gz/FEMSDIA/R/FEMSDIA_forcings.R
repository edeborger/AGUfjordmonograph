################################################################################
######            FEMSDIA: C, N, P, Fe, Mn, S, O2 diagenesis              ######
################################################################################

## -----------------------------------------------------------------------------
## Check the forcing functions, calculate the average over "times" 
## and update the PARAMETER vector
## -----------------------------------------------------------------------------

CreateMeanPars <- function(Parms, name, forc, times) {
  
  if (is.null(forc$data))
    return(Parms)
  
  else if (is.null(times))
    Parms[[name]] <- mean(forc$data[,2])
  
  else if (length(times) > 1) {
    Data <- as.matrix(forc$data)
    ii <- which(Data[,1] >= min(times) & 
                Data[,1] <= max(times))
    
    if (!length(ii)) 
      stop("cannot run model: forcing data set for", name, 
        "is not compatible with (spinup) times")
    
    if (length(ii) == 1)
      res <- Data[ii,2]
    
    else 
      res <- approx(x = Data[ ,1], y = Data[ ,2], xout = times)$y
    
    Parms[[name]] <- mean(res)
  } else 
    Parms[[name]] <- approx(x    = forc$data[,1], 
                            y    = forc$data[,2], 
                            xout = times, 
                            rule = 2)$y
  Parms 
}

## -----------------------------------------------------------------------------
## Sets all parameters based on the forcing functions
## -----------------------------------------------------------------------------

CreateAllMeanPars <- function(Parms, ff, times){
    
  # parameters need to be set based on forcing functions (if present)  
   Parms <- CreateMeanPars (Parms, "Cflux"     , ff$f_Cflux     , times) 
   Parms <- CreateMeanPars (Parms, "pFast"     , ff$f_pFast     , times) 
   Parms <- CreateMeanPars (Parms, "RDETflux"  , ff$f_RDETflux  , times) 
   Parms <- CreateMeanPars (Parms, 'MnO2flux'  , ff$f_MnO2flux  , times) 
   Parms <- CreateMeanPars (Parms, "FeOH3flux" , ff$f_FeOH3flux , times) 
   Parms <- CreateMeanPars (Parms, "DBL"       , ff$f_DBL       , times) 
   Parms <- CreateMeanPars (Parms, 'flow  '    , ff$f_flow      , times) 
   Parms <- CreateMeanPars (Parms, "w"         , ff$f_w         , times) 
   Parms <- CreateMeanPars (Parms, "biot"      , 
                            ff$f_Bioturbationfactor             , times) 
   Parms <- CreateMeanPars (Parms, "irr"       , 
                            ff$f_Irrigationfactor               , times) 
   
   Parms <- CreateMeanPars (Parms, "O2bw"      , ff$f_O2bw      , times) 
   Parms <- CreateMeanPars (Parms, "NO3bw"     , ff$f_NO3bw     , times) 
   Parms <- CreateMeanPars (Parms, "NO2bw"     , ff$f_NO2bw     , times) 
   Parms <- CreateMeanPars (Parms, "NH3bw"     , ff$f_NH3bw     , times) 
   Parms <- CreateMeanPars (Parms, 'Mnbw'      , ff$f_Mnbw      , times) 
   Parms <- CreateMeanPars (Parms, "Febw"      , ff$f_Febw      , times) 
   Parms <- CreateMeanPars (Parms, "H2Sbw"     , ff$f_H2Sbw     , times) 
   Parms <- CreateMeanPars (Parms, "SO4bw"     , ff$f_SO4bw     , times) 
   Parms <- CreateMeanPars (Parms, "CH4bw"     , ff$f_CH4bw     , times) 
   Parms <- CreateMeanPars (Parms, "PO4bw"     , ff$f_PO4bw     , times) 
   Parms <- CreateMeanPars (Parms, "DICbw"     , ff$f_DICbw     , times) 
   Parms <- CreateMeanPars (Parms, "ALKbw"     , ff$f_ALKbw     , times) 
   Parms <- CreateMeanPars (Parms, "MPBprod"   , ff$f_MPBprod   , times)   
   Parms <- CreateMeanPars (Parms, "gasflux"   , ff$f_gasflux   , times) 
   Parms <- CreateMeanPars (Parms, "Hwater"    , ff$f_Hwater    , times)
   Parms <- CreateMeanPars (Parms, "Twater"    , ff$f_Twater    , times) 
   Parms <- CreateMeanPars (Parms, "Swater"    , ff$f_Swater    , times) 
  
#  if (dynamicpH) 
   Parms <- CreateMeanPars (Parms, "CALCflux",  ff$f_CALCflux  , times) 
   Parms <- CreateMeanPars (Parms, "ARAGflux" , ff$f_ARAGflux  , times) 
   Parms <- CreateMeanPars (Parms, "Cabw"     , ff$f_Cabw      , times) 

   Parms  
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Checks a forcing function DECLARATION
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

checkforcs <- function(forc, name) {
  formal <- list(data = NULL, amp = 0, period = 365, 
                 phase = 0, pow = 1, min = 0)
  
  if (is.null(forc)) 
    return(formal)

  if (is.data.frame(forc) | is.matrix(forc))
    forc <- list(data = forc)
  
  if (! is.list(forc))
    stop ("forcing ", name, " should be a list or NULL")
  
  nms    <- names(formal)
  formal[(namc <- names(forc))] <- forc
  
  if (length(noNms <- namc[!namc %in% nms]) > 0)
    warning("unknown names in forcing ",name, ": ", paste(noNms, collapse = ", "))

  NN       <- c("amp", "period", "phase", "pow", "min")
  formal$n <- max(unlist(lapply(formal[NN], FUN = length)))
  
  if (formal$n > 1) 
    for (i in NN) formal[[i]] <- rep(formal[[i]], length.out = formal$n)
  
  return(formal)
}

## -----------------------------------------------------------------------------
## Check all forcing function declarations
## -----------------------------------------------------------------------------

checkAllForcings <- function(ff){
  
  ff$f_Cflux      <- checkforcs (ff$f_Cflux,         "f_Cflux")
  ff$f_pFast      <- checkforcs (ff$f_pFast,         "f_pFast")
  ff$f_RDETflux   <- checkforcs (ff$f_RDETflux,   "f_RDETflux")
  ff$f_MnO2flux   <- checkforcs (ff$f_MnO2flux,   "f_MnO2flux")   
  ff$f_FeOH3flux  <- checkforcs (ff$f_FeOH3flux, "f_FeOH3flux")
  ff$f_DBL        <- checkforcs (ff$f_DBL,             "f_DBL")
  ff$f_flow       <- checkforcs (ff$f_flow,           "f_flow")  
  
  ff$f_O2bw       <- checkforcs (ff$f_O2bw,           "f_O2bw")
  ff$f_NO3bw      <- checkforcs (ff$f_NO3bw,         "f_NO3bw")
  ff$f_NO2bw      <- checkforcs (ff$f_NO2bw,         "f_NO2bw")
  ff$f_NH3bw      <- checkforcs (ff$f_NH3bw,         "f_NH3bw")
  ff$f_Mnbw       <- checkforcs (ff$f_Mnbw,           "f_Mnbw")  
  ff$f_Febw       <- checkforcs (ff$f_Febw,           "f_Febw")
  ff$f_H2Sbw      <- checkforcs (ff$f_H2Sbw,         "f_H2Sbw")
  ff$f_SO4bw      <- checkforcs (ff$f_SO4bw,         "f_SO4bw")
  ff$f_CH4bw      <- checkforcs (ff$f_CH4bw,         "f_CH4bw")
  ff$f_PO4bw      <- checkforcs (ff$f_PO4bw,         "f_PO4bw")
  ff$f_DICbw      <- checkforcs (ff$f_DICbw,         "f_DICbw")
  ff$f_ALKbw      <- checkforcs (ff$f_ALKbw,         "f_ALKbw")
  ff$f_w          <- checkforcs (ff$f_w,                 "f_w")
  ff$f_Bioturbationfactor <- checkforcs(ff$f_Bioturbationfactor,           
                                      "f_Bioturbationfactor")
  ff$f_Irrigationfactor   <- checkforcs(ff$f_Irrigationfactor, 
                                      "f_Irrigationfactor")
  ff$f_MPBprod    <- checkforcs (ff$f_MPBprod,     "f_MPBprod")
  ff$f_gasflux    <- checkforcs (ff$f_gasflux,     "f_gasflux")
  ff$f_Hwater     <- checkforcs (ff$f_Hwater,       "f_Hwater")
  ff$f_Twater     <- checkforcs (ff$f_Twater,       "f_Twater")
  ff$f_Swater     <- checkforcs (ff$f_Swater,       "f_Swater")

#  if (dynamicpH)
  ff$f_CALCflux  <- checkforcs (ff$f_CALCflux,    "f_CALCflux")
  ff$f_ARAGflux  <- checkforcs (ff$f_ARAGflux ,   "f_ARAGflux")
  ff$f_Cabw      <- checkforcs (ff$f_Cabw,            "f_Cabw")
  
  return(ff)  
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Create forcing function time series DATA
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

Setforcings <- function(Parms, name, forc, times, fac = 1){
  if (is.nan(fac) | is.infinite(fac)) fac <- 1
  
  if (is.null(forc$data)) {
    
    meanforc <- Parms[[name]]*fac
    
    if(forc$amp[1] == 0 | forc$pow[1] == 0)
      forcings <- cbind(range(times), meanforc)
    
    else {
      Val <- pmax(forc$min[1], 
                  meanforc*(1 + forc$amp[1]*sin((times - forc$phase[1])
                               / forc$period[1]*2*pi))^forc$pow[1])
      if (forc$n >1)
        for (i in  2:forc$n) 
          Val <- Val + pmax(forc$min[i], 
                            meanforc*(1 + forc$amp[i]*sin((times - forc$phase[i]) 
                              / forc$period[i]*2*pi))^forc$pow[i])
          
       Val <- meanforc / mean(Val) * Val
       forcings <- cbind(times, Val)
    }
    
  } else {
    
    forcings     <-  as.matrix(forc$data)
    
    forcings[,2] <- forcings[,2]*fac
  }
  names(forcings  ) <- name
  return(forcings)
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Creates all forcing function time series data
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

createForcings <- function(iniP, times, ff){

    forcings <- list()
    
    forcings[[1]]  <- Setforcings (iniP$parms, "Cflux",     
                                   ff$f_Cflux,     times, fac = 1)
    
    forcings[[2]]  <- Setforcings (iniP$parms, "pFast", 
                                   ff$f_pFast,     times, fac = 1)
    
    forcings[[3]]  <- Setforcings (iniP$parms, "RDETflux", 
                                   ff$f_RDETflux, times, fac = 1)
    
    forcings[[4]]  <- Setforcings (iniP$parms, "MnO2flux", 
                                   ff$f_MnO2flux,  times, fac = 1) 
    
    forcings[[5]]  <- Setforcings (iniP$parms, "FeOH3flux", 
                                   ff$f_FeOH3flux, times, fac = 1)
    
    forcings[[6]]  <- Setforcings (iniP$parms, "DBL",   
                                   ff$f_DBL,       times, fac = 1)
    
    forcings[[7]]  <- Setforcings (iniP$parms, "flow",  
                                   ff$f_flow,      times, fac = 1) 
    
    forcings[[8]]  <- Setforcings (iniP$parms, "w",     
                                   ff$f_w,         times, fac = 1)
    
    forcings[[9]]  <- Setforcings (iniP$other, "biot",  
                                   ff$f_Bioturbationfactor,   times,   
                                   fac = 1/iniP$other[["biot"]])
    
    forcings[[10]]  <- Setforcings (iniP$other, "irr",   
                                   ff$f_Irrigationfactor,     times,   
                                   fac = 1/iniP$other[["irr"]])
    
    forcings[[11]] <- Setforcings (iniP$parms, "O2bw",   
                                   ff$f_O2bw,      times, fac = 1)
    
    forcings[[12]] <- Setforcings (iniP$parms, "NO3bw", 
                                   ff$f_NO3bw,     times, fac = 1)
    
    forcings[[13]] <- Setforcings (iniP$parms, "NO2bw", 
                                   ff$f_NO2bw,     times, fac = 1)
    
    forcings[[14]] <- Setforcings (iniP$parms, "NH3bw", 
                                   ff$f_NH3bw,     times, fac = 1)
    
    forcings[[15]] <- Setforcings (iniP$parms, "Mnbw",  
                                   ff$f_Mnbw,      times, fac = 1) 
    
    forcings[[16]] <- Setforcings (iniP$parms, "Febw",  
                                   ff$f_Febw,      times, fac = 1)
    
    forcings[[17]] <- Setforcings (iniP$parms, "H2Sbw", 
                                   ff$f_H2Sbw,     times, fac = 1)
    
    forcings[[18]] <- Setforcings (iniP$parms, "SO4bw", 
                                   ff$f_SO4bw,     times, fac = 1)
    
    forcings[[19]] <- Setforcings (iniP$parms, "CH4bw", 
                                   ff$f_CH4bw,     times, fac = 1)
    
    forcings[[20]] <- Setforcings (iniP$parms, "PO4bw", 
                                   ff$f_PO4bw,     times, fac = 1)
    
    forcings[[21]] <- Setforcings (iniP$parms, "DICbw", 
                                   ff$f_DICbw,     times, fac = 1)
    
    forcings[[22]] <- Setforcings (iniP$parms, "ALKbw", 
                                   ff$f_ALKbw,     times, fac = 1)
    
    forcings[[23]] <- Setforcings (iniP$parms, "gasflux", 
                                   ff$f_gasflux,   times, fac = 1)
    
    forcings[[24]] <- Setforcings (iniP$parms, "MPBprod", 
                                   ff$f_MPBprod,   times, fac = 1)
    
    forcings[[25]] <- Setforcings (iniP$parms, "Hwater",   
                                   ff$f_Hwater,    times, fac = 1)
    
    forcings[[26]] <- Setforcings (iniP$parms, "Twater", 
                                   ff$f_Twater,    times, fac = 1)
    
    forcings[[27]] <- Setforcings (iniP$parms, "Swater", 
                                   ff$f_Swater,    times, fac = 1)
    
#    if (dynamicpH){
    forcings[[28]] <- Setforcings (iniP$parms, "CALCflux", 
                                   ff$f_CALCflux, times, fac = 1)
    
    forcings[[29]] <- Setforcings (iniP$parms, "ARAGflux",  
                                   ff$f_ARAGflux,  times, fac = 1)
    
    forcings[[30]] <- Setforcings (iniP$parms, "Cabw",      
                                   ff$f_Cabw,      times, fac = 1)
    names(forcings) <- c(
     "Cflux" , "pFast", "RDETflux", "MnO2flux", "FeOH3flux", "DBL",
     "flow"  , "w", "Bioturbationfactor", "Irrigationfactor", 
      "O2bw" , "NO3bw", "NO2bw", "NH3bw", "Mnbw", "Febw",  "H2Sbw", 
      "SO4bw", "CH4bw", "PO4bw", "DICbw", "ALKbw", 
      "gasflux", "MPBprod", "Hwater", "Twater",  "Swater",  
      "CALCflux", "ARAGflux", "Cabw")    
    return(forcings)
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Create forcing function vector for STEADY-STATE
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

steadyForcings <- function(iniP){
    forcings <- c(as.double(iniP$parms["Cflux"]), 
                  as.double(iniP$parms["pFast"]),
                  as.double(iniP$parms["RDETflux"]),   
                  as.double(iniP$parms['MnO2flux']), 
                  as.double(iniP$parms["FeOH3flux"]), 
                  as.double(iniP$parms["DBL"]), 
                  as.double(iniP$parms["flow"]),      
                  as.double(iniP$parms["w"]),
                  as.double(1.),            # bioturbation: relative to profile
                  as.double(1.),            # irrigation: relative to profile
                  as.double(iniP$parms["O2bw"]),
                  as.double(iniP$parms["NO3bw"]), 
                  as.double(iniP$parms["NO2bw"]), 
                  as.double(iniP$parms["NH3bw"]), 
                  as.double(iniP$parms['Mnbw']),      
                  as.double(iniP$parms["Febw"]), 
                  as.double(iniP$parms["H2Sbw"]), 
                  as.double(iniP$parms["SO4bw"]), 
                  as.double(iniP$parms["CH4bw"]), 
                  as.double(iniP$parms["PO4bw"]), 
                  as.double(iniP$parms["DICbw"]),
                  as.double(iniP$parms["ALKbw"]), 
                  as.double(iniP$parms["gasflux"]), 
                  as.double(iniP$parms["MPBprod"]), 
                  as.double(iniP$parms["Hwater"]),                 
                  as.double(iniP$parms["Twater"]),  
                  as.double(iniP$parms["Swater"]), 
                  as.double(iniP$parms["CALCflux"]), 
                  as.double(iniP$parms["ARAGflux"]), 
                  as.double(iniP$parms["Cabw"])
      ) 
    return(forcings)
}
