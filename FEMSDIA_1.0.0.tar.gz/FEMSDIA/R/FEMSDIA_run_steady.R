################################################################################
######            FEMSDIA: C, N, P, Fe, Mn, S, O2 diagenesis              ######
################################################################################

## -----------------------------------------------------------------------------

  checkYini <- function(yini, dynamicpH, dynamicbottomwater = FALSE){
  
  if (is.null (yini)) return(NULL)
  N <- .FEMSDIA$N
  if (dynamicbottomwater) N <- N+1
  
  nspec    <- length(.FEMSDIA$y_names)
  
  if (dynamicpH)
      nspec <- nspec + length(.PHDIA$y_names)
  
  if (inherits(yini, "FEMSDIAdyn")){
     if (dynamicpH ){
       if (!attributes(yini)$dynamicpH)
         stop ("cannot use 'yini': dynamicpH is TRUE,", 
         "but object was created with dynamicpH = FALSE")
     }
     yini   <- yini[nrow(yini), 2:(nspec*N+1)]
  } else if (inherits(yini, "FEMSDIAstd")){
     if (dynamicpH ){
       if (!yini$dynamicpH)
         stop ("cannot use 'yini': dynamicpH is TRUE,", 
         "but object was created with dynamicpH = FALSE")
     }
     yini   <- as.vector(yini$y)[1:(nspec*N)]
  } else if (is.matrix(yini)) {
    yini <- as.vector(yini)[1:(nspec*N)]
  }
  
  if (length(yini) != nspec*N)
    stop ("'yini' not of correct length, should be ", nspec*N)
  yini
 }

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## solve the steady-state condition - main function
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIA_run_steady <- function (
                         parms              = list(), 
                         yini               = NULL, 
                         gridtype           = 1, Grid = NULL,  
                         porosity           = NULL, 
                         bioturbation       = NULL, 
                         irrigation         = NULL, 
                         surface            = NULL,      
                         diffusionfactor    = NULL, 
                         dynamicpH          = FALSE, 
                         dynamicbottomwater = FALSE, 
                         method             = c("mixed", "runsteady", "stode", "stodes"), 
                         runsteady_times    = c(0, 1e6), 
                         pH_settings        = list(yini = NULL, times = c(0, 1e5), niter = 10, precis = 1e-3),
                         verbose            = FALSE, 
                         ...)   {

  method <- match.arg(method, c("mixed", "runsteady", "stode", "stodes"), 
                         several.ok = FALSE)

  # first run without pH dynamics
  std <- FEMSDIAsteady_Full (
                         parms              = parms, 
                         yini               = yini, 
                         gridtype           = gridtype, Grid = Grid, 
                         porosity           = porosity, 
                         bioturbation       = bioturbation, 
                         irrigation         = irrigation, 
                         surface            = surface, 
                         diffusionfactor    = diffusionfactor,  
                         dynamicbottomwater = dynamicbottomwater,
                         dynamicpH          = FALSE,    # !!
                         method             = method, 
                         times              = runsteady_times, 
                         verbose            = verbose, 
                         ...)
  CLS <-  class(std)
  ATT <- attributes(std)
  
  # then run for pH if needed
  if (dynamicpH){
    std <- PHDIAsteady(std = std, pH_settings = pH_settings, yini = yini)
  }
  
  std$dynamicpH          <- dynamicpH
  std$dynamicbottomwater <- dynamicbottomwater
  
  class(std)    <- unique(c("FEMSDIAstd", CLS))
  std
}                         

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Add steady-state pH variables to the 
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

PHDIAsteady <- function (std, pH_settings, yini){
  
    N        <- .FEMSDIA$N
    nspec    <- 2 + length(.PHDIA$y_names)
    ynames   <- c("DIC", "ALK", .PHDIA$y_names) 
    nout     <- .PHDIA$nout
    outnames <- .PHDIA$outnames
  
  # initial conditions for the ph model:  
    ph_yini <- pH_settings$yini
    
    if (is.null (ph_yini)){
        nspec_femsdia <- length(.FEMSDIA$y_names)
        nspec_phdia   <- length(.PHDIA$y_names)
        nspec_all     <- nspec_femsdia + nspec_phdia
        
        nc_femsdia <- nspec_femsdia * N
        nc_all     <- nspec_all     * N
    
      if (inherits(yini, "FEMSDIAdyn")){
        if (attributes(yini)$dynamicpH)
          ph_yini   <- yini[nrow(yini), (nc_femsdia + 2) : (nc_all + 1)]
        
      } else if (inherits(yini, "FEMSDIAstd")){
         if (yini$dynamicpH)
           ph_yini <- as.vector(yini$y[, (nspec_femsdia+1):nspec_all])
         
      } else if (is.matrix(yini)) {
           ph_yini <- as.vector(yini)[   (nc_femsdia + 1) : (nc_all)]
      }
    } 
    if (is.null(ph_yini)) 
      ph_yini <- c(rep(1e2, N), rep(1e2, N), rep(1e4, N))
    if (length(ph_yini) == 3) 
      ph_yini <- rep(ph_yini, each = N)
      
    DIC    <- FEMSDIA_extract(std, which = "DIC")  
    ALK    <- FEMSDIA_extract(std, which = "ALK")  
    yini   <- c(DIC, ALK, ph_yini)
    
    # forcing variables, passed in rpar 
    ATT    <- attributes(std)

    rpar  <- c(FEMSDIA_extract(std, which = "NO3"),
               FEMSDIA_extract(std, which = "NO2"),
               FEMSDIA_extract(std, which = "NH3"),
               FEMSDIA_extract(std, which = "H2S"),
               FEMSDIA_extract(std, which = "SO4"), 
               FEMSDIA_extract(std, which = "PO4"), 
               FEMSDIA_extract(std, which = "Temperature"), 
               FEMSDIA_extract(std, which = "DICprod"), 
               FEMSDIA_extract(std, which = "ALKprod"))

# try first using solver
     stdph  <- suppressWarnings(steady.1D(
                    y        = as.double(yini),   
                    func     = "phsteady", 
                    initfunc = "initphdia", 
                    initforc = "initfemsforc",
                    dllname  = "FEMSDIA", 
                    forcings = std$forcings, 
                    initpar  = std$initpar, 
                    rpar     = as.double(rpar), 
                    names    = ynames, nout = nout, outnames = outnames,
                    jactype  = "1D", method = "stode", nspec = nspec, 
                    maxiter  = 100, 
                    positive = TRUE))
     
     if (attributes(stdph)$steady){
       ATTph <- attributes(stdph)
     
       std$y[,"DIC"] <- stdph$y[,"DIC"]   # new DIC and ALK
       std$y[,"ALK"] <- stdph$y[,"ALK"]
       std$y         <- cbind(std$y, stdph$y[,-(1:2)])  # add CALC, ARAG, Ca
       std           <- c(std, stdph[-1])               # add new variables
       
       attributes(std)$steady <- ATTph$steady & ATT$steady
       attributes(std)$precis <- ATTph$precis
       attributes(std)$solver <- "stode"
       attributes(std)$dimens <- ATTph$dimens
       attributes(std)$nspec  <- ATT$nspec + ATTph$nspec - 2
       attributes(std)$ynames <- c(ATT$ynames, ATTph$ynames[-(1:2)])
       return (std)
     }
   
   times <- pH_settings$times
   if (is.null(times)) times <- c(0, 1e5)
   
   niter <- pH_settings$niter
   if (is.null(niter)) niter <- 10
   
   precis <- pH_settings$precis
   if (is.null(precis)) precis <- 1e-3
   
   for (i in 1:niter){
       stdph <- steady.1D(
                    y        = as.double(yini),   
                    func     = "phsteady", 
                    initfunc = "initphdia", 
                    initforc = "initfemsforc",
                    dllname  = "FEMSDIA", 
                    forcings = std$forcings, 
                    initpar  = std$initpar, 
                    rpar     = as.double(rpar), 
                    names    = ynames, nout = nout, outnames = outnames,
                    jactype  = "1D", method = "runsteady", nspec    = nspec, 
                    times    = times,
                    positive = TRUE)
       yini <- stdph$y
       if (attributes(stdph)$precis < precis) break()
   }     
     stdph_2  <- suppressWarnings(
           steady.1D(
                    y        = as.double(yini),   
                    func     = "phsteady", 
                    initfunc = "initphdia", 
                    initforc = "initfemsforc",
                    dllname  = "FEMSDIA", 
                    forcings = std$forcings, 
                    initpar  = std$initpar, 
                    rpar     = as.double(rpar), 
                    names    = ynames, nout = nout, outnames = outnames,
                    jactype  = "1D", method = "stode", nspec = nspec, 
                    maxiter  = 100, 
                    positive = TRUE))
     
     if (attributes(stdph_2)$steady) {
       
       stdph <- stdph_2
     
     } else {  # make runsteady output compatible to stode
            
       Att     <- attributes(stdph)[-(1:2)]
       STD  <- list(y = stdph$y)
       VAR  <- stdph$var
       names(VAR) <- outnames 
       OUT  <- unique(outnames)
       Z <- lapply(OUT, 
                  FUN = function(x) {
                    VV        <- subset(VAR, names(VAR) == x)
                    names(VV) <- NULL
                    VV 
                  })
         
       names(Z) <- OUT   
     
       Att <- Att[-1]
       stdph           <- c(STD, Z, Att) 
         
     }
     ATTph <- attributes(stdph)
     
     std$y[,"DIC"] <- stdph$y[,"DIC"]   # new DIC and ALK
     std$y[,"ALK"] <- stdph$y[,"ALK"]
     std$y         <- cbind(std$y, stdph$y[,-(1:2)])  # add CALC, ARAG, Ca
     std           <- c(std, stdph[-1])               # add new variables
     
     attributes(std)$steady <- ATTph$steady & ATT$steady
     attributes(std)$precis <- ATTph$precis
     attributes(std)$solver <- c("runsteady", "stode")
     attributes(std)$runsteady_iterations <- i
     attributes(std)$dimens <- ATTph$dimens
     attributes(std)$nspec  <- ATT$nspec + ATTph$nspec - 2
     attributes(std)$ynames <- c(ATT$ynames, ATTph$ynames[-(1:2)])
     std
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIAsteady_Full <- function (parms = list(), yini = NULL, 
                  f_Cflux = NULL, f_pFast = NULL, f_RDETflux = NULL, 
                  f_MnO2flux = NULL, f_FeOH3flux = NULL, 
                  f_DBL   = NULL, f_flow = NULL,
                  f_O2bw  = NULL, f_NO3bw = NULL, f_NO2bw = NULL, 
                  f_NH3bw = NULL, 
                  f_Mnbw  = NULL, f_Febw = NULL, 
                  f_H2Sbw = NULL, f_SO4bw = NULL, 
                  f_CH4bw = NULL, f_PO4bw = NULL, 
                  f_DICbw = NULL, f_ALKbw = NULL,
                  f_gasflux = NULL, f_w = NULL, 
                  f_Bioturbationfactor = NULL, f_Irrigationfactor = NULL, 
                  f_Hwater = NULL, f_Twater = NULL, f_Swater = NULL, 
                  f_MPBprod = NULL,
                  f_CALCflux = NULL, f_ARAGflux = NULL, 
                  f_Cabw = NULL,
                  gridtype = 1, Grid = NULL,  porosity = NULL, 
                  bioturbation = NULL, irrigation = NULL, 
                  surface = NULL, diffusionfactor = NULL, 
                  dynamicbottomwater = FALSE,
                  dynamicpH = FALSE, verbose = FALSE, 
                  method  = NULL, times = c(0, 1e6),  ...)   {
  
    ff <- list(f_Cflux  = f_Cflux, f_pFast  = f_pFast, f_RDETflux = f_RDETflux,   
             f_MnO2flux = f_MnO2flux, f_FeOH3flux = f_FeOH3flux, 
             f_O2bw   = f_O2bw,     f_NO3bw = f_NO3bw,   f_NO2bw = f_NO2bw, 
             f_NH3bw  = f_NH3bw,     f_Mnbw = f_Mnbw,   f_Febw   = f_Febw,     
             f_H2Sbw = f_H2Sbw,     f_SO4bw = f_SO4bw,  
             f_CH4bw  = f_CH4bw,    f_PO4bw = f_PO4bw,    
             f_DICbw  = f_DICbw,    f_ALKbw = f_ALKbw,   
             f_DBL    = f_DBL,       f_flow = f_flow,   f_w      = f_w,      
             f_MPBprod = f_MPBprod,  f_gasflux = f_gasflux, 
             f_Hwater = f_Hwater,  f_Twater = f_Twater, f_Swater = f_Swater,   
             f_Bioturbationfactor = f_Bioturbationfactor,  
             f_Irrigationfactor = f_Irrigationfactor,
             f_CALCflux = f_CALCflux, f_ARAGflux = f_ARAGflux, f_Cabw = f_Cabw)


   N <- .FEMSDIA$N
   if (dynamicbottomwater) N <- .FEMSDIA$N+1
  
   if (is.null(method)) method <- "mix"
   
   if ( method %in% c("runsteady", "mixed", "run", "mix")) {
      DIA <- FEMSDIAdyna_Full (parms  = parms, times = times, yini = yini, 
                   ff                 = ff, 
                   gridtype = gridtype, 
                   Grid = Grid, porosity = porosity, 
                   bioturbation       = bioturbation, 
                   irrigation         = irrigation, 
                   surface            = surface, 
                   diffusionfactor    = diffusionfactor,
                   
                   dynamicbottomwater = dynamicbottomwater,
                   dynamicpH          = dynamicpH, 
                   verbose            = verbose, ...) 
     
      Att   <- attributes(DIA)[-1]
      DIA   <- DIA[nrow(DIA), -1]
      nspec <- length(.FEMSDIA$y_names)
      if (dynamicpH) 
        nspec <- nspec + length(.PHDIA$y_names)
      SVAR  <- DIA[1:(N*nspec)]  
     
      if (method == "runsteady"){  # finished
         SVNAMES  <- unique(names(SVAR))
       
         STD  <- list(y = matrix(nrow = N, ncol = nspec, data  = SVAR))
         colnames(STD$y) <- SVNAMES
       
         VAR  <- DIA[-(1:(N*nspec))]
       
         OUT  <- unique(names(VAR))
         Z <- lapply(OUT, 
                     FUN = function(x) {
                         VV        <- subset(VAR, names(VAR) == x)
                         names(VV) <- NULL
                         VV 
                     })
         
         names(Z) <- OUT   
     
         Att <- Att[-1]
         nn <- c("depth", "dx", "Aint", "parms", 
                 "Grid", "porosity", "porint", 
                 "diffusionfactor", "bioturbation", "bioturbint",
                 "irrigation", "gridtype", 
                 "diffcoeff", "isDistReact", "DistReact")
         STD             <- c(STD, Z, Att[nn]) 
         
         STD$model       <- "FEMSDIA_run_steady"
         STD$method      <- "run_steady"
         attributes(STD) <- c(attributes(STD)[1], Att[!names(Att) %in% nn])
         class(STD)      <- c("FEMSDIAstd", "steady1D",  "rootSolve", "list")
         return (STD)
         
     } else {
       yini <- SVAR
     }
  }   # method in c("runsteady", "mixed", "run", "mix")
  
  std <- FEMSDIAsteady_full (parms, gridtype, Grid = Grid, ff = ff,
                    porosity = porosity, 
                    bioturbation = bioturbation, 
                    irrigation = irrigation, surface = surface, 
                    diffusionfactor = diffusionfactor, yini = yini, 
                    verbose = verbose, 
                    times = times, method = NULL, 
                    dynamicbottomwater = dynamicbottomwater,
                    dynamicpH = dynamicpH, ...)
  class(std) <- unique(c("FEMSDIAstd", class(std)))
  std

}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIAsteady_full <- function (parms = list(), gridtype = 1, ff,
                        times = NULL, Grid = NULL, porosity = NULL, 
                        bioturbation = NULL, irrigation = NULL, surface = NULL, 
                        diffusionfactor = NULL, yini = NULL, 
                        verbose = FALSE, method = NULL, 
                        dynamicpH = FALSE, dynamicbottomwater = FALSE,
                        iniP = NULL, ...)  {
  
  if (is.null(iniP))
    iniP <- initFEMSDIA(parms = parms, gridtype = gridtype, ff = ff,
                        times = times, Grid = Grid,
                        porosity = porosity, bioturbation = bioturbation, 
                        irrigation = irrigation, surface = surface, 
                        diffusionfactor = diffusionfactor, 
                        dynamicbottomwater = dynamicbottomwater, dynamicpH = dynamicpH)
                     
  initfunc <- "initfemsdia"
  initforc <- "initfemsforc"
  
  if (!dynamicpH){
    nspec    <- length(.FEMSDIA$y_names)
    ynames   <- .FEMSDIA$y_names
    nout     <- .FEMSDIA$nout
    outnames <- .FEMSDIA$outnames
  } else {
    nspec    <- length(.FEMSDIA$y_names) + length(.PHDIA$y_names)
    ynames   <- c(.FEMSDIA$y_names,.PHDIA$y_names) 
    nout     <- .FEMSDIA$nout + .PHDIA$nout
    outnames <- c(.FEMSDIA$outnames, .PHDIA$outnames)
  }
  
  if (dynamicpH){
     if (! dynamicbottomwater) {  # No dynamic bottom water
#       f_HWATER <- as.double(0)
       func     <- "phdiamod"
       N        <- .FEMSDIA$N
     } else {
#       f_HWATER <- as.double(iniP$parms["Hwater"])
       func     <- "phdiamodbw"
       N        <- .FEMSDIA$N + 1
     } 
    
     initfunc <- "initphdia"

  } else { # NO dynamic pH

     if (! dynamicbottomwater) {
#       f_HWATER <- as.double(0)
       func     <- "femsdiamod"
       N        <- .FEMSDIA$N
     } else {
#       f_HWATER <- as.double(iniP$parms["Hwater"])
       func     <- "femsdiamodbw"
       N        <- .FEMSDIA$N + 1
     }  
  }
  
  forcings <- steadyForcings(iniP)

  Random   <- is.null(yini)
  Yini     <- yini  
  
  if (is.null(Yini)) 
    Yini   <- rep(10, nspec*N)

  else
    Yini <- checkYini(yini, dynamicpH, dynamicbottomwater)
  
  sparse   <- "1D"
  jactype <- NULL
  if (is.null(method)) {
    if (iniP$isDistReact) 
     method <- "stodes"
    else if ( dynamicbottomwater  & iniP$Isirr) 
      method <- "stodes"
    else  
      method <- "stode"
  }     

  inz <- NULL
  
  if (method == "stodes") 
    sparse <- "sparseint"
  if (iniP$isDistReact)      
    sparse <- "sparseint"
  if (dynamicbottomwater & iniP$Isirr) 
    sparse <- "sparseint"
    
  
  ZZ <- NULL
  if ((method %in% c("runsteady", "mixed", "run", "mix")) & 
      (any(is.na(times)) | any(is.infinite(times))))
    stop ("cannot combine method = 'runsteady' or 'mixed'",
          "with 'times' that is either NA or Inf")
  
  # suppress the warnings and the messages
  if (any(is.na(times))){   # just one call to the DLL

# expand forcings to be a "time series"
     lf <- as.list(forcings)
     forcings <- lapply(lf, FUN = function(x) cbind(t = c(0, Inf), v = x))
    
     ZZ <- c(ZZ, capture.output(suppressWarnings(   
       DIA  <- DLLfunc(y        = as.double(Yini), 
                       times    = 0,
                       func     = func, 
                       initfunc = initfunc, 
                       initforc = initforc, 
                       dllname  = "FEMSDIA", 
                       forcings = forcings, 
                       parms    = iniP$initpar,
                       nout     = nout, outnames = outnames, ...)
     )))
     attr(DIA,"message") <- ZZ 
     return(DIA)
  } 

  ZZ <- c(ZZ, capture.output(suppressWarnings(   
     DIA  <- steady.1D(
                    y        = as.double(Yini), 
                    times    = times,  
                    func     = func, 
                    initfunc = initfunc, 
                    initforc = initforc,
                    dllname  = "FEMSDIA", 
                    forcings = forcings, 
                    initpar  = unlist(iniP$initpar), 
                    names    = ynames, nout = nout, outnames = outnames,
                    jactype  = sparse, method = method, inz = inz,
                    nspec    = nspec, 
                    maxiter  = 100, 
                    positive = TRUE, ...)
  )))
  
  niter <- 1
  y1 <- c(1e2,    1e4,    1e5, 10,    5,    1,     1000,   1e4, 1e4,  1e3,      
          1e2,    1e3,   1e2,   30,  1e4,      1e2,    0,   1e4, 
          1,        1,     1,  1e2,    1e3
          ) 
  y2 <- c(1e1,    1e3,   1e4, 100,   10,   10,       10,   1e3,  1e2,  1e2,
          1,      1e4,     0,    1,  3e4,        1,     0,  1e3, 
          1,        1,     1,  1e1,    1e2
          ) 
  if (dynamicpH){
    y1 <- c(y1, 1e4, 1e4, 1e4)
    y2 <- c(y2, 1e2, 1e2, 1e4)
      
  }
  while (! attributes(DIA)$steady & niter <= 50 & method != "runsteady")  {
    
   if (Random) {
     aa <- runif(1)
     if (aa > 0.6)
       Yini <- runif(N*nspec)
     else if (aa > 0.3)
       Yini <- as.vector(sapply(y1*runif(nspec), 
                                FUN = function(x) rep(x, times = N)))
     else
       Yini <- as.vector(sapply(y2*runif(nspec), 
                                FUN = function(x) rep(x, times = N)))
     
   } else
      Yini <- runif( N*nspec)*yini
  
#   Yini <- runif(nspec * .FEMSDIA$N)*niter 
   ZZ <- c(ZZ, capture.output(suppressWarnings(   
   DIA  <- steady.1D(
                    y        = as.double(Yini), 
                    times    = times,  
                    func     = func, 
                    initfunc = initfunc, 
                    initforc = initforc,
                    dllname  = "FEMSDIA", 
                    forcings = forcings, 
                    initpar  = unlist(iniP$initpar), 
                    names    = ynames, nout = nout, outnames = outnames,
                    jactype  = sparse, method = method, inz = inz,
                    nspec    = nspec, 
                    maxiter  = 100, 
                    positive = TRUE, ...)
       )))
       niter <- niter + 1
  }
  
  if (verbose) {
    if (!attributes(DIA)$steady) warning("steady-state not reached")
    print(ZZ)
  }  
  
  if (method == "runsteady"){   # all output vars are in one long vector
     
     DD             <- DIA
     names(DIA$var) <- outnames
     OUT            <- unique(outnames)
     Z <- lapply(OUT, FUN = function(x) {
        VV <- subset(DIA$var, names(DIA$var) == x)
        names(VV) <- NULL
        VV })
     names(Z) <- OUT   
     DD$var <- NULL
     Att <- attributes(DIA)[-1]
     DIA <- c(DD, Z)   
     attributes(DIA) <- c(attributes(DIA)[1], Att[-1])
  }
  
  DIA$depth           <- iniP$depth
  DIA$dx              <- iniP$Grid$dx
  DIA$Aint            <- iniP$Aint
  DIA$parms           <- iniP$parms
  DIA$forcings        <- forcings
  DIA$other           <- iniP$other
  DIA$initpar         <- unlist(iniP$initpar)
  DIA$porosity        <- iniP$porosity
  DIA$porint          <- iniP$porint
  DIA$diffusionfactor <- iniP$diffusionfactor
  DIA$bioturbation    <- iniP$bioturbation
  DIA$bioturbint      <- iniP$bioturbint
  DIA$irrigation      <- iniP$irrigation
  DIA$gridtype        <- gridtype
  DIA$Grid            <- iniP$Grid
  DIA$porGrid         <- iniP$porGrid
  DIA$numberTries     <- niter
  DIA$warnings        <- ZZ
  DIA$model           <- "FEMSDIA_run_steady"
  DIA$diffcoeff       <- iniP$diffcoeff
  DIA$diffusionfactor <- DIA$diffusionfactor
  DIA$DistReact       <- iniP$DistReact 
  DIA$isDistReact     <- max(iniP$DistReact) > 0
  DIA$DistProfile     <- iniP$DistProfile  

  return(DIA)
}

