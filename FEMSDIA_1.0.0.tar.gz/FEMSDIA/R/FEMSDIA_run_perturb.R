################################################################################
######            FEMSDIA: C, N, P, Mn, Fe, S, O2 diagenesis              ######
################################################################################

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Solve the model with PERTURBATIONS
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

# internal functions
IntegrateSol <- function(FDET, N.Pert, porGrid, Grid)
    sum(FDET[1:N.Pert] * (1.-porGrid$mid[1:N.Pert]) * Grid$dx[1:N.Pert])

IntegrateLiq <- function(CONC, N.Pert,porGrid, Grid)
    sum(CONC[1:N.Pert] * porGrid$mid[1:N.Pert] * Grid$dx[1:N.Pert])

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Mixing of a solid, e.g. detritus, in the top layer 
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

MixDET <- function (FDET, N.Pert, porGrid, Grid) {
  # Integrated concentration
   TotalFdet <- sum(FDET[1:N.Pert] *
                   (1.-porGrid$mid[1:N.Pert]) * Grid$dx[1:N.Pert])
   
  # approximate mean concentration
   MeanFdet <- TotalFdet / sum(Grid$dx[1:N.Pert])

   TotalFdet2 <- sum(MeanFdet *
                  (1.-porGrid$mid[1:N.Pert]) * Grid$dx[1:N.Pert])

   if (TotalFdet2 > 0 )
     Fac <- TotalFdet / TotalFdet2
   else
     Fac <- 1

  # Mixed concentration
   FDET[1:N.Pert] <- MeanFdet*Fac
   return(FDET)
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Deposition of detritus on top of sediment
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

DepositDET <- function (FDET, N.Pert, porGrid, Grid, fac) {
  
  # Integrated concentration
   TotalFdet <- sum(FDET[1:N.Pert] *
                   (1.-porGrid$mid[1:N.Pert]) * Grid$dx[1:N.Pert])
  
   # approximate mean concentration
   MeanFdet   <- TotalFdet / sum(Grid$dx[1:N.Pert])
   
   TotalFdet2 <- sum(MeanFdet *
                  (1.-porGrid$mid[1:N.Pert]) * Grid$dx[1:N.Pert])

   if (TotalFdet2 > 0 )
     Fac <- TotalFdet / TotalFdet2* fac
   else
     Fac <- 1
   
   NewGrid <- c(Grid$x.mid[1:N.Pert], 
                Grid$x.mid + Grid$x.mid[N.Pert+1])
   FDETerode <- c(rep(MeanFdet*Fac, N.Pert), FDET)
   FDETn     <- approx(x    = NewGrid, y = FDETerode, 
                       xout = Grid$x.mid)$y

   return(FDETn)  # new concentration of the solid
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Deposition for dissolved substance:  interstitial conc = bottom water conc
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

DepositBW <- function (O2, N.Pert, bwO2, Grid) {
  
    NewGrid <- c(Grid$x.mid[1:N.Pert], Grid$x.mid+Grid$x.mid[N.Pert+1])
    O2erode <- c(rep(bwO2, N.Pert), O2)
    
    O2n <- approx(x = NewGrid, y = O2erode, xout = Grid$x.mid)$y

   return(O2n)   # new concentration
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Erosion of the top of the sediment, for solids and liquids
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

Erode <- function (FDET, N.Pert, porGrid, Grid) {

   NewGrid   <- c(Grid$x.mid[-(1:N.Pert)] - Grid$x.mid[N.Pert+1], 
                  Grid$x.mid[Grid$N])
   
   FDETerode <- c(FDET[-(1:N.Pert)], FDET[Grid$N])
   FDETn     <- approx(x    = NewGrid, 
                       y    = FDETerode, 
                       xout = Grid$x.mid)$y

   return(FDETn)
}

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Main FEMSDIA perturbation function
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIA_run_perturb <- function (parms = list(), times = 0:365, spinup = NULL, 
     yini     = NULL, gridtype = 1, Grid = NULL, 
     porosity = NULL, bioturbation = NULL, 
     irrigation = NULL, surface = NULL, 
     diffusionfactor = NULL, 
     dynamicpH = FALSE, dynamicbottomwater = FALSE, 
     
     perturb_type  = "mix", 
     perturb_times = seq(from = 0, to = max(times), by = 365), 
     perturb_depth = 0.05, 
     perturb_concfac = rep(1, times = 11),   # for all solids
  
     f_Cflux    = NULL, f_pFast     = NULL, f_RDETflux = NULL,   
     f_MnO2flux = NULL, f_FeOH3flux = NULL, 
     f_O2bw     = NULL, f_NO3bw     = NULL, f_NO2bw    = NULL,   
     f_NH3bw    = NULL, f_Mnbw      = NULL, f_Febw     = NULL,    
     f_H2Sbw    = NULL, f_SO4bw     = NULL,   
     f_CH4bw    = NULL, f_PO4bw     = NULL,  
     f_DICbw    = NULL, f_ALKbw     = NULL, 
     f_DBL      = NULL, f_flow      = NULL, f_w        = NULL, 
     f_MPBprod  = NULL, f_gasflux   = NULL,  
     f_Hwater   = NULL, f_Twater    = NULL, f_Swater   = NULL,   
     f_Bioturbationfactor = NULL,  f_Irrigationfactor  = NULL,
     f_CALCflux = NULL, f_ARAGflux  = NULL, f_Cabw     = NULL,
     verbose = FALSE, ...) {

## forcing function list

  ff <- list(f_Cflux     = f_Cflux,     f_pFast   = f_pFast,  
             f_RDETflux  = f_RDETflux, 
             f_MnO2flux  = f_MnO2flux, 
             f_FeOH3flux = f_FeOH3flux, 
             f_O2bw      = f_O2bw,      f_NO3bw   = f_NO3bw,  
             f_NO2bw     = f_NO2bw,     f_NH3bw   = f_NH3bw,    
             f_Mnbw      = f_Mnbw,      f_Febw    = f_Febw,     
             f_H2Sbw     = f_H2Sbw,     f_SO4bw   = f_SO4bw,  
             f_CH4bw     = f_CH4bw,     f_PO4bw   = f_PO4bw,     
             f_DICbw     = f_DICbw,     f_ALKbw   = f_ALKbw,   
             f_DBL       = f_DBL,       f_flow    = f_flow,   
             f_w         = f_w,         f_MPBprod = f_MPBprod,  
             f_gasflux   = f_gasflux,   f_Hwater  = f_Hwater,   
             f_Twater    = f_Twater,    f_Swater  = f_Swater, 
             f_Bioturbationfactor = f_Bioturbationfactor,  
             f_Irrigationfactor   = f_Irrigationfactor,
             f_CALCflux  = f_CALCflux, f_ARAGflux = f_ARAGflux, 
             f_Cabw      = f_Cabw)

  # check concentration factor for all solid phases 
  # (FDET, SDET, RDET, MnO2, FeOH3, FeP, CaP, Pads, FeS, FeS2, S0)
  nsolid <- 11
  if (dynamicpH) nsolid <- nsolid + 2
  if (length(perturb_concfac) == 1) 
    perturb_concfac <- rep(perturb_concfac, length.out = nsolid)
  
  if (length(perturb_concfac) != 11)
    stop("'perturb_concfac' should be of length 11, one value for ",
         "FDET, SDET, RDET, MnO2, FeOH3, FeP, CaP, Pads, FeS, FeS2, S0")
  
  perttype  <- match.arg(perturb_type, c("mix", "erode", "deposit"), 
                         several.ok = TRUE)

  depthPert <- rep(perturb_depth, length.out = length(perttype))
  
  names(depthPert) <- as.character(perttype)
  
  numPert          <- length(depthPert)
  
  ff               <- checkAllForcings(ff)

  if (is.null(spinup)) Times <- times else Times <- spinup
  
#  if (! dynamicbottomwater) 
#    ff$f_Hwater <- list(data = 1)

  # Initialisation
  if (is.null(yini)) {
    iniP <- FEMSDIAsteady_full(parms, gridtype = gridtype, ff = ff,
                      times = Times, Grid = Grid, porosity = porosity,
                      bioturbation = bioturbation, irrigation = irrigation,
                      surface = surface, diffusionfactor = diffusionfactor, 
                      dynamicbottomwater = dynamicbottomwater, 
                      dynamicpH = dynamicpH,
                      verbose = verbose)
    yini <- iniP$y
  } else  
    iniP <- initFEMSDIA(parms, gridtype = gridtype, ff = ff,
                      times = Times, Grid = Grid, porosity = porosity, 
                      bioturbation = bioturbation, irrigation = irrigation,
                      surface = surface, diffusionfactor = diffusionfactor, 
                      dynamicbottomwater = dynamicbottomwater, 
                      dynamicpH = dynamicpH)
  Grid    <- iniP$Grid
  porGrid <- iniP$porGrid

  pertCONC <- yini
  PertFlux <- PertBW <- PertBW2 <- NULL 
  events   <- NULL

  Parms <- iniP$parms
  PP    <- unlist(Parms)

# Number of layers that are perturbed 
# Note: there can be more than one type of perturbation 

  N.Pert <- rep(0, times = length(depthPert))
  
  for (i in 1:length(depthPert))
      N.Pert[i] <- length(Grid$x.int[Grid$x.int < depthPert[i]])
  
  names(N.Pert) <- as.character(perttype)

  y_names  <- .FEMSDIA$y_names
  if (dynamicpH) y_names <- c(y_names, .PHDIA$y_names)
  nspec    <- length(y_names)

#===============================================================================
# Function to Perturb all states
#===============================================================================

   Perturb <- function (out, t) {

    ii <- which (N.Pert > 0)
     
    # integrated concentrations over the perturbed sediment layer
    if (inherits (out, "steady1D"))
      pertCONC <- out$y
    
    else
      pertCONC <- matrix(ncol = nspec, out, byrow = FALSE)

    colnames(pertCONC) <- y_names
    
    Fluxes        <-  rep(0, times = nspec)
    names(Fluxes) <- y_names

    if (! dynamicbottomwater){   # forcing functions
      bw_O2  <- bwO2 (t)
      bw_NO3 <- bwNO3(t)
      bw_NO2 <- bwNO2(t)
      bw_NH3 <- bwNH3(t)
      bw_Mn  <- bwMn (t)
      bw_Fe  <- bwFe (t)
      bw_H2S <- bwH2S(t)
      bw_SO4 <- bwSO4(t)
      bw_CH4 <- bwCH4(t)
      bw_PO4 <- bwPO4(t)
      bw_DIC <- bwDIC(t)
      bw_ALK <- bwALK(t)
      
      if (dynamicpH) 
        bw_Ca  <- bwCa (t)

    } else {     # dynamic bottom water concentrations
      BW       <- pertCONC[1 , ]
      pertCONC <- pertCONC[-1, ]
      
      bw_O2  <- BW["O2"]
      bw_NO3 <- BW["NO3"]
      bw_NO2 <- BW["NO2"]
      bw_NH3 <- BW["NH3"]
      bw_Mn  <- BW["Mn"]
      bw_Fe  <- BW["Fe"]
      bw_H2S <- BW["H2S"]
      bw_SO4 <- BW["SO4"]
      bw_CH4 <- BW["CH4"]
      bw_PO4 <- BW["PO4"]
      bw_DIC <- BW["DIC"]
      bw_ALK <- BW["ALK"]
      
      if (dynamicpH) 
        bw_Ca <- BW["Ca"]
    }
    
    for (i in ii){

      O2Conc    <- IntegrateLiq(pertCONC[ ,"O2"] ,  .FEMSDIA$N, porGrid, Grid)
      NO3Conc   <- IntegrateLiq(pertCONC[ ,"NO3"],  .FEMSDIA$N, porGrid, Grid)
      NO2Conc   <- IntegrateLiq(pertCONC[ ,"NO2"],  .FEMSDIA$N, porGrid, Grid)
      NH3Conc   <- IntegrateLiq(pertCONC[ ,"NH3"],  .FEMSDIA$N, porGrid, Grid)
      MnConc    <- IntegrateLiq(pertCONC[ ,"Mn" ],  .FEMSDIA$N, porGrid, Grid)
      FeConc    <- IntegrateLiq(pertCONC[ ,"Fe" ],  .FEMSDIA$N, porGrid, Grid)
      H2SConc   <- IntegrateLiq(pertCONC[ ,"H2S"],  .FEMSDIA$N, porGrid, Grid)
      SO4Conc   <- IntegrateLiq(pertCONC[ ,"SO4"],  .FEMSDIA$N, porGrid, Grid)
      CH4Conc   <- IntegrateLiq(pertCONC[ ,"CH4"],  .FEMSDIA$N, porGrid, Grid)
      PO4Conc   <- IntegrateLiq(pertCONC[ ,"PO4"],  .FEMSDIA$N, porGrid, Grid)
      DICConc   <- IntegrateLiq(pertCONC[ ,"DIC"],  .FEMSDIA$N, porGrid, Grid)
      ALKConc   <- IntegrateLiq(pertCONC[ ,"ALK"],  .FEMSDIA$N, porGrid, Grid)
      if (dynamicpH) 
        CaConc  <- IntegrateLiq(pertCONC[ , "Ca"],  .FEMSDIA$N, porGrid, Grid)

      FDETConc  <- IntegrateSol(pertCONC[ ,"FDET"] ,.FEMSDIA$N, porGrid, Grid)
      SDETConc  <- IntegrateSol(pertCONC[ ,"SDET"] ,.FEMSDIA$N, porGrid, Grid)
      RDETConc  <- IntegrateSol(pertCONC[ ,"RDET"] ,.FEMSDIA$N, porGrid, Grid)
      MnO2Conc  <- IntegrateSol(pertCONC[ ,"MnO2"] ,.FEMSDIA$N, porGrid, Grid)
      FeOH3Conc <- IntegrateSol(pertCONC[ ,"FeOH3"],.FEMSDIA$N, porGrid, Grid)
      FePConc   <- IntegrateSol(pertCONC[ ,"FeP"]  ,.FEMSDIA$N, porGrid, Grid)
      CaPConc   <- IntegrateSol(pertCONC[ ,"CaP"]  ,.FEMSDIA$N, porGrid, Grid)
      PadsConc  <- IntegrateSol(pertCONC[ ,"Pads"] ,.FEMSDIA$N, porGrid, Grid)
      FeSConc   <- IntegrateSol(pertCONC[ ,"FeS"]  ,.FEMSDIA$N, porGrid, Grid)
      FeS2Conc  <- IntegrateSol(pertCONC[ ,"FeS2"] ,.FEMSDIA$N, porGrid, Grid)
      S0Conc    <- IntegrateSol(pertCONC[ ,"S0"]   ,.FEMSDIA$N, porGrid, Grid)
      if (dynamicpH) {
       CALCConc  <- IntegrateSol(pertCONC[ ,"CALC"] ,.FEMSDIA$N, porGrid, Grid)
       ARAGConc  <- IntegrateSol(pertCONC[ ,"ARAG"] ,.FEMSDIA$N, porGrid, Grid)
      }

    if (perttype[i] == "mix") {    # mixed
      pertCONC[,"FDET"]  <- MixDET (pertCONC[,"FDET"]  ,N.Pert[i], porGrid, Grid)
      pertCONC[,"SDET"]  <- MixDET (pertCONC[,"SDET"]  ,N.Pert[i], porGrid, Grid)
      pertCONC[,"RDET"]  <- MixDET (pertCONC[,"RDET"]  ,N.Pert[i], porGrid, Grid)
      pertCONC[,"MnO2"]  <- MixDET (pertCONC[,"MnO2"]  ,N.Pert[i], porGrid, Grid)
      pertCONC[,"FeOH3"] <- MixDET (pertCONC[,"FeOH3"] ,N.Pert[i], porGrid, Grid)
      pertCONC[,"FeP"]   <- MixDET (pertCONC[,"FeP"]   ,N.Pert[i], porGrid, Grid)
      pertCONC[,"CaP"]   <- MixDET (pertCONC[,"CaP"]   ,N.Pert[i], porGrid, Grid)
      pertCONC[,"Pads"]  <- MixDET (pertCONC[,"Pads"]  ,N.Pert[i], porGrid, Grid)
      pertCONC[,"FeS"]   <- MixDET (pertCONC[,"FeS"]   ,N.Pert[i], porGrid, Grid)
      pertCONC[,"FeS2"]  <- MixDET (pertCONC[,"FeS2"]  ,N.Pert[i], porGrid, Grid)
      pertCONC[,"S0"]    <- MixDET (pertCONC[,"S0"]    ,N.Pert[i], porGrid, Grid)
      if (dynamicpH) {
        pertCONC[,"CALC"] <- MixDET (pertCONC[,"CALC"] ,N.Pert[i], porGrid, Grid)
        pertCONC[,"ARAG"] <- MixDET (pertCONC[,"ARAG"] ,N.Pert[i], porGrid, Grid)
      }      
      pertCONC[1:N.Pert[i], "O2"]  <- bw_O2
      pertCONC[1:N.Pert[i], "NO3"] <- bw_NO3
      pertCONC[1:N.Pert[i], "NO2"] <- bw_NO2
      pertCONC[1:N.Pert[i], "NH3"] <- bw_NH3
      pertCONC[1:N.Pert[i], "Mn" ] <- bw_Mn
      pertCONC[1:N.Pert[i], "Fe" ] <- bw_Fe
      pertCONC[1:N.Pert[i], "H2S"] <- bw_H2S
      pertCONC[1:N.Pert[i], "SO4"] <- bw_SO4
      pertCONC[1:N.Pert[i], "CH4"] <- bw_CH4
      pertCONC[1:N.Pert[i], "PO4"] <- bw_PO4
      pertCONC[1:N.Pert[i], "DIC"] <- bw_DIC
      pertCONC[1:N.Pert[i], "ALK"] <- bw_ALK
      if (dynamicpH) 
        pertCONC[1:N.Pert[i], "Ca"] <- bw_Ca

     } else if (perttype[i] == "erode") {  # erosion
       pertCONC[,"FDET"] <- Erode (pertCONC[,"FDET"] , N.Pert[i], porGrid, Grid)
       pertCONC[,"SDET"] <- Erode (pertCONC[,"SDET"] , N.Pert[i], porGrid, Grid)
       pertCONC[,"RDET"] <- Erode (pertCONC[,"RDET"] , N.Pert[i], porGrid, Grid)
       pertCONC[,"MnO2"] <- Erode (pertCONC[,"MnO2"] , N.Pert[i], porGrid, Grid)
       pertCONC[,"FeOH3"]<- Erode (pertCONC[,"FeOH3"], N.Pert[i], porGrid, Grid)
       pertCONC[,"FeP"]  <- Erode (pertCONC[,"FeP"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"CaP"]  <- Erode (pertCONC[,"CaP"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"Pads"] <- Erode (pertCONC[,"Pads"] , N.Pert[i], porGrid, Grid)
       pertCONC[,"FeS"]  <- Erode (pertCONC[,"FeS"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"FeS2"] <- Erode (pertCONC[,"FeS2"] , N.Pert[i], porGrid, Grid)
       pertCONC[,"S0"]   <- Erode (pertCONC[,"S0"]   , N.Pert[i], porGrid, Grid)
       if (dynamicpH) {
        pertCONC[,"CALC"]<- Erode (pertCONC[,"CALC"] , N.Pert[i], porGrid, Grid)
        pertCONC[,"ARAG"]<- Erode (pertCONC[,"ARAG"] , N.Pert[i], porGrid, Grid)
       }
       
       pertCONC[,"O2"]   <- Erode (pertCONC[,"O2"]   , N.Pert[i], porGrid, Grid)
       pertCONC[,"NO3"]  <- Erode (pertCONC[,"NO3"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"NO2"]  <- Erode (pertCONC[,"NO2"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"NH3"]  <- Erode (pertCONC[,"NH3"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"Mn"]   <- Erode (pertCONC[,"Mn"]   , N.Pert[i], porGrid, Grid)
       pertCONC[,"Fe"]   <- Erode (pertCONC[,"Fe"]   , N.Pert[i], porGrid, Grid)
       pertCONC[,"H2S"]  <- Erode (pertCONC[,"H2S"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"SO4"]  <- Erode (pertCONC[,"SO4"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"CH4"]  <- Erode (pertCONC[,"CH4"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"PO4"]  <- Erode (pertCONC[,"PO4"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"DIC"]  <- Erode (pertCONC[,"DIC"]  , N.Pert[i], porGrid, Grid)
       pertCONC[,"ALK"]  <- Erode (pertCONC[,"ALK"]  , N.Pert[i], porGrid, Grid)
       if (dynamicpH) 
         pertCONC[,"Ca"] <- Erode (pertCONC[,"Ca"]   , N.Pert[i], porGrid, Grid)

     } else { # deposit
       
       pertCONC[,"FDET"] <- DepositDET (pertCONC[,"FDET"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[1])
       
       pertCONC[,"SDET"] <- DepositDET (pertCONC[,"SDET"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[2])
       
       pertCONC[,"RDET"] <- DepositDET (pertCONC[,"RDET"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[3])
       
       pertCONC[,"MnO2"] <- DepositDET (pertCONC[,"MnO2"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[4])
       
       pertCONC[,"FeOH3"]<- DepositDET (pertCONC[,"FeOH3"], N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[5])
       
       pertCONC[,"FeP"]  <- DepositDET (pertCONC[,"FeP"] ,  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[6])
       
       pertCONC[,"CaP"]  <- DepositDET (pertCONC[,"CaP"] ,  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[7])
       
       pertCONC[,"Pads"] <- DepositDET (pertCONC[,"Pads"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[8])
       
       pertCONC[,"FeS"]  <- DepositDET (pertCONC[,"FeS"] ,  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[9])
       
       pertCONC[,"FeS2"] <- DepositDET (pertCONC[,"FeS2"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[10])
       
       pertCONC[,"S0"]   <- DepositDET (pertCONC[,"S0"] ,  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[11])
       
       if (dynamicpH) {
        pertCONC[,"CALC"]<- DepositDET (pertCONC[,"CALC"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[12])
        pertCONC[,"ARAG"]<- DepositDET (pertCONC[,"ARAG"],  N.Pert[i], porGrid, 
                                        Grid, perturb_concfac[13])
       }
       pertCONC[,"O2"]   <- DepositBW (pertCONC[,"O2"]  ,   N.Pert[i], bwO2(t) , Grid)
       pertCONC[,"NO3"]  <- DepositBW (pertCONC[,"NO3"] ,   N.Pert[i], bwNO3(t), Grid)
       pertCONC[,"NO2"]  <- DepositBW (pertCONC[,"NO2"] ,   N.Pert[i], bwNO2(t), Grid)
       pertCONC[,"NH3"]  <- DepositBW (pertCONC[,"NH3"] ,   N.Pert[i], bwNH3(t), Grid)
       pertCONC[,"Mn" ]  <- DepositBW (pertCONC[,"Mn" ] ,   N.Pert[i], bwMn(t) , Grid)
       pertCONC[,"Fe" ]  <- DepositBW (pertCONC[,"Fe" ] ,   N.Pert[i], bwFe(t) , Grid)
       pertCONC[,"H2S"]  <- DepositBW (pertCONC[,"H2S"] ,   N.Pert[i], bwH2S(t), Grid)
       pertCONC[,"SO4"]  <- DepositBW (pertCONC[,"SO4"] ,   N.Pert[i], bwSO4(t), Grid)
       pertCONC[,"CH4"]  <- DepositBW (pertCONC[,"CH4"] ,   N.Pert[i], bwCH4(t), Grid)
       pertCONC[,"PO4"]  <- DepositBW (pertCONC[,"PO4"] ,   N.Pert[i], bwPO4(t), Grid)
       pertCONC[,"DIC"]  <- DepositBW (pertCONC[,"DIC"] ,   N.Pert[i], bwDIC(t), Grid)
       pertCONC[,"ALK"]  <- DepositBW (pertCONC[,"ALK"] ,   N.Pert[i], bwALK(t), Grid)
       if (dynamicpH)
         pertCONC[,"Ca"] <- DepositBW (pertCONC[,"Ca"]  ,   N.Pert[i], bwCa(t) , Grid)
     }
    Fluxes[1:23] <- Fluxes[1:23] + 
       c(FDET  = -(FDETConc - IntegrateSol(pertCONC[ ,"FDET"] ,.FEMSDIA$N, porGrid, Grid)),
         SDET  = -(SDETConc - IntegrateSol(pertCONC[ ,"SDET"] ,.FEMSDIA$N, porGrid, Grid)),
         RDET  = -(RDETConc - IntegrateSol(pertCONC[ ,"RDET"] ,.FEMSDIA$N, porGrid, Grid)),
         O2    = -(O2Conc   - IntegrateLiq(pertCONC[ ,"O2"]   ,.FEMSDIA$N, porGrid, Grid)),
         NO3   = -(NO3Conc  - IntegrateLiq(pertCONC[ ,"NO3"]  ,.FEMSDIA$N, porGrid, Grid)),
         NO2   = -(NO2Conc  - IntegrateLiq(pertCONC[ ,"NO2"]  ,.FEMSDIA$N, porGrid, Grid)),
         NH3   = -(NH3Conc  - IntegrateLiq(pertCONC[ ,"NH3"]  ,.FEMSDIA$N, porGrid, Grid)),
         Mn    = -(MnConc   - IntegrateLiq(pertCONC[ ,"Mn"]   ,.FEMSDIA$N, porGrid, Grid)),
         MnO2  = -(MnO2Conc - IntegrateSol(pertCONC[ ,"MnO2"] ,.FEMSDIA$N, porGrid, Grid)),
         Fe    = -(FeConc   - IntegrateLiq(pertCONC[ ,"Fe"]   ,.FEMSDIA$N, porGrid, Grid)),
         FeOH3 =-(FeOH3Conc - IntegrateSol(pertCONC[ ,"FeOH3"],.FEMSDIA$N, porGrid, Grid)),
         H2S   = -(H2SConc  - IntegrateLiq(pertCONC[ ,"H2S"]  ,.FEMSDIA$N, porGrid, Grid)),
         SO4   = -(SO4Conc  - IntegrateLiq(pertCONC[ ,"SO4"]  ,.FEMSDIA$N, porGrid, Grid)),
         CH4   = -(CH4Conc  - IntegrateLiq(pertCONC[ ,"CH4"]  ,.FEMSDIA$N, porGrid, Grid)),
         PO4   = -(PO4Conc  - IntegrateLiq(pertCONC[ ,"PO4"]  ,.FEMSDIA$N, porGrid, Grid)),
         FeP   = -(FePConc  - IntegrateSol(pertCONC[ ,"FeP"]  ,.FEMSDIA$N, porGrid, Grid)),
         CaP   = -(CaPConc  - IntegrateSol(pertCONC[ ,"CaP"]  ,.FEMSDIA$N, porGrid, Grid)),
         Pads  = -(PadsConc - IntegrateSol(pertCONC[ ,"Pads"] ,.FEMSDIA$N, porGrid, Grid)),
         FeS   = -(FeSConc  - IntegrateSol(pertCONC[ ,"FeS"]  ,.FEMSDIA$N, porGrid, Grid)),
         FeS2  = -(FeS2Conc - IntegrateSol(pertCONC[ ,"FeS2"] ,.FEMSDIA$N, porGrid, Grid)),
         S0    = -(S0Conc   - IntegrateSol(pertCONC[ ,"S0"]   ,.FEMSDIA$N, porGrid, Grid)),
         DIC   = -(DICConc  - IntegrateLiq(pertCONC[ ,"DIC"]  ,.FEMSDIA$N, porGrid, Grid)),
         ALK   = -(ALKConc  - IntegrateLiq(pertCONC[ ,"ALK"]  ,.FEMSDIA$N, porGrid, Grid))
         )
      if (dynamicpH){
        Fluxes[24:26] <- Fluxes[24:26] + 
       c(CALC  = -(CALCConc - IntegrateSol(pertCONC[ ,"CALC"] ,.FEMSDIA$N, porGrid, Grid)),
         ARAG  = -(ARAGConc - IntegrateSol(pertCONC[ ,"ARAG"] ,.FEMSDIA$N, porGrid, Grid)),
           Ca  = -(CaConc   - IntegrateSol(pertCONC[ ,"Ca"]   ,.FEMSDIA$N, porGrid, Grid)))
      }
    }
      PertFlux <<- rbind(PertFlux, Fluxes)
      
      if (dynamicbottomwater){
        PertBW   <<- rbind(PertBW  , BW)
        BW       <- BW - Fluxes[.FEMSDIA$y_names]/bwHeight(t)
        BW       <- pmax(BW, 0)
        pertCONC <- rbind(BW, pertCONC)
        PertBW2  <<- rbind(PertBW2  , BW)
    
      }
    return(pertCONC)
  }  # end function Perturb

#===============================================================================
# Event Function
#===============================================================================

  EventFunc <- function(t, y, parms){
     print (paste("event at time", t))
     pertCONC <- Perturb(y, t)
     return (as.vector(pertCONC))
  }

  initpar = unlist(iniP$initpar)

  events <- list(func = EventFunc, 
                 time = perturb_times)

  if (iniP$isDistReact | dynamicbottomwater) {
     band   <- 0
     lrw    <- 500000
  } else  {
      band   <- 1
     lrw    <- 300000
  }

  if (! dynamicbottomwater) {
    func <- "femsdiamod"
    N    <- .FEMSDIA$N
  } else {
    func <- "femsdiamodbw"
    N    <- .FEMSDIA$N + 1  
  }  
  
  yini <- checkYini(yini, dynamicpH, dynamicbottomwater)
  
  ZZ <- NULL  
  
  is.spinup <- ! is.null(spinup)
  
  if (is.spinup)
    is.spinup <- (length(spinup) > 1)

  if (is.spinup) {
    forcings <- createForcings(iniP, spinup, ff)
    
    if (! dynamicbottomwater){   # 
# bottom water concentrations are forcing functions
      bwO2  <- approxfun(x = forcings[["O2bw"]],  rule = 2)
      bwNO3 <- approxfun(x = forcings[["NO3bw"]], rule = 2)
      bwNO2 <- approxfun(x = forcings[["NO2bw"]], rule = 2)
      bwNH3 <- approxfun(x = forcings[["NH3bw"]], rule = 2)
      bwMn  <- approxfun(x = forcings[["Mnbw"]],  rule = 2)
      bwFe  <- approxfun(x = forcings[["Febw"]],  rule = 2)
      bwH2S <- approxfun(x = forcings[["H2Sbw"]], rule = 2)
      bwSO4 <- approxfun(x = forcings[["SO4bw"]], rule = 2)
      bwCH4 <- approxfun(x = forcings[["CH4bw"]], rule = 2)
      bwPO4 <- approxfun(x = forcings[["PO4bw"]], rule = 2)
      bwDIC <- approxfun(x = forcings[["DICbw"]], rule = 2)
      bwALK <- approxfun(x = forcings[["ALKbw"]], rule = 2)
      bwCa  <- approxfun(x = forcings[["Cabw"]],  rule = 2)
    
    } else {
# bottom water concentrations are modeled 
      BWapprox <- approxfun(x = range(times), y = c(0,0), rule = 2)
      bwO2  <- bwNO3 <- bwNO2 <- bwNH3 <- BWapprox 
      bwMn  <- bwFe  <- bwH2S <- bwSO4 <- bwCH4 <- BWapprox
      bwPO4 <- bwDIC <- bwALK <- bwCa  <- BWapprox
    }
      
    if (dynamicbottomwater) 
      bwHeight <- approxfun(x = forcings[["Hwater"]], rule = 2)
    
    ev      <- events
    ev$time <- ev$time [ev$time >= min(spinup) & 
                        ev$time <= max(spinup)]
    
    ZZ <- c(ZZ, capture.output(suppressWarnings(   
      DYN <- ode.1D(y = yini, times = spinup, 
                   func     = func, 
                   initfunc = "initfemsdia", 
                   initforc = "initfemsforc",
                   dllname  = "FEMSDIA", 
                   initpar  = initpar, forcings = forcings,  
                   method   = "lsodes", lrw = lrw, bandwidth = band, 
                   nspec    = nspec,
                   names    = .FEMSDIA$y_names, nout = .FEMSDIA$nout, 
                   outnames = .FEMSDIA$outnames,
                   events = ev, ...)
    )))      
    yini <- DYN[nrow(DYN),2:(nspec*N+1)]
  }

    forcings <- createForcings(iniP, times, ff)

    if (! dynamicbottomwater){   # 
# bottom water concentrations are forcing functions
      bwO2  <- approxfun(x = forcings[["O2bw"]],  rule = 2)
      bwNO3 <- approxfun(x = forcings[["NO3bw"]], rule = 2)
      bwNO2 <- approxfun(x = forcings[["NO2bw"]], rule = 2)
      bwNH3 <- approxfun(x = forcings[["NH3bw"]], rule = 2)
      bwMn  <- approxfun(x = forcings[["Mnbw"]],  rule = 2)
      bwFe  <- approxfun(x = forcings[["Febw"]],  rule = 2)
      bwH2S <- approxfun(x = forcings[["H2Sbw"]], rule = 2)
      bwSO4 <- approxfun(x = forcings[["SO4bw"]], rule = 2)
      bwCH4 <- approxfun(x = forcings[["CH4bw"]], rule = 2)
      bwPO4 <- approxfun(x = forcings[["PO4bw"]], rule = 2)
      bwDIC <- approxfun(x = forcings[["DICbw"]], rule = 2)
      bwALK <- approxfun(x = forcings[["ALKbw"]], rule = 2)
      bwCa  <- approxfun(x = forcings[["Cabw"]],  rule = 2)
    
    } else {  # set to 0
# bottom water concentrations are modeled
      BWapprox <- approxfun(x = range(times), 
                            y = c(0, 0), rule = 2)
      bwO2  <- bwNO3 <- bwNO2 <- bwNH3 <- BWapprox 
      bwMn  <- bwFe  <- bwH2S <- bwSO4 <- bwCH4 <- BWapprox
      bwPO4 <- bwDIC <- bwALK <- bwCa  <- BWapprox
    }
      
    if (dynamicbottomwater) 
      bwHeight <- approxfun(x = forcings[["Hwater"]], rule = 2)

    PertFlux <- PertBW <- PertBW2 <- NULL 
    ev       <- events
    ev$time  <- ev$time[ev$time >= min(times) & 
                        ev$time <= max(times)]

    ZZ <- c(ZZ, capture.output(suppressWarnings(   
      DYN <- ode.1D(y = yini, times = times, 
                   func      = func, 
                   initfunc  = "initfemsdia", 
                   initforc  = "initfemsforc", 
                   dllname   = "FEMSDIA", 
                   initpar   = initpar, forcings = forcings,  
                   method    = "lsodes", lrw = lrw, 
                   bandwidth = band, nspec = nspec, 
                   names     = .FEMSDIA$y_names, 
                   nout      = .FEMSDIA$nout, outnames = .FEMSDIA$outnames,
                   events    = ev, ...)
  )))
  
  colnames(DYN)[2:(nspec*N+1)] <- as.vector(
         sapply(.FEMSDIA$y_names, 
                FUN = function(x) rep(x, times = N)))
  
  if (dynamicbottomwater) {
    cn <- colnames(DYN)
    cn[seq(2, by = N, length.out = nspec)] <- paste(.FEMSDIA$y_names, "_bw", sep ="")
    colnames(DYN) <- cn
  }
  if (verbose) print (ZZ)
  
  attr(DYN, "depth")          <- iniP$depth
  attr(DYN, "dx")             <- iniP$dx
  attr(DYN, "porosity")       <- iniP$porosity
  attr(DYN, "bioturbation")   <- iniP$bioturbation
  attr(DYN, "irrigation")     <- iniP$irrigation
  attr(DYN, "DistReact")      <- iniP$DistReact
  
  attr(DYN, "parms")          <- iniP$parms
  attr(DYN, "perturb_fluxes") <- data.frame(time = perturb_times[1:nrow(PertFlux)], 
                                             PertFlux)
  if (dynamicbottomwater) {
    attr(DYN, "BWbeforePert") <- data.frame(time = PertBW [1:nrow(PertBW)], 
                                            PertBW)
    attr(DYN, "BWafterPert")  <- data.frame(time = PertBW2[1:nrow(PertBW2)], 
                                            PertBW2)
  }
  attr(DYN, "perturb_settings") <- list(
                perturb_type    = perturb_type, 
                perturb_times   = perturb_times, 
                perturb_depth   = perturb_depth, 
                perturb_concfac = perturb_concfac)
  
  attr(DYN, "warnings")     <- ZZ
  attr(DYN, "dynamicpH")           <- dynamicpH
  attr(DYN, "dynamicbottomwater")  <- dynamicbottomwater
  attr(DYN, "model")        <- "FEMSDIA_run_perturb"
  attr(DYN, "units")        <- .FEMSDIA$outunits
  
  class(DYN) <- c("FEMSDIAdyn", class(DYN))
  
  return(DYN)
 
}  # FEMSDIA_run_perturb

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Retrieve perturbation fluxes
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIA_get_perturb_fluxes <- function(out, which = NULL) {
  
  if (missing(out)) 
    stop("object 'out' should be given")
  
  if (! inherits (out, "FEMSDIAdyn"))
     stop("perturbation fluxes can only be obtained from a run ", 
          "performed with 'FEMSDIA_run_dyna' or 'FEMSDIA_run_perturb'" )
    
  W <- attributes(out)$perturb_fluxes
    
  if (! is.null(W)) { 
    if (! is.null(which))
      W <- cbind(W$time, W[,which])
  }
  return(W)
}  

## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------
## Retrieve perturbation settings
## -----------------------------------------------------------------------------
## -----------------------------------------------------------------------------

FEMSDIA_get_perturb_settings <- function(out) {
  
  if (missing(out)) 
    stop("object 'out' should be given")
  
  if (! inherits (out, "FEMSDIAdyn"))
    stop("perturbation settings can only be obtained from a run ",
         "performed with 'FEMSDIA_run_dyna' or 'FEMSDIA_run_perturb'" )
    
  W <- attributes(out)$perturb_settings
  return(W)
}  
