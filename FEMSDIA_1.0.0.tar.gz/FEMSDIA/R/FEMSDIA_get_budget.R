###########################################################################
#####             FEMSDIA: C, N, P, O2, Fe, Mn diagenesis                  #####
#####                     BUDGETTING                                     #####
###########################################################################

##------------------------------------
# Utility functions
##------------------------------------

dVal <- function(out)  {# derivative
  
  toty <- c(
     "time", paste("Total", .FEMSDIA$y_names, sep = "")) 
  
  if (inherits(out, c("PHDIAstd", "PHDIAdyn")))
    toty <- c(toty, "TotalCALC", "TotalARAG")

  OUT <- out[c(1, nrow(out)), toty]
  as.list((OUT[2,]-OUT[1,])/(OUT[2,1]-OUT[1,1]))
}

getMean0D <- function(out){ # mean value, taking into account unequal times
  OUT <- FEMSDIA_get_0Dvars(out)
  on  <- OUT$name
  OUT <- as.list(OUT$value)
  names(OUT) <- on
  return(OUT)
}

#====================#
# budget wrapper     #
#====================#

## -----------------------------------------------------------------------------

FEMSDIA_get_budget_all <- function(out, ..., 
   which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat"), 
   func = FEMSDIA_get_budgetO2_one, args) {
  which <- match.arg(which, 
                     choices = c("All", "Rates", "Fluxes", "Losses", "Fluxmat"))
  if ("All" %in% which)
    which <- c("Rates", "Fluxes", "Losses", "Fluxmat", "Delta", "dC")
  
  ALL  <- list(out, ...)
  
  NM <- unlist(lapply(args[-1], as.character))  # this does not always work
  if (! is.null(names(NM)))
    NM <- NM[!names(NM) == "which"]
  if (length(NM) != length(ALL)) NM <- paste("out", 1:length(ALL), sep = "_")
  
  budg <- func(out)  
  budgFlux    <- budg$Fluxes
  budgRates   <- budg$Rates
  budgLoss    <- budg$Losses
  budgdC      <- data.frame(names = names(budg$dC), dC = budg$dC)
  budgDelta   <- budg$Delta
  budgFluxmat <- budg$Fluxmat
  
  if (length(ALL) > 1) {
    
    budgFlux    <- unlist(budgFlux)
    budgRates   <- unlist(budgRates)
    budgFluxmat <- list(budgFluxmat)
    for ( i in 2:length(ALL)) {
      budg <- func(ALL[[i]])
      
      budgFlux    <- cbind(budgFlux,    unlist(budg$Fluxes))
      budgRates   <- cbind(budgRates,   unlist(budg$Rates))
      budgLoss    <- c(budgLoss,        budg$Losses)
      #    budgPerturb <- cbind(unlist(budgPerturb), budg$Perturb)
      bdC         <- data.frame(names = names(budg$dC), dC = budg$dC)
      budgdC      <- merge(budgdC, bdC, by = "names", all.x = TRUE)
      budgDelta   <- c(budgDelta, budg$Delta)
      budgFluxmat[[i]]  <- budg$Fluxmat
    } 
    
    cn <- rep(names(budg$Fluxes), each = 4)
    nc <- nchar(cn)
    cn <- paste (cn, c("surf", "deep", "perturb", "net"), sep="")
    
    rownames(budgFlux) <- cn
  }
  
  budg <- list()
  if ("Rates" %in% which){
    if(length(NM) > 1) colnames(budgRates) <- NM
    budg$Rates <- budgRates
  }
  if ("Fluxes" %in% which){
    if(length(NM) > 1) colnames(budgFlux) <- NM
    budg$Fluxes <- budgFlux
  }
  if ("Losses" %in% which){
    if(length(NM) > 1) names(budgLoss) <- NM
    budg$Losses <- budgLoss
  }
  if ("Fluxmat" %in% which){
    if(length(NM) > 1) names(budgFluxmat) <- NM
    budg$Fluxmat <- budgFluxmat
  }
  if ("dC" %in% which){
    if(length(NM) > 1) colnames(budgdC)[-1] <- NM
    budg$dC <- budgdC
  }
  if ("Delta" %in% which){
    if(length(NM) > 1) names(budgDelta) <- NM
    budg$Delta <- budgDelta
  }
  
  return(budg)
}    

## --------------------------------------------------------------------------------------------------

FEMSDIA_get_budgetO2 <- function(out, ..., 
                           which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetO2_one, args = sys.call())  

FEMSDIA_get_budgetC <- function(out, ..., 
                          which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetC_one, args = sys.call())  

FEMSDIA_get_budgetN <- function(out, ..., 
                          which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetN_one, args = sys.call())  

FEMSDIA_get_budgetP <- function(out, ..., 
                          which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetP_one, args = sys.call())  

FEMSDIA_get_budgetS <- function(out, ..., 
                          which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetS_one, args = sys.call())  

FEMSDIA_get_budgetFe <- function(out, ..., 
                           which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetFe_one, args = sys.call())  

FEMSDIA_get_budgetMn <- function(out, ..., 
                           which = c("All", "Rates", "Fluxes", "Losses", "Fluxmat")) 
  FEMSDIA_get_budget_all(out, ..., which = which, 
                   func = FEMSDIA_get_budgetMn_one, args = sys.call())  

FEMSDIA_get_budgetO2_one <- function(out) {

  pertFlux <- attributes(out)$perturb_fluxes
  pF <- NULL
  if (! is.null(pertFlux)){
   pF <- colSums(pertFlux)/diff(range(out[,1]))
  }

  dC <- NULL
  if (inherits(out, "deSolve")){
    dC  <- dVal(out)
    out <- getMean0D(out)
  }
  
  Cflux <- out$O2flux - out$O2deepflux

  Fluxes <- data.frame(O2 = c(out$O2flux, out$O2deepflux))
  if(! is.null(pF)) 
     Fluxes <- rbind(Fluxes, perturb = unlist(pF[c("O2")]))
  else
     Fluxes <- rbind(Fluxes, perturb = c(0))
  Fluxes           <- rbind(Fluxes, Fluxes[1,] - Fluxes[2,] + Fluxes[3,])                     
  rownames(Fluxes) <- c("surface", "bottom", "perturb", "netin")

  Rates <- data.frame(
    Nitrification      = out$TotNitri1*1.5 + out$TotNitri2*0.5,
    FeOxidation        = 0.25*out$TotFeoxid,
    H2Soxidation       = 2.  *out$TotH2Soxid,
    CH4oxidation       = 2.  *out$TotCH4oxid,
    H2Soxid.dist       = 2.  *out$TotH2Soxsurf,
    CH4oxid.dist       = 2.  *out$TotCH4oxsurf,
    MnOxidation        =      out$TotMnoxid,    # MTM
    FeSoxidation       = 2.  *out$TotFeSoxid,   # MTM
    FeS2oxidation      = 3.5 *out$TotFeS2oxid, # MTM
    OxicMineralisation =      out$TotOxic,
    MPBO2production    =      out$TotMPBO2prod,
    MPBO2respiration   = 0)
 
  Rfac <- c(-1, -1, -1, -1,  -1,  -1,  -1, -1, -1, -1, +1, -1)
  
  Rates$Total = sum(Rates * Rfac)   

  rownames(Rates) <- "mmolO2/m2/d" 
  
  mat <- matrix (nrow = 9, ncol = 9, data = 0)
  rownames(mat) <- colnames(mat) <- c("Ext", "O2", "NO2", "NO3", "DIC", "SO4", "FeOH3", "Burial",  "MnO2")
  mat["Ext", "O2"] <- out$O2flux * (out$O2flux > 0)      
  mat["O2", "Ext"]    <- -out$O2flux    * (out$O2flux     < 0)      
  mat["O2", "Burial"] <-  out$O2deepflux* (out$O2deepflux > 0)   
  mat["Burial", "O2"] <- -out$O2deepflux* (out$O2deepflux < 0)   
  mat["O2", "DIC"]    <- Rates$OxicMineralisation + Rates$MPBO2respiration + 
                         Rates$CH4oxidation + Rates$CH4oxid.dist
  mat["O2", "NO2"]    <- out$TotNitri1*1.5
  mat["O2", "NO3"]    <- out$TotNitri2*0.5
  mat["O2", "SO4"]    <- Rates$H2Soxidation + Rates$H2Soxid.dist +
                         Rates$FeSoxidation + Rates$FeS2oxidation  # MTM 
  mat["O2", "FeOH3"]  <- Rates$FeOxidation
  mat["DIC", "O2"]    <- Rates$MPBO2production
  mat["O2", "MnO2"]   <- Rates$MnOxidation  # MTM (+H2O)??

  if (is.null(dC))
    dC <- rowSums(mat) - colSums(mat)
  else 
    dC <- c(O2 = dC$TotalO2)
  return(list(
     Fluxes = Fluxes, Rates = Rates, Losses = out$O2deepflux, dC = c(dC, sum = sum(dC)), 
     Delta = Cflux + Rates$Total, Fluxmat = mat))                 
}


FEMSDIA_get_budgetC_one <- function(out) {

  Parms <- FEMSDIA_get_parms(out, TRUE)  
  hasPH <- inherits(out, c("PHDIAstd", "PHDIAdyn"))
  
  pertFlux <- attributes(out)$perturb_fluxes
  pF <- NULL
  if (! is.null(pertFlux)){
   pF <- colSums(pertFlux)/diff(range(out[,1]))
  }
    
  dV <- NULL
  if (inherits(out, "deSolve")){
    dV  <- dVal(out)
    out <- getMean0D(out)
  }

  Fluxes <- data.frame(FDET    = c(out$FDETflux, out$FDETdeepflux), 
                       SDET    = c(out$SDETflux, out$SDETdeepflux), 
                       RDET    = c(out$RDETflux, out$RDETdeepflux), 
                       DIC     = c(out$DICflux,  out$DICdeepflux),
                       CH4     = c(out$CH4flux,  out$CH4deepflux),
                       CinCaP  = c(out$CaPflux,  out$CaPdeepflux)*Parms[["CPrCaP"]])
  if (hasPH) Fluxes <- cbind (Fluxes, 
                       CALC    = c(out$CALCflux,  out$CALCdeepflux), 
                       ARAG    = c(out$ARAGflux,  out$ARAGdeepflux))
  else  Fluxes <- cbind (Fluxes, 
                       CALC   = c(0, 0), 
                       ARAG    = c(0,  0))
  
  if(! is.null(pF)) Fluxes <- rbind(Fluxes, 
    perturb = c(unlist(pF[c("FDET", "SDET", "RDET", "DIC", "CaP")]) * 
                       c(1,1,1,1,Parms[["CPrCaP"]])), 0,0)
  else
     Fluxes <- rbind(Fluxes, perturb = c(0, 0, 0, 0, 0, 0, 0, 0))

  Fluxes           <- rbind(Fluxes, Fluxes[1,] - Fluxes[2,] + Fluxes[3,])                     
  rownames(Fluxes) <- c("surface", "bottom", "perturb", "netin")
  Fluxes$Total <- rowSums(Fluxes)
  influx <- Fluxes[1,"Total"]
  burial <- Fluxes[2,"Total"]
  Cflux   <- influx - burial

  Rates <- data.frame(
    OxicMineralisation = out$TotOxic,
    Denitrification    = out$TotDenit,
    MnReduction        = out$TotMnred,
    IronReduction      = out$TotFered,
    SulphateReduction  = out$TotBSR,
    Methanogenesis     = out$TotMeth,
    TotalMineralisation = out$TotMin,  
    CH4oxidation       = out$TotCH4oxid,
    CH4oxid.dist       = out$TotCH4oxsurf,
    CH4oxidAOM         = out$TotAOM,
    MPBDICuptake       = out$TotMPBDICuptake,
    MPBFDETproduction  = -out$TotMPBDICuptake,
    MPBResp            = 0,
    CaPprecipitation   = out$TotCaPprod*Parms[["CPrCaP"]],
    CaPdissolution     = out$TotCaPdiss*Parms[["CPrCaP"]],
    CALCdissolution    = 0,
    ARAGdissolution    = 0,
    CALCproduction     = 0,
    MnCO3production    = out$TotMnCO3prod, 
    FeCO3production    = out$TotFeCO3prod  

    )
  if (hasPH){
    Rates$CALCdissolution   <- out$TotCALCdiss
    Rates$ARAGdissolution   <- out$TotARAGdiss
    Rates$CALCproduction    <- out$TotCALCprod
    }
    rownames(Rates) <- "mmolC/m2/d"  

      # derivatives
  mat <- matrix (nrow = 11, ncol = 11, data = 0)
  rownames(mat) <- colnames(mat) <- c("Ext", "DET", "DIC", "CaP", "CH4", "MPB", 
                                      "CALC", "ARAG", "Burial",  
                                      "MnCO3", "FeCO3")
  mat["Ext", "DET"]    <-  out$FDETflux      + out$SDETflux     + out$RDETflux
  mat["DET", "Burial"] <-  out$FDETdeepflux  + out$SDETdeepflux + out$RDETdeepflux
  mat["Ext", "DIC"]    <-  out$DICflux     * (out$DICflux > 0) 
  mat["DIC", "Ext"]    <- -out$DICflux     * (out$DICflux < 0)
  mat["Burial", "DIC"] <- -out$DICdeepflux * (out$DICdeepflux < 0)
  mat["DIC", "Burial"] <-  out$DICdeepflux * (out$DICdeepflux > 0) 
  mat["Ext", "CaP"] <- 0
  mat["CaP", "Ext"] <- out$CaPdeepflux*Parms[["CPrCaP"]] 

  mat["MPB", "DET"] <- Rates$MPBFDETproduction 
  mat["DET", "DIC"] <- Rates$TotalMineralisation - 0.5*Rates$Methanogenesis
  mat["DIC", "MPB"] <- Rates$MPBDICuptake
  mat["DIC", "CaP"] <- Rates$CaPprecipitation
  mat["CaP", "DIC"] <- Rates$CaPdissolution
  mat["MPB", "DIC"] <- Rates$MPBResp 
  mat["DET", "CH4"] <- 0.5*Rates$Methanogenesis
  mat["CH4", "DIC"] <- Rates$CH4oxidation + Rates$CH4oxid.dist + Rates$CH4oxidAOM
  mat["DIC", "MnCO3"] <- Rates$MnCO3production # MTM
  mat["DIC", "FeCO3"] <- Rates$FeCO3production # MTM

  if (hasPH){
    mat["Ext", "CALC"]    <-  out$CALCflux * (out$CALCflux > 0) 
    mat["CALC", "Ext"]    <- -out$CALCflux * (out$CALCflux < 0)
    mat["Ext", "ARAG"]    <-  out$ARAGflux * (out$ARAGflux > 0) 
    mat["ARAG", "Ext"]    <- -out$ARAGflux * (out$ARAGflux < 0)
    mat["Burial", "CALC"] <- - out$CALCdeepflux*(out$CALCdeepflux < 0)
    mat["CALC", "Burial"] <- + out$CALCdeepflux*(out$CALCdeepflux > 0) 
    mat["Burial", "ARAG"] <- - out$ARAGdeepflux*(out$ARAGdeepflux < 0)
    mat["ARAG", "Burial"] <- + out$ARAGdeepflux*(out$ARAGdeepflux > 0) 
    mat["DIC", "CALC"]    <- Rates$CALCproduction
    mat["CALC", "DIC"]    <- Rates$CALCdissolution
    mat["ARAG", "DIC"]    <- Rates$ARAGdissolution
  }
  # derivatives
  
  if (is.null(dV)) 
    dC <- rowSums(mat) - colSums(mat)
  else
    dC <- c(DET   = dV$TotalFDET + dV$TotalSDET + dV$TotalRDET,
            DIC   = dV$TotalDIC, 
            CaP   = dV$TotalCaP, 
            CH4   = dV$TotalCH4  , 
            CALC  = dV$TotalCALC, 
            ARAG  = dV$TotalARAG)


  return(list(Fluxes = Fluxes, Rates = Rates, Losses = burial, 
              dC = c(dC, sum = sum(dC)), 
              Delta = influx- burial, Fluxmat = mat))                 
 
}

FEMSDIA_get_budgetS_one <- function(out) {

  Parms <- FEMSDIA_get_parms(out, TRUE)  

  pertFlux <- attributes(out)$perturb_fluxes
  pF <- NULL
  if (! is.null(pertFlux)){
   pF <- colSums(pertFlux)/diff(range(out[,1]))
  }
    
  dV <- NULL
  if (inherits(out, "deSolve")){
    dV  <- dVal(out)
    out <- getMean0D(out)
  }

  Fluxes <- data.frame(H2S  = c(out$H2Sflux, out$H2Sdeepflux), 
                       SO4  = c(out$SO4flux, out$SO4deepflux),
                       FeS  = c(0,           out$FeSdeepflux),     
                       FeS2 = c(0,           out$FeS2deepflux),    
                       S0   = c(0,           out$S0deepflux)) 

  if(! is.null(pF)) Fluxes <- rbind(Fluxes, 
    perturb = unlist(pF[c("H2S", "SO4")]))
  else
    Fluxes <- rbind(Fluxes, perturb = c(0, 0))

  Fluxes           <- rbind(Fluxes, Fluxes[1,] - Fluxes[2,] + Fluxes[3,])                     
  rownames(Fluxes) <- c("surface", "bottom", "perturb", "netin")
  Fluxes$Total <- rowSums(Fluxes)
  influx <- Fluxes[1,"Total"]
  burial <- Fluxes[2,"Total"]
  Cflux   <- influx - burial

  Rates <- data.frame(
    SulphateReduction = 0.5*out$TotBSR,
    H2Soxidation      = out$TotH2Soxid,
    H2Soxid.dist      = 2.*out$TotH2Soxsurf,
    AOM               = out$TotAOM,
    FeSproduction     = out$TotFeSprod, 
    H2Soxid.Mnox      = out$TotH2SMnoxid,     
    H2Soxid.Feox      = out$TotH2SFeoxid,     
    FeS2prod.S0       = out$TotFeS2prod,    
    FeS2prod.H2S      = out$TotFeS2prodB,   
    FeSoxidation      = out$TotFeSoxid,     
    FeS2oxidation     = 2.*out$TotFeS2oxid  
  )      
  rownames(Rates) <- "mmolS/m2/d" 


  mat <- matrix (nrow = 7, ncol = 7, data = 0)
  rownames(mat) <- colnames(mat) <- c("Ext", "H2S", "SO4", 
    "Burial", "FeS", "FeS2", "S0")
  mat["Ext", "H2S"]    <- out$H2Sflux*(out$H2Sflux>1)
  mat["H2S", "Ext"]    <- -out$H2Sflux*(out$H2Sflux<1)
  mat["H2S", "Burial"] <- out$H2Sdeepflux*(out$H2Sdeepflux>0)
  mat["Burial", "H2S"] <- -out$H2Sdeepflux*(out$H2Sdeepflux<0)
  
  mat["Ext", "SO4"]    <-  out$SO4flux * (out$SO4flux > 0) 
  mat["SO4", "Ext"]    <- -out$SO4flux * (out$SO4flux < 0)
  mat["Burial", "SO4"] <- - out$SO4deepflux*(out$SO4deepflux < 0)
  mat["SO4", "Burial"] <- + out$SO4deepflux*(out$SO4deepflux > 0) 

  mat["Ext", "FeS"]    <- 0                      # MTM
  mat["FeS", "Burial"] <- out$FeSdeepflux        # MTM

  mat["Ext", "FeS2"]   <- 0                      # MTM
  mat["FeS2", "Burial"]<- out$FeS2deepflux       # MTM

  mat["Ext", "S0"]     <- 0                      # MTM
  mat["S0", "Burial"]  <- out$S0deepflux         # MTM

  mat["SO4", "H2S"] <- Rates$SulphateReduction
  mat["H2S", "SO4"] <- Rates$H2Soxidation + Rates$H2Soxid.dist + Rates$AOM 
  mat["H2S", "FeS"] <- Rates$FeSproduction
  mat["FeS", "FeS2"] <- Rates$FeS2prod.S0 + Rates$FeS2prod.H2S          # MTM
  mat["H2S", "FeS2"] <- Rates$FeS2prod.H2S                              # MTM
  mat["S0",  "FeS2"] <- Rates$FeS2prod.S0                               # MTM 
  mat["FeS", "SO4"]  <- Rates$FeSoxidation                              # MTM 
  mat["FeS2", "SO4"] <- Rates$FeS2oxidation                             # MTM ??
  mat["H2S",  "S0"]  <- Rates$H2Soxid.Mnox + Rates$H2Soxid.Feox         # MTM 

  # derivatives
  if (is.null(dV)) 
    dC <- rowSums(mat) - colSums(mat)
  else
    dC = c(H2S = dV$TotalH2S, SO4 = dV$TotalSO4, FeS = dV$TotalFeS)

  return(list(Fluxes = Fluxes, Rates = Rates, 
      Losses = burial+dC[["FeS"]], dC = c(dC, sum = sum(dC)), 
      Delta = sum(dC), Fluxmat = mat))                 

}

FEMSDIA_get_budgetMn_one <- function(out) {
}

FEMSDIA_get_budgetFe_one <- function(out) {

  Parms <- FEMSDIA_get_parms(out, TRUE)  

  pertFlux <- attributes(out)$perturb_fluxes
  pF <- NULL
  if (! is.null(pertFlux)){
   pF <- colSums(pertFlux)/diff(range(out[,1]))
  }
    
  dV <- NULL
  if (inherits(out, "deSolve")){
    dV  <- dVal(out)
    out <- getMean0D(out)
  }

  Fluxes <- data.frame(Fe    = c(out$Feflux,    out$Fedeepflux), 
                       FeOH3 = c(out$FeOH3flux, out$FeOH3deepflux),
                       FeS   = c(0,             out$FeSdeepflux), 
                       FeS2  = c(0,             out$FeS2deepflux))

  if(! is.null(pF)) Fluxes <- rbind(Fluxes, 
    perturb = unlist(pF[c("Fe", "FeOH3")]))
  else
     Fluxes <- rbind(Fluxes, perturb = c(0, 0))

  Fluxes           <- rbind(Fluxes, Fluxes[1,] - Fluxes[2,] + Fluxes[3,])                     
  rownames(Fluxes) <- c("surface", "bottom", "perturb", "netin")
  Fluxes$Total <- rowSums(Fluxes)
  influx <- Fluxes[1,"Total"]
  burial <- Fluxes[2,"Total"]
  Cflux   <- influx - burial

   Rates <- data.frame(
    IronReduction = 4.*out$TotFered,
    FeOxidation   = out$TotFeoxid,
    FeSproduction = out$TotFeSprod, 
    FeS2prod.S0   = out$TotFeS2prod,      
    FeS2prod.H2S  = 2.*out$TotFeS2prodB, 
    H2Soxid.Feox  = 2.*out$TotH2SFeoxid,   
    FeSoxidation  = out$TotFeSoxid,      
    FeS2oxidation = out$TotFeS2oxid,      
    Feoxid.Mnox   = 2.*out$TotFeMnoxid,  
    FeCO3production = out$TotFeCO3prod    
  )      
  rownames(Rates) <- "mmolFe/m2/d" 

  
  mat <- matrix (nrow = 7, ncol = 7, data = 0)
  rownames(mat) <- colnames(mat) <- c("Ext", "Fe", "FeOH3", "Burial", 
                          "FeS", "FeS2", "FeCO3")
  mat["Ext", "FeOH3"] <- out$FeOH3flux*(out$FeOH3flux>1)
  #mat["FeOH3", "Ext"]    <- -out$FeOH3flux   *(out$FeOH3flux<0)  # ??? FeOH3flux<1 MTM
  mat["FeOH3", "Burial"] <- out$FeOH3deepflux*(out$FeOH3deepflux>0)
  #mat["Burial", "FeOH3" ]<- -out$FeOH3deepflux*(out$FeOH3deepflux<0) # ?? MTM
  
  mat["Ext", "Fe"]       <-  out$Feflux     * (out$Feflux > 0) 
  mat["Fe", "Ext"]       <- -out$Feflux     * (out$Feflux < 0)
  mat["Burial", "Fe"]    <- - out$Fedeepflux*(out$Fedeepflux < 0)
  mat["Fe", "Burial"]    <- + out$Fedeepflux*(out$Fedeepflux > 0) 
  
  mat["Ext", "FeS"]      <- 0                                       # MTM
  mat["FeS", "Burial"]   <- out$FeSdeepflux                         # MTM

  mat["Ext", "FeS2"]     <- 0                                       # MTM
  mat["FeS2", "Burial"]  <- out$FeS2deepflux*(out$FeS2deepflux < 0) # MTM

  
  mat["FeOH3", "Fe"] <- Rates$IronReduction
  mat["Fe", "FeOH3"] <- Rates$FeOxidation
  mat["Fe", "FeS"]   <- Rates$FeSproduction
  mat["FeS", "FeS2"] <- Rates$FeS2prod.S0 + Rates$FeS2prod.H2S    # MTM
  mat["FeS", "Fe"]   <- Rates$FeSoxidation                        # MTM 
  mat["FeS2", "Fe"]  <- Rates$FeS2oxidation                       # MTM 
  mat["FeOH3", "Fe"] <- Rates$H2Soxid.Feox                        # MTM 
  mat["Fe", "FeOH3"] <- Rates$Feoxid.Mnox                         # MTM
  mat["Fe", "FeCO3"] <- Rates$FeCO3production                     # MTM

  # derivatives
  if (is.null(dV)) 
    dC <- rowSums(mat) - colSums(mat)
  else
    dC = c(H2S = dV$TotalFe, SO4 = dV$TotalFeOH3, FeS = dV$TotalFeS)

  return(list(Fluxes = Fluxes, Rates = Rates, loss = burial+dC[["FeS"]], dC = c(dC, sum = sum(dC)), 
     Delta = sum(dC), Fluxmat = mat))                 
}



FEMSDIA_get_budgetN_one <- function(out) {

  Parms <- FEMSDIA_get_parms(out, TRUE)  

  pertFlux <- attributes(out)$perturb_fluxes
  pF <- NULL
  if (! is.null(pertFlux)){
   pF <- colSums(pertFlux)/diff(range(out[,1]))
  }
    
  dV <- NULL
  if (inherits(out, "deSolve")){
    dV  <- dVal(out)
    out <- getMean0D(out)
  }

  Fluxes <- data.frame(FDET_N = c(out$FDETflux        *Parms[["NCrFdet"]] , 
                                  out$FDETdeepflux    *Parms[["NCrFdet"]] ), 
                       SDET_N = c(out$SDETflux        *Parms[["NCrSdet"]] , 
                                  out$SDETdeepflux    *Parms[["NCrSdet"]] ), 
                       RDET_N = c(out$RDETflux        *Parms[["NCrRdet"]] , 
                                  out$RDETdeepflux    *Parms[["NCrRdet"]] ), 
                       NO3  = c(out$NO3flux, out$NO3deepflux),
                       NO2  = c(out$NO2flux, out$NO2deepflux),
                       NH3  = c(out$NH3flux, out$NH3deepflux))
  if(! is.null(pF)) Fluxes <- rbind(Fluxes, 
    perturb = unlist(pF[c("FDET",          "SDET",             "RDET", 
                           "NO3", "NO2", "NH3")]) * 
                c(Parms[["NCrFdet"]], Parms[["NCrSdet"]], Parms[["NCrRdet"]],
                            1,     1,     1))
  else
     Fluxes <- rbind(Fluxes, perturb = c(0, 0, 0, 0))

  Fluxes           <- rbind(Fluxes, Fluxes[1,] - Fluxes[2,] + Fluxes[3,])                     
  rownames(Fluxes) <- c("surface", "bottom", "perturb", "netin")
  Fluxes$Total <- rowSums(Fluxes)
  influx <- Fluxes[1,"Total"]
  burial <- Fluxes[2,"Total"]
  Cflux   <- influx - burial

  Rates <- data.frame(
    NH3production   = out$TotNH3prod,
    Denitrification = out$TotDenit*0.8,
    MPBNO3consumption  = out$TotMPBNO3uptake,
    MPBNH3consumption  = out$TotMPBNH3uptake,
    Nitrification1     = out$TotNitri1,
    Nitrification2     = out$TotNitri2,
    Anammox            = out$TotAnammox,
    NH3adsorption      = out$TotNH3ads,
    N2production       = out$TotDenit*0.8 + 2*out$TotAnammox,
    MPBNdeath          = out$TotMPBNO3uptake + out$TotMPBNH3uptake,
    NH3prodMPBdeath    = 0,
    DETNprodMPBdeath   = out$TotMPBNO3uptake + out$TotMPBNH3uptake
  )

  rownames(Rates) <- "mmolN/m2/d" 

  # derivatives
  mat           <- matrix (nrow = 8, ncol = 8, data = 0)
  rownames(mat) <- colnames(mat) <- c("Ext", "DET", "NH3", "NO3", "NO2", "MPB", "N2", "Burial")
  mat["Ext", "DET"]    <- out$FDETflux*Parms[["NCrFdet"]]  + 
                          out$SDETflux*Parms[["NCrSdet"]]  +
                          out$RDETflux*Parms[["NCrRdet"]]  
  
  mat["DET", "Burial"] <- out$FDETdeepflux * Parms[["NCrFdet"]] + 
                          out$SDETdeepflux * Parms[["NCrSdet"]] +
                          out$RDETdeepflux * Parms[["NCrRdet"]]
  
  mat["Ext", "NH3"]    <-   out$NH3flux     * (out$NH3flux > 0) 
  mat["NH3", "Ext"]    <- - out$NH3flux     * (out$NH3flux < 0)
  mat["Burial", "NH3"] <- - out$NH3deepflux * (out$NH3deepflux < 0)
  mat["NH3", "Burial"] <- + out$NH3deepflux * (out$NH3deepflux > 0) 

  mat["Ext", "NO3"]    <-  out$NO3flux * (out$NO3flux > 0) 
  mat["NO3", "Ext"]    <- -out$NO3flux * (out$NO3flux < 0)
  mat["Burial", "NO3"] <- - out$NO3deepflux*(out$NO3deepflux < 0)
  mat["NO3", "Burial"] <- + out$NO3deepflux*(out$NO3deepflux > 0) 

  mat["Ext", "NO2"]    <-  out$NO2flux * (out$NO2flux > 0) 
  mat["NO2", "Ext"]    <- -out$NO2flux * (out$NO2flux < 0)
  mat["Burial", "NO2"] <- - out$NO2deepflux*(out$NO2deepflux < 0)
  mat["NO2", "Burial"] <- + out$NO2deepflux*(out$NO2deepflux > 0) 
  
  mat["MPB", "DET"] <- Rates$DETNprodMPBdeath 
  mat["DET", "NH3"] <- Rates$NH3production
  mat["NH3", "MPB"] <- Rates$MPBNH3consumption
  mat["NH3", "NO2"] <- Rates$Nitrification1
  mat["NH3", "N2"]  <- Rates$Anammox
  mat["MPB", "NH3"] <- Rates$NH3prodMPBdeath
  mat["NO3", "N2"]  <- Rates$Denitrification
  mat["NO3", "MPB"] <- Rates$MPBNO3consumption
  mat["NO2", "NO3"] <- Rates$Nitrification2
  mat["NO2", "N2"]  <- Rates$Anammox
  
  # derivatives
  if (is.null(dV)) 
    dC <- rowSums(mat) - colSums(mat)
  else
    dC = c(DET = dV$TotalFDET * Parms[["NCrFdet"]] + 
                 dV$TotalSDET * Parms[["NCrSdet"]] + 
                 dV$TotalRDET * Parms[["NCrRdet"]], 
           NH3 = dV$TotalNH3*(1+Parms[["NH3Ads"]]), 
           NO3 = dV$TotalNO3, NO2 = dV$TotalNO2)

  return(list(Fluxes = Fluxes, Rates = Rates, Losses = -dC["N2"]+burial, 
     dC = c(dC, sum = sum(dC)), Delta = sum(dC), Fluxmat = mat))                 

}

FEMSDIA_get_budgetP_one <- function(out) {

  Parms <- FEMSDIA_get_parms(out, TRUE)  

  pertFlux <- attributes(out)$perturb_fluxes
  pF <- NULL
  if (! is.null(pertFlux)){
   pF <- colSums(pertFlux)/diff(range(out[,1]))
  }
    
  dV <- NULL
  if (inherits(out, "deSolve")){
    dV  <- dVal(out)
    out <- getMean0D(out)
  }

  Fluxes <- data.frame(FDET_P = c(out$FDETflux     *Parms[["PCrFdet"]] , 
                                  out$FDETdeepflux *Parms[["PCrFdet"]] ), 
                       SDET_P = c(out$SDETflux     *Parms[["PCrSdet"]] , 
                                  out$SDETdeepflux *Parms[["PCrSdet"]]) , 
                       RDET_P = c(out$RDETflux     *Parms[["PCrRdet"]] , 
                                  out$RDETdeepflux *Parms[["PCrRdet"]]) , 
                       PO4  = c(out$PO4flux, out$PO4deepflux),
                       FeP  = c(0, out$FePdeepflux),
                       CaP  = c(0, out$CaPdeepflux))
  if(! is.null(pF)) Fluxes <- rbind(Fluxes, 
    perturb = unlist(pF[c("FDET",           "SDET",           "RDET", 
                        "PO4", "FeP", "CaP")]) * 
               c(Parms[["PCrFdet"]], Parms[["PCrSdet"]], Parms[["PCrRdet"]],
                         1,     1,     1))
  else
     Fluxes <- rbind(Fluxes, perturb = c(0, 0, 0, 0))

  Fluxes           <- rbind(Fluxes, Fluxes[1,] - Fluxes[2,] + Fluxes[3,])                     
  rownames(Fluxes) <- c("surface", "bottom", "perturb", "netin")
  Fluxes$Total <- rowSums(Fluxes)
  influx <- Fluxes[1,"Total"]
  burial <- Fluxes[2,"Total"]
  Cflux   <- influx - burial

 Rates <- data.frame(
    PO4production   = out$TotPO4prod,
    FePadsorption   = out$TotFePprod,
    FePdesorption   = out$TotFePdesorp,
    MPBPO4consumption  = out$TotMPBPO4uptake,
    CaPproduction   = out$TotCaPprod,
    CaPdissolution  = out$TotCaPdiss)                   
 
    Rates$MPBPdeath <- Rates$MPBPO4consumption
    Rates$PO4prodMPBdeath <- 0
    Rates$DETPprodMPBdeath <- Rates$MPBPO4consumption
      
   rownames(Rates) <- "mmolP/m2/d" 

     mat <- matrix (nrow = 7, ncol = 7, data = 0)
  rownames(mat) <- colnames(mat) <- c("Ext", "DET", "PO4", "FeP", "CaP", "MPB", "Burial")
  mat["Ext", "DET"]    <- out$FDETflux     * Parms[["PCrFdet"]]  + 
                          out$SDETflux     * Parms[["PCrSdet"]]  +
                          out$RDETflux     * Parms[["PCrRdet"]] 
  mat["DET", "Burial"] <- out$FDETdeepflux * Parms[["PCrFdet"]]  + 
                          out$SDETdeepflux * Parms[["PCrSdet"]]  +
                          out$RDETdeepflux * Parms[["PCrRdet"]]
  mat["Ext", "PO4"]    <-   out$PO4flux     * (out$PO4flux > 0) 
  mat["PO4", "Ext"]    <- - out$PO4flux     * (out$PO4flux < 0)
  mat["Burial", "PO4"] <- - out$PO4deepflux * (out$PO4deepflux < 0)
  mat["PO4", "Burial"] <- + out$PO4deepflux * (out$PO4deepflux > 0) 

  mat["Ext", "FeP"] <- 0
  mat["FeP", "Burial"] <- out$FePdeepflux
  mat["Ext", "CaP"] <- 0
  mat["CaP", "Burial"] <- out$CaPdeepflux
  
  mat["MPB", "DET"] <- Rates$DETPprodMPBdeath 
  mat["DET", "PO4"] <- Rates$PO4production
  mat["PO4", "MPB"] <- Rates$MPBPO4consumption
  mat["PO4", "FeP"] <- Rates$FePadsorption
  mat["FeP", "PO4"] <- Rates$FePdesorption
  mat["PO4", "CaP"] <- Rates$CaPproduction
  mat["CaP", "PO4"] <- Rates$CaPdissolution
  mat["MPB", "PO4"] <- Rates$PO4prodMPBdeath

  # derivatives
  if (is.null(dV)) 
    dC <- rowSums(mat) - colSums(mat)
  else
    dC = c(DET = dV$TotalFDET*Parms[["PCrFdet"]] + 
                 dV$TotalSDET*Parms[["PCrSdet"]] + 
                 dV$TotalRDET*Parms[["PCrRdet"]], 
      PO4 = dV$TotalPO4, FeP = dV$TotalFeP, CaP = dV$TotalCaP)

  return(list(Fluxes = Fluxes, Rates = Rates, Losses = burial, dC = c(dC, sum = sum(dC)), 
     Delta = sum(dC), Fluxmat = mat))                 
}

