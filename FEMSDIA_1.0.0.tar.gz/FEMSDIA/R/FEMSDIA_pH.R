################################################################################
######            FEMSDIA: C, N, P, Fe, Mn, S, O2 diagenesis              ######
################################################################################

## -----------------------------------------------------------------------------
## standalone pH module
## -----------------------------------------------------------------------------

FEMSDIA_extract <- function(out, which = NULL) {
  
  if (missing(out)) 
    stop("object 'out' should be given")
  
  if (inherits (out, "steady1D")) {
    if (which %in% colnames(out$y))
      W <- out$y[,which]
    else
      W <- out[[which]]
  } else W <- subset(out, which = which)  
  
  if (any(is.null(W))) W <- 0  
  return(W)
}

FEMSDIA_get_pH <- function (out) {

  P       <- FEMSDIA_get_parms(out, as.vector = TRUE)
  
  # temperature in sediment layers
  temp    <- as.vector(FEMSDIA_extract(out, which = "Temperature"))  
  S       <- P["Swater"]
  depth   <- P["Hwater"]
  D       <- sw_dens(S = S, t = temp)
  
  TA       <- FEMSDIA_extract(out, which = "ALK")/1000/D
  DIM      <- dim(TA)
  TA       <- as.vector(TA)
  len      <- length(TA)
  
  SumCO2   <- as.vector(FEMSDIA_extract(out, which = "DIC")/1000/D)  
  
  # convert to mol/kg
  SumNH4   <- as.vector(FEMSDIA_extract(out, which = "NH3")/1000/D)
  SumH2S   <- as.vector(FEMSDIA_extract(out, which = "H2S")/1000/D)
  SumH3PO4 <- as.vector(FEMSDIA_extract(out, which = "PO4")/1000/D)
  SumH2SO4 <- as.vector(FEMSDIA_extract(out, which = "SO4")/1000/D)
  SumHNO3  <- as.vector(FEMSDIA_extract(out, which = "NO3")/1000/D)
  SumHNO2  <- as.vector(FEMSDIA_extract(out, which = "NO2")/1000/D)
  
  
  A <- .Fortran ("EstimatePH", 
                 Temp = as.double(temp), Sal = as.double(S), depth = as.double(depth), 
                 TA = TA, SumCO2 = SumCO2, SumH3PO4 = SumH3PO4, 
                 SumNH4 = SumNH4, SumH2S = SumH2S, SumH2SO4 = SumH2SO4, 
                 maxIter = as.integer(5), numvals = as.integer(len), 
                 pH  = as.double(rep(8., times = len)), 
                 KS  = as.double(rep(0., 20)),
                 Cts = as.double(rep(0., times = 12)), 
                 iters = as.integer(rep(0, times = len)),
                 PACKAGE = "FEMSDIA")
  
#    PH <- aquaenv(S = S, t = temp, SumCO2 = SumCO2, SumNH4 = SumNH4, SumH2S = SumH2S, 
#                SumH3PO4 = SumH3PO4, SumH2SO4 = SumH2SO4, SumHNO3 = SumHNO3, TA = TA,
#                speciation = FALSE, skeleton = TRUE)$pH
  PH       <- A$pH
  K        <- A$KS    # dissociation constants
  
  names(K) <- c("K_W", "K_HF", "K_CO2", "K_HCO3", "K_BOH3", "K_NH4", "K_H2S",
                "K_HS", "K_H3PO4", "K_H2PO4", "K_HPO4", "K_HSO4", "K_H2SO4",
                "K0_CO2", "Ksp_Calcite", "Ksp_Aragonite",  "TotToFree",
                "SWSToFree", "SumBorate", "SumF")
  
  if (length(DIM)) dim(PH)      <- DIM
  attr(PH, "Diss_constants")    <- K
  attr(PH, "Other_constants")   <- A$Cts
  attr(PH, "iters")    <- A$iters
  PH
}


dpH.int <- function(out){
  por   <- FEMSDIA_get_por(out)
  dx    <- FEMSDIA_get_dx(out)
  phr   <- dpH.Rates(out)
  Rates <- apply(phr, MARGIN = 2, FUN = function(x) sum(x*por*dx))
  
}

  
dpH.Rates <- function(out, asH = FALSE){

  por <- FEMSDIA_get_por(out)
  
  getVars <- function(name, solid = FALSE){
    
    Var <- as.vector(FEMSDIA_extract(out, which = name))     # convert to mol
    
    if (solid)                       # correct for porosity
      Var <- Var*(1-por)/por
    
    Var
  }
  
  # change in summed conc due to process default = 0
  dPH.numeric <- function(dSumCO2   = 0, dSumBOH3 = 0, dSumH2S   = 0,     
                          dSumSiOH4 = 0, dSumNH4  = 0, dSumH3PO4 = 0,   
                          dSumHNO3  = 0, dSumHNO2 = 0, dSumHF    = 0, 
                          dSumH2SO4 = 0,    
                          dTA       = 0, dC = 1e-8  # change in total alkalinity        
                        ) {                      
    # pH range for which to estimate dpHdProcess
  
    P       <- FEMSDIA_get_parms(out, as.vector = TRUE)
    temp    <- P["Twater"]
    S       <- P["Swater"]
    D       <- sw_dens(S = S, t = temp)
  
  # reference settings
    pH      <- FEMSDIA_extract(out, which = "pH")
    
    # convert to mol/kg
    SumCO2   <- as.vector(FEMSDIA_extract(out, which = "DIC")/1000/D)  
    SumNH4   <- as.vector(FEMSDIA_extract(out, which = "NH3")/1000/D)
    SumH2S   <- as.vector(FEMSDIA_extract(out, which = "H2S")/1000/D)
    SumH3PO4 <- as.vector(FEMSDIA_extract(out, which = "PO4")/1000/D)
    SumH2SO4 <- as.vector(FEMSDIA_extract(out, which = "SO4")/1000/D)
    SumHNO3  <- as.vector(FEMSDIA_extract(out, which = "NO3")/1000/D)
    SumHNO2  <- as.vector(FEMSDIA_extract(out, which = "NO2")/1000/D)
    TA       <- as.vector(FEMSDIA_extract(out, which = "ALK")/1000/D)
  
  # perturbed settings
    delt      <- dC/1000/D
  
    SumCO2p   <- SumCO2   + delt*dSumCO2
    SumNH4p   <- SumNH4   + delt*dSumNH4
    SumH2Sp   <- SumH2S   + delt*dSumH2S
    SumH3PO4p <- SumH3PO4 + delt*dSumH3PO4
    SumH2SO4p <- SumH2SO4 + delt*dSumH2SO4
    SumHNO3p  <- SumHNO3  + delt*dSumHNO3
    SumHNO2p  <- SumHNO2  + delt*dSumHNO2
    TAp       <- TA       + delt*dTA

    DIM       <- dim(TA)
    TA        <- as.vector(TA)
    len       <- length(TA)
   
    # reference pH
    pHr <- .Fortran ("EstimatePH", Temp = temp, Sal = S, depth = 0., 
                     TA = TA, SumCO2 = SumCO2, SumH3PO4 = SumH3PO4, 
                     SumNH4 = SumNH4, SumH2S = SumH2S, SumH2SO4 = SumH2SO4,  
                     maxIter = as.integer(10), numvals = as.integer(len), 
                     pH  = as.double(rep(8., times = len)), 
                     KS  = as.double(rep(0., 20)),
                     Cts = as.double(rep(0., times = 12)), PACKAGE = "FEMSDIA")$pH
    
    if (asH) pHr <- 10^-pHr
   
    # perturbed pH
    pHp  <-.Fortran ("EstimatePH", Temp = temp, Sal = S, depth = 0., 
                     TA = TAp, SumCO2 = SumCO2p, SumH3PO4 = SumH3PO4p, 
                     SumNH4 = SumNH4p, SumH2S = SumH2Sp, SumH2SO4 = SumH2SO4p,   
                     maxIter = as.integer(10), numvals = as.integer(len), 
                     pH  = as.double(rep(8., times = len)), 
                     KS  = as.double(rep(0., 20)),
                     Cts = as.double(rep(0., times = 12)), 
                     PACKAGE = "FEMSDIA")$pH
    if (asH) pHp <- 10^-pHp
  

    # estimate dpHdspec by numerical differencing. Divide by 1e6 so that pH change is per micromol rather than per mol.
    dpH_dSpec <- (pHp - pHr)/(dC*1e6)  # units in per umolC  - DENSITY????
  
    return(dpH_dSpec)
  }

 DICprodMin     <- getVars("DICprod")
 NC             <- getVars("DINprod")/DICprodMin
 PC             <- getVars("DIPprod")/DICprodMin
 NC[is.nan(NC)] <- 0
 PC[is.nan(PC)] <- 0
 P       <- FEMSDIA_get_parms(out, as.vector = TRUE)
  
 NCf     <- P["NCrFdet"]
 PCf     <- P["PCrFdet"]
 
 pHeffect <- data.frame(
   Oxicmin.pH      = dPH.numeric(dSumCO2   = 1,   
                                 dSumNH4   = NC, 
                                 dSumH3PO4 = PC,                
                                 dTA       = NC-PC    ) * 
                                 getVars("Oxicmin",    TRUE),
   
   Denitrific.pH   = dPH.numeric(dSumCO2   = 1,   
                                 dSumNH4   = NC, 
                                 dSumH3PO4 = PC, 
                                 dSumHNO3  = -0.8, 
                                 dTA       = 0.8 + NC - PC) *
                                 getVars("Denitrific", TRUE),             
   
   Feredmin.pH     = dPH.numeric(dSumCO2   = 1,   
                                 dSumNH4   = NC, 
                                 dSumH3PO4 = PC,                
                                 dTA       = NC - PC + 8   ) *
                                 getVars("Feredmin",   TRUE),
   
   BSRmin.pH       = dPH.numeric(dSumCO2   = 1,   
                                 dSumNH4   = NC, 
                                 dSumH3PO4 = PC, 
                                 dSumH2SO4 = -0.5, 
                                 dSumH2S   = 0.5,
                                 dTA       = NC - PC + 1)    * 
                                 getVars("BSRmin",     TRUE), 
   
   Methmin.pH      = dPH.numeric(dSumCO2   = 0.5, 
                                 dSumNH4   = NC, 
                                 dSumH3PO4 = PC,                             
                                 dTA       = NC - PC)        * 
                                 getVars("Methmin",    TRUE), 

   Nitri1.pH       = dPH.numeric(dSumNH4   = -1,  
                                 dSumHNO2  =  1,             
                                 dTA       = -2)             * 
                                 getVars("Nitri1"),
   
   Nitri2.pH       = dPH.numeric(dSumHNO2  = -1, 
                                 dSumHNO3  = 1   )           * 
                                 getVars("Nitri2"),
   
   Anammox.pH      = dPH.numeric(dSumNH4   = -1, 
                                 dSumHNO2  = -1,            
                                 dTA       = 0   )           * 
                                 getVars("Anammox"),

   Feoxid.pH       = dPH.numeric(dTA       = -2)             * 
                                 getVars("Feoxid"),
   
   H2Soxid.pH      = dPH.numeric(dSumH2S   = -1, 
                                 dSumH2SO4 =  1,            
                                 dTA       = -2)             * 
                                 getVars("H2Soxid"),
   
   CH4oxid.pH      = dPH.numeric(dSumCO2   = 1,                          
                                 dTA       = 0)              * 
                                 getVars("CH4oxid"),
   
   AOM.pH          = dPH.numeric(dSumH2SO4 = -1, 
                                 dSumH2S   =  1, 
                                 dSumCO2   =  1, 
                                 dTA       =  2)             * 
                                 getVars("AOM"),

   FeSprod.pH      = dPH.numeric(dSumH2S   = -1.5, 
                                 dTA       =  0)             * 
                                 getVars("FeSprod"),
   
#   adsorption.pH    = dPH.numeric(              dTA=1)* getVars("AOM"),                           
   
#   CO2release.pH    = dPH.numeric(dSumCO2=-1,   dTA=0)* getVars("AOM"),
   
#   NH3release.pH    = dPH.numeric(dSumNH4=-1,   dTA=-1)* getVars("AOM"),
   
#   NH4release.pH    = dPH.numeric(dSumNH4=-1,   dTA=0)* getVars("AOM"),

   MPBCprod.pH      = dPH.numeric(dSumCO2  = -1)             * 
                                  getVars("MPBCprod"),
   
   MPBuptakeNH3.pH  = dPH.numeric(dSumNH4  = -NCf, 
                                  dTA      = -NCf)           * 
                                  getVars("MPBuptakeNH3"),
   
   MPBuptakeNO3.pH  = dPH.numeric(dSumHNO3 = -NCf, 
                                  dTA      = NCf)            * 
                                  getVars("MPBuptakeNO3"),
   
   MPBuptakePO4.pH  = dPH.numeric(dSumH3PO4= -PCf, 
                                  dTA      = PCf)            * 
                                  getVars("MPBuptakeNO3"),
   
   CALCprod.pH      = dPH.numeric(dSumCO2  = -1, 
                                  dTA      = -2)             * 
                                  getVars("CALCprod"),

   CALCdiss.pH      = dPH.numeric(dSumCO2  =  1,  
                                  dTA      =  2)             * 
                                  getVars("CALCdiss"),

   ARAGdiss.pH      = dPH.numeric(dSumCO2  =  1,  
                                  dTA      =  2)             * 
                                  getVars("ARAGdiss")
  )
 return(pHeffect)
}   
