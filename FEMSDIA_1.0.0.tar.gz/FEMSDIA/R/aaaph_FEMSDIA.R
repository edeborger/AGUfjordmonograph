## ====================================================================
## A local environment for non user-visible data,
## for pH part of the model
## ====================================================================

.PHDIA <- new.env()

##------------------------------------
## state variables
##------------------------------------

.PHDIA$y_units   <- c(
  CALC  = "mmolC/m3 solid", 
  ARAG  = "mmolC/m3 solid", 
  Ca    = "mmolCa/m3 liquid")

.PHDIA$y_names <- names(.PHDIA$y_units)

.PHDIA$y_description <- c(
  CALC  = "Calcite (calcium carbonate) concentration",  
  ARAG  = "Aragonite (calcium carbonate) concentratiion", 
  Ca    = "Calcium (Ca2+) concentration")

.PHDIA$ynamesall <- as.vector(sapply(.PHDIA$y_names, FUN = function(x) 
                                      rep(x, times = .FEMSDIA$N)))
                                      
##------------------------------------
## Parameters
##------------------------------------
                                      
.PHDIA$parms <- c(

  CALCflux  = 0.39*1e3/365  , # mmolC/m2/d   Calcite   deposition: 0.39 M/m2/yr
  ARAGflux  = 0.21*1e3/365  , # mmolC/m2/d   Aragonite deposition: 0.21 M/m2/yr
  rCALCdiss = 40/365        , # /d           Calcite   dissolution rate
  pCALC     = 2.74          , # -            calcite dissolution/precipitation power
  rARAGdiss = 110/365       , # /d           Aragonite dissolution
  pARAG     = 2.43          , # -            Aragonite dissolution/precipitation power
  rCALCprod = 1e-8          , # /mmol/m3/d   calcite precipitation rate
  
  Cabw      = 10000         , # mmol/m3      Ca++ conc in bottom water
  Cadw      = NA            , # mmol/m3      deep water concentration

  CALCfall  = 1             , # m/day        fall speed of suspended calcite (in dynamic bw)
  ARAGfall  = 1               # m/day        fall speed of suspended aragonite
)

.PHDIA$parms_names <- names(.PHDIA$parms)

.PHDIA$parms_units <- c(
  CALCflux  = "mmolC/m2/d", 
  ARAGflux  = "mmol/m2/d", 
  rCALCdiss = "/mmol/m3/d", 
  pCALC     = "-", 
  rARAGdiss = "/mmol/m3/d", 
  pARAG     = "-", 
  rCALCprod = "/mmol/m3/d", 
  Cabw      = "mmol/m3", 
  Cadw      = "mmol/m3", 
  CALCfall  = "m/d", 
  ARAGfall  = "m/d")

.PHDIA$parms_description <- c(
  CALCflux  = "Calcite (CaCO3) deposition rate", 
  ARAGflux  = "Aragonite (CaCO3) deposition rate", 
  rCALCdiss = "Calcite dissolution rate", 
  pCALC     = "Calcite dissolution/precipitation power", 
  rARAGdiss = "Aragonite dissolution/precipitation rate", 
  pARAG     = "Aragonite dissolution/precipitation power", 
  rCALCprod = "Calcite precipitation rate", 
  Cabw      = "Ca++ conc in bottom water", 
  Cadw      = "deep water Ca2+ concentration", 
  CALCfall  = "fall speed of suspended Calcite (if dynamic BW)", 
  ARAGfall  = "fall speed of suspended aragonite (if dynamic BW)")


##------------------------------------
## forcing functions 
##------------------------------------

.PHDIA$forc_units <- c(
  CALCflux  = "mmolC/m2/d", 
  ARAGflux  = "mmolC/m2/d", 
  bwCa      = "mmol/m3") 

.PHDIA$forc_names <- names(.PHDIA$forc_units)
  
.PHDIA$forc_description <- c(
  CALCflux  = "Calcite sediment-water deposition",
  ARAGflux  = "Aragonite sediment-water deposition",
  bwCa      = "Ca2+ bottom water concentration")

##------------------------------------
## Variables
##------------------------------------

.PHDIA$out0D_units <- c(
  Caflux        = "mmolCa/m2/d", 
  Cadeepflux    = "mmolCa/m2/d", 
  CALCdeepflux  = "mmolC/m2/d", 
  ARAGdeepflux  = "mmolC/m2/d", 
  TotCALCdiss   = "mmolC/m2/d", 
  TotARAGdiss   = "mmolC/m2/d", 
  TotCALCprod   = "mmolC/m2/d", 
  TotalCALC     = "mmolC/m2", 
  TotalARAG     = "mmolC/m2", 
  TotalCa       = "mmolCa/m2",
  KH2O          = "mol^2/kg-soln^2", 
  KHF           = "mol/kg-soln",
  KH2CO3        = "mol/kg-soln", 
  KHCO3         = "mol/kg-soln", 
  KBOH3         = "mol/kg-soln", 
  KNH4          = "mol/kg-soln", 
  KH2S          = "mol/kg-soln", 
  KHS           = "mol/kg-soln", 
  KH3PO4        = "mol/kg-soln",
  KH2PO4        = "mol/kg-soln", 
  KHPO4         = "mol/kg-soln", 
  KHSO4         = "mol/kg-soln", 
  KH2SO4        = "mol/kg-soln", 
  K0CO2         = "mol/(kg-soln/atm)", 
  KspCalcite    = "mol/kg-soln", 
  KspAragonite  = "mol/kg-soln", 
  TotToFree     = "-", 
  SWSToFree     = "-", 
  Borate        = "micromol/kg", 
  Fluoride      = "micromol/kg")

.PHDIA$out0D_names <- names(.PHDIA$out0D_units)

.PHDIA$out0D_description <- c(
  Caflux        = "Ca2+ influx sediment-water",  
  Cadeepflux    = "Ca2+ efflux lower boundary",
  CALCdeepflux  = "Calcite efflux lower boundary", 
  ARAGdeepflux  = "Aragonite efflux lower boundary",
  TotCALCdiss   = "Integrated Calcite dissolution", 
  TotARAGdiss   = "Integrated Aragonate dissolution",  
  TotCALCprod   = "Integrated Calcite production",  
  TotalCALC     = "Integrated Calcite concentration",  
  TotalARAG     = "Integrated Aragonite concentration", 
  TotalCa       = "Integrated Ca2+ (ion) concentration",  
  KH2O          = "ion product of water/dissociation ct of H2O",
  KHF           = "dissociation constant of HF-", 
  KH2CO3        = "dissociation constant of H2CO3",
  KHCO3         = "dissociation constant of HCO3-", 
  KBOH3         = "dissociation constant of BOH3",
  KNH4          = "dissociation constant of NH4+", 
  KH2S          = "dissociation constant of H2S", 
  KHS           = "dissociation constant of HS-", 
  KH3PO4        = "dissociation constant of H3PO4",
  KH2PO4        = "dissociation constant of H2PO4-", 
  KHPO4         = "dissociation constant of HPO4--",
  KHSO4         = "dissociation constant of HSO4-", 
  KH2SO4        ="dissociation constant of H2SO4", 
  K0CO2         = "CO2 solubility, Henrys ct", 
  KspCalcite    ="solubility product for calcite",
  KspAragonite  = "solubility product for aragonite", 
  TotToFree     = "conversion from total to free pH scale",
  SWSToFree     = "conversion from SWS to free pH scale", 
  Borate        = "Borate concentration", 
  Fluoride      = "Fluoride concentration")
 
 .PHDIA$out1D_units <- c(
  CALCdiss  = "mmolC/m3 solid/d", 
  ARAGdiss  = "mmolC/m3 solid/d", 
  CALCprod  = "mmolC/m3 liquid/d", 
  pH        = "-",  
  omegaCa   = "-", 
  omegaAr   = "-",
  CO3       = "mmolC/m3",
  CO2       = "mmolC/m3")

.PHDIA$out1D_names <- names(.PHDIA$out1D_units)

.PHDIA$out1D_description <- c(
  CALCdiss  = "Calcite dissolution profile",  
  ARAGdiss  = "Aragonite dissolution profile", 
  CALCprod  = "Calcite production profile", 
  pH        = "pH profile", 
  omegaCa   = "Calcite saturation state profile", 
  omegaAr   = "Aragonite saturation state profile", 
  CO3       = "CO3 concentration profile", 
  CO2       = "CO2 concentration profile")


.PHDIA$var1Dall <- as.vector(
      sapply(.PHDIA$out1D_names, 
             FUN = function(x) rep(x, times = .FEMSDIA$N)))

.PHDIA$outnames <- c(.PHDIA$out0D_names, 
                     .PHDIA$var1Dall, .PHDIA$forc_names)
.PHDIA$outunits <- c(
  as.vector(sapply(.PHDIA$y_units, 
                   FUN = function(x) rep(x, times = .FEMSDIA$N))),
  .PHDIA$out0D_units, 
  as.vector(sapply(.PHDIA$out1D_units, 
                  FUN = function(x) rep(x, times = .FEMSDIA$N))),
  .PHDIA$forc_units)

.PHDIA$nout <- length(.PHDIA$outnames)
