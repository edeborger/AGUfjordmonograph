##===========================================
## Interrogation Functions for FEMSDIA models
##===========================================

FEMSDIA_get_args <- function(f)
  data.frame(names   = names(formals(f)), 
             default = as.character(formals(f)))

##------------------------------------
## Get parameters and values
##------------------------------------

FEMSDIA_get_parms <- function(out = NULL, as.vector = FALSE, 
                              which = NULL, dynamicpH = FALSE) {


 if (is.null(out))
   Parms <- .FEMSDIA$parms
 else if (inherits(out, "PHDIAdyn") | inherits(out, "PHDIAstd"))
    return(PHDIA_get_parms(out = out, as.vector= as.vector, which = which)) 
 else if (inherits (out, "steady1D"))
   Parms <- out$parms[1:length(.FEMSDIA$parms)]
 else if (inherits (out, "deSolve"))
   Parms <- attr(out, "parms")[1:length(.FEMSDIA$parms)]
 else stop("object 'out' not supported")
 
 phP <- NULL
 if (dynamicpH){
   phP <- PHDIA_get_parms(out = out, as.vector = as.vector, which = which)
 }

  if (as.vector) {
   if (! is.null(which))
     Parms <- Parms[which]
     if (! is.null(phP)) Parms <- c(Parms, phP)
   
 } else {
    
    Units <- .FEMSDIA$parms_units
    if  (Parms["BCupLiq"] == 1) {  # upper boundary = FLUX
      i1 <- which(names(Parms) == "O2bw")
      Units[i1:(i1+11)] <- "mmol/m2/d"
    }  
    
    if  (Parms["BCdownLiq"] == 1) {
      i1 <- which(names(Parms) == "O2dw")
      Units[i1:(i1+11)] <- "mmol/m2/d"
    } 
    
    Parms <- data.frame(parms       = Parms, 
                        units       = Units, 
                        description = .FEMSDIA$parms_description)
    if (! is.null(which))
      Parms <- Parms[which, ]
     if (! is.null(phP)) Parms <- rbind(Parms, phP)
 } 
   return(Parms)
}

##------------------------------------

FEMSDIA_get_depth <- function(out = NULL) {
 if (is.null(out))
   D <- .FEMSDIA$Grid$x.mid
 else if (inherits (out, "steady1D"))
   D <- out$depth
 else if (inherits (out, "deSolve"))
   D <- attr(out, "depth")
 else stop("object 'out' not supported")
 D
} 

##------------------------------------

FEMSDIA_get_grid <- function(out = NULL) {
  if (is.null(out))
    D <- .FEMSDIA$Grid 
  else if (inherits (out, "steady1D"))
    D <- out$Grid
  else if (inherits (out, "deSolve"))
    D <- attr(out, "Grid")
  else stop("object 'out' not supported for grid calculation - try FEMSDIA_get_depth intstead")
  D
} 

##------------------------------------

FEMSDIA_get_dx <- function(out = NULL, mid = TRUE) {
  if (is.null(out))
    D <- .FEMSDIA$Grid$dx
  else if (inherits (out, "steady1D"))
    D <- out$dx
  else if (inherits (out, "deSolve"))
    D <- attr(out, "dx")
  else stop("object 'out' not supported")
  D
} 

##------------------------------------

FEMSDIA_get_biot <- function(out) {
  if (is.null(out))
    stop("out' needs to be given for the bioturbation")
  else if (inherits (out, "steady1D"))
    D <- out$bioturbation
  else if (inherits (out, "deSolve"))
    D <- attr(out, "bioturbation")
  else stop("object 'out' not supported")
  D
} 

##------------------------------------

FEMSDIA_get_irr <- function(out) {
  if (missing(out))
    stop("out' needs to be given for the irrigation")
  else if (inherits (out, "steady1D"))
    D <- out$irrigation
  else if (inherits (out, "deSolve"))
    D <- attr(out, "irrigation")
  else stop("object 'out' not supported")
  D
} 

##------------------------------------

FEMSDIA_get_por <- function(out) {
  if (missing(out))
    stop("out' needs to be given for the porosity")
  if (inherits (out, "steady1D"))
    D <- out$porosity
  else if (inherits (out, "deSolve"))
    D <- attr(out, "porosity")
  else stop("object 'out' not supported")
  D
} 

##------------------------------------
## time-averaged mean 
##------------------------------------

MeanVal <- function(out)  # takes into account unequal timing 
  (colSums(diff(out[,1])*(out[-1,]+out[-nrow(out),])*0.5)/(out[nrow(out),1]-out[1,1]))[-1]

##------------------------------------
## Get forcings 
##------------------------------------

FEMSDIA_get_forcs <- function(out, as.vector = FALSE, which = NULL) {
  if (missing(out)) {
    Dnames   <- .FEMSDIA$forc_names
    D        <- rep(NA, times = length(Dnames))
    names(D) <- Dnames
  } 
  
  if (inherits (out, "steady1D"))
    D <- unlist(out[.FEMSDIA$forc_names])
  
  else if (inherits (out, "deSolve"))
    D <- MeanVal(out[, c("time", .FEMSDIA$forc_names)])
  
  else stop("object 'out' not supported")
  
  if (! as.vector)
    D <- data.frame(names = names(D), values = D, 
                    units =  .FEMSDIA$forc_units,
                    description = .FEMSDIA$forc_description)
  
  if (! is.null(which)){
    if (is.vector(D))
      D <- D[which]
    else D <- D[which,]  
  } 
  row.names(D) <- NULL
  D
} 

##------------------------------------
## Get variables 
##------------------------------------

FEMSDIA_get_0Dvars <- function(out, as.vector = FALSE, which = NULL, 
  dynamicpH = FALSE) {
  if (missing(out)) {
    Dnames   <- c(.FEMSDIA$out0D_names, .FEMSDIA$forc_names)
    D        <- rep(NA, times = length(Dnames))
    names(D) <- Dnames
  } 
  
 else if (inherits(out, "PHDIAdyn") | inherits(out, "PHDIAstd"))
   return(PHDIA_get_0Dvars(out = out, as.vector = as.vector, which = which))

 else if (inherits (out, "steady1D"))
   D <- unlist(out[c(.FEMSDIA$out0D_names, .FEMSDIA$forc_names)])
 else if (inherits (out, "deSolve"))
   D <- MeanVal(out[, c("time",.FEMSDIA$out0D_names, .FEMSDIA$forc_names)])
 else stop("object 'out' not supported")

 if (! as.vector)
   D <- data.frame(names = names(D), values = D, 
      units = c(.FEMSDIA$out0D_units, .FEMSDIA$forc_units),
      description = c(.FEMSDIA$out0D_description, .FEMSDIA$forc_description))
 
 if (! is.null(which)){
   if (is.vector(D))
     D <- D[which]
   else D <- D[which,]  
 } 
 
 phP <- NULL
 if (dynamicpH){
   phP <- PHDIA_get_0Dvars(out = out, as.vector = as.vector, which = which)
 }
 if (! is.null(phP)) {
   if (is.vector(D)) 
      D <- c(D, phP)
   else
      D <- rbind(D, phP)
 }

 row.names(D) <- NULL
 D
} 

##------------------------------------

FEMSDIA_get_1Dvars <- function(out, which = NULL, 
  dynamicpH = FALSE) {
  if (missing(out)) {
    D <- data.frame(
            names = c(.FEMSDIA$y_names, .FEMSDIA$out1D_names), 
            units = c(.FEMSDIA$y_units, .FEMSDIA$out1D_units), 
            description = c(.FEMSDIA$y_description, .FEMSDIA$out1D_description))
    if (! is.null(which))
      D <- D[(D$names %in% which), ]
    return(D)
  }
  
  if (inherits (out, "steady1D"))
    D <- cbind(out$y, as.data.frame(out[.FEMSDIA$out1D_names]))
  else if (inherits(out, "PHDIAdyn") | inherits(out, "PHDIAstd"))
    return(PHDIA_get_1Dvars(out = out, which = which))
  else if (inherits (out, "deSolve")) {
    D <- NULL
    for (cc in c(.FEMSDIA$y_names, .FEMSDIA$out1D_names))
     D <- cbind(D,MeanVal(cbind(out[,1],subset(out, which = cc))))
    rownames(D) <- NULL
    colnames(D) <- c(.FEMSDIA$y_names, .FEMSDIA$out1D_names)
    D <- as.data.frame(D)  
  }
  else stop("object 'out' not supported")
 
  D <- cbind(x = FEMSDIA_get_depth(out), por = FEMSDIA_get_por(out), D)
  if (! is.null(which))
   D <- D[ ,c( "x", "por", which)]
  
 phP <- NULL
 if (dynamicpH){
   phP <- PHDIA_get_1Dvars(out = out, which = which)
 }
 if (! is.null(phP)) {
   if (is.vector(D)) 
      D <- c(D, phP)
   else
      D <- rbind(D, phP)
 }
 
 D  
} 
  
##------------------------------------

FEMSDIA_get_states <- function(out, which = NULL, 
  dynamicpH = FALSE) {
  if (missing(out)) 
    return(data.frame(names = .FEMSDIA$y_names, 
                      units = .FEMSDIA$y_units, 
                      description = .FEMSDIA$y_description))
  
  else if (inherits(out, "PHDIAdyn") | inherits(out, "PHDIAstd"))
    return(PHDIA_get_states(out = out, which = which))

  if (inherits (out, "steady1D"))
    D <- out$y
  else if (inherits (out, "deSolve")) {
    D <- NULL
    for (cc in .FEMSDIA$y_names)
      D <- cbind(D,MeanVal(cbind(out[,1],subset(out, which = cc))))
    rownames(D) <- NULL
    colnames(D) <- .FEMSDIA$y_names
    D <- as.data.frame(D)  
  }
  else stop("object 'out' not supported")
  
  D <- cbind(x = FEMSDIA_get_depth(out), por = FEMSDIA_get_por(out), D)
  if (! is.null(which))
    D <- D[ ,c( "x", "por", which)]
  
 phP <- NULL
 if (dynamicpH){
   phP <- PHDIA_get_states(out = out, which = which)
 }
 
 if (! is.null(phP)) {
   if (is.vector(D)) 
      D <- c(D, phP)
   else
      D <- rbind(D, phP)
 }
  D  
} 

## ============================================================================
## ============================================================================
##   Functions to extract parameters and variables from PHDIA models
## ============================================================================
## ============================================================================

PHDIA_get_parms <- function(out = NULL, as.vector = FALSE, which = NULL) {
  if (is.null(out))
    Parms <- c(.FEMSDIA$parms, .PHDIA$parms)
  else if (inherits (out, "steady1D"))
    Parms <- out$parms
  else if (inherits (out, "deSolve"))
    Parms <- attr(out, "parms")
  else stop("object 'out' not supported")
  
  if (as.vector) {
    if (! is.null(which))
      Parms <- Parms[which]
    return(Parms)
  } else {
    Pn <- names(Parms)
    Units <- c(.FEMSDIA$parms_units, .PHDIA$parms_units)
    Parms <- data.frame(parms = Parms, units = Units, 
       description = c(.FEMSDIA$parms_description, .PHDIA$parms_description))
    row.names(Parms) <- Pn   
    if (! is.null(which))
      Parms <- Parms[which, ]
    return(Parms)
  }
}

##------------------------------------

PHDIA_get_0Dvars <- function(out, as.vector = FALSE, which = NULL) {
  if (missing(out)) {
    Dnames <- c(.FEMSDIA$out0D_names, .PHDIA$forc_names, .PHDIA$out0D_names)
    D <- rep(NA, times = length(Dnames))
    names(D) <- Dnames
  } else if (inherits (out, "steady1D"))
    D <- unlist(out[c(.FEMSDIA$out0D_names, .PHDIA$forc_names, 
                      .PHDIA$out0D_names)])
  else if (inherits (out, "deSolve"))
    D <- MeanVal(out[, c("time",.FEMSDIA$out0D_names, 
                         .PHDIA$forc_names, .PHDIA$out0D_names)])
  else stop("object 'out' not supported")
 
 if (! as.vector)
   D <- data.frame(names = names(D), values = D, 
     units = c(.FEMSDIA$out0D_units, .PHDIA$forc_units, .PHDIA$out0D_units), 
     description = c(.FEMSDIA$out0D_description, .PHDIA$forc_description, 
                     .PHDIA$out0D_description))
 
 if (! is.null(which)){
   if (is.vector(D))
     D <- D[which]
#    else if (inherits (out, "deSolve"))
#     D <- D[, which]  
   else D <- D[which,]  
 } 
 D
} 

##------------------------------------

PHDIA_get_1Dvars <- function(out, which = NULL) {
  if (missing(out)) 
    return(data.frame(names = c(.FEMSDIA$out1D_names, .PHDIA$out1D_names), 
      units = c(.FEMSDIA$out1D_units, .PHDIA$out1D_units), 
      description = c(.FEMSDIA$out1D_description, .PHDIA$out1D_description)))
  
 if (inherits (out, "steady1D"))
    D <- cbind(out$y, as.data.frame(out[c(.FEMSDIA$out1D_names, .PHDIA$out1D_names)]))
 else if (inherits (out, "deSolve")) {
   D <- NULL
   for (cc in c(.FEMSDIA$y_names, .PHDIA$y_names, .FEMSDIA$out1D_names,
                .PHDIA$out1D_names))
     D <- cbind(D,colMeans(subset(out, which = cc)))
   rownames(D) <- NULL
   colnames(D) <- c(.FEMSDIA$y_names, .PHDIA$y_names, .FEMSDIA$out1D_names,
                    .PHDIA$out1D_names)
   D <- as.data.frame(D)  
 }
 else stop("object 'out' not supported")
 
 D <- cbind(x = FEMSDIA_get_depth(out), por = FEMSDIA_get_por(out), D)
 if (! is.null(which))
   D <- D[ ,c( "x", "por", which)]
 D  
} 
  
##------------------------------------

PHDIA_get_states <- function(out, which = NULL) {
  if (missing(out)) 
    return(data.frame(names = c(.FEMSDIA$y_names, .PHDIA$y_names), 
    units = c(.FEMSDIA$yunits,.PHDIA$y_units), 
    description = c(.FEMSDIA$y_description, .PHDIA$y_description)))
  
  if (inherits (out, "steady1D"))
    D <- out$y
  else if (inherits (out, "deSolve")) {
    D <- NULL
    for (cc in c(.FEMSDIA$y_names, .PHDIA$y_names))
      D <- cbind(D,colMeans(subset(out, which = cc)))
    rownames(D) <- NULL
    colnames(D) <- c(.FEMSDIA$y_names, .PHDIA$y_names)
    D <- as.data.frame(D)  
  }
  else stop("object 'out' not supported")
  
  D <- cbind(x = FEMSDIA_get_depth(out), por = FEMSDIA_get_por(out), D)
  if (! is.null(which))
    D <- D[ ,c( "x", "por", which)]
  D  
} 
