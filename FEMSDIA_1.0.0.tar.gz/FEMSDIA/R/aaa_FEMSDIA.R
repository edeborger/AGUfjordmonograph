## A local environment for non user-visible data,
## ====================================================================

.FEMSDIA <- new.env()

.FEMSDIA$N     <- 100  # do not change this without adapting the fortran code!
.FEMSDIA$Grid  <- setup.grid.1D(x.up=0, dx.1 = 0.0001, N = .FEMSDIA$N, L = 1)

##-------------------------------------------------------------------
## Parameters - note all rates defined at base temperature
## If you want no temperature dependency, set base temp = actual temp
##-------------------------------------------------------------------

.FEMSDIA$parms <- c(
  ## organic matter dynamics  #
    Cflux      = 2e4/12/365, # mmolC/m2/d  organic Carbon deposition
    pFast      = 0.9     , # -           fraction fast detritus in flux
    RDETflux   = 0.5     , # mmolC/m2/d  refractory Carbon deposition
  
    MnO2flux   = 0       , # mmolMn/m2/d deposition rate of MnO2
    FeOH3flux  = 0.01    , # mmolFe/m2/d FeOH3 deposition rate 0.01
    FePflux    = 0       , # mmolP/m2/d  deposition rate of FeP
    CaPflux    = 0       , # mmolP/m2/d  deposition rate of CaP
    Padsflux   = 0       , # mmolP/m2/d  deposition rate of adsorbed P
    FeSflux    = 0       , # mmolFe/m2/d deposition rate of FeS
    FeS2flux   = 0       , # mmolFe/m2/d deposition rate of FeS2
    S0flux     = 0       , # mmolS/m2/d  deposition rate of S0
    
    rFast      = 25/365  , # /d          decay rate fast decay detritus
    rSlow      = 0.05/365, # /d          decay rate slow decay detritus
    rRefrac    = 0.0     , # /d          decay rate refractory detritus
    
    NCrFdet    = 16/106  , # molN/molC   NC ratio fast decay detritus
    NCrSdet    = 16/106  , # molN/molC   NC ratio slow decay detritus
    NCrRdet    = 16/106  , # molN/molC   NC ratio refractory detritus
    PCrFdet    = 1/106   , # molP/molC   PC ratio fast decay det.
    PCrSdet    = 1/106   , # molP/molC   PC ratio slow decay det.
    PCrRdet    = 1/106   , # molP/molC   PC ratio refractory det.

  ## Nutrient bottom water conditions
    BCupLiq    = 2       , # upper boundary condition for liquid; 1= flux, 2=conc, 3 = 0-grad
    BCdownLiq  = 3       , # lower boundary condition; default = 0-gradient
    O2bw       = 300     , # mmol/m3    Oxygen conc in bottom water
    NO3bw      = 10      , # mmol/m3
    NO2bw      = 0       , # mmol/m3
    NH3bw      = 1       , # mmol/m3
    Mnbw       = 0.0     , # mmol/m3
    Febw       = 0       ,
    H2Sbw      = 0       ,
    SO4bw      = 31000   ,
    CH4bw      = 0       , # mmol/m3
    PO4bw      = 0.5     , # mmol/m3
    DICbw      = 2100    ,
    ALKbw      = 2400    ,

    O2dw       = NA      , # mmol/m3    deep boundary concentrations
    NO3dw      = NA      , # mmol/m3
    NO2dw      = NA      , # mmol/m3
    NH3dw      = NA      , # mmol/m3
    Mndw       = NA      , # mmolMn/m3 deep water concentration of Mn2+
    Fedw       = NA      ,
    H2Sdw      = NA      ,
    SO4dw      = NA      ,
    CH4dw      = NA      , # mmol/m3
    PO4dw      = NA      , # mmol/m3
    DICdw      = NA      ,
    ALKdw      = NA      ,

    TOC0       = 0.5     , # %           TOC concentration at depth 
  
    por0       = 0.9     , # -            surface porosity
    pordeep    = 0.5     , # -            deep porosity
    porcoeff   = 0.003   , # m           porosity coefficient
    formationtype = 1    , # to estimate effective diffusion, 1=sand, 2=mud, 3=general
  
  ## Bioturbation, advection, bio-irrigation
    DBL        = 0.001   , # m         thickness of the diffusive boundary layer
    flow       = 0       , # m3/m2/dd  bulk flow rate (water)  
    w          = 5e-6    , # m/d       advection (sediment accretion) rate
    biot       = 1e-4/365, # m2/d      bioturbation coefficient
    biotdepth  = 0.05    , # m         depth of mixed layer
    biotatt    = 0.01    , # m         depth attenuation coefficient below biotdepth
    irr        = 0       , # /d        bio-irrigation rate
    irrdepth   = 0.05    , # m         depth of irrigates layer
    irratt     = 0.01    , # m         depth attenuation coefficient below irrdepth
    gasflux    = 0       , # m/d       piston velocity for dry flats-exchange of O2 & DIC
    Q10        = 1       , # -         Q10  temperature multiplication factor for all rates
    Treference = 15      , # dg C      reference temperature (at which rates are defined)

    Twater     = 10      , # deg C     temperature of overlying water
    Swater     = 35      , # -         salinity of overlying water
  
    ksO2oxic   = 3.      , # mmolO2/m3   half-sat O2 in oxic mineralisation
    ksNO3denit = 30.     , # mmolNO3/m3  half-sat NO3 in denitrification
    kinO2denit = 1.      , # mmolO2/m3   half-sat O2 inhib denitrification
    kinO2anox  = 0.001   , # mmolO2/m3   half-sat O2 inhib anoxic min
    kinNO3anox = 1.      , # mmolNO3/m3  half-sat NO3 inhib anoxic degr
    ksMnO2     = 5000    , # mmolMnO2/m3 half-sat MnO2 in manganese red - Wijsman 2002
    kinMnO2    = 5000    , # mmolMnO2/m3 half-sat MnO2 inhib - Wijsman 2002
    ksFeOH3    = 12500.  , # mmolFe/m3   half-sat FeOH3 in iron red  
    kinFeOH3   = 12500.  , # mmolFe/m3   half-sat FeOH3 inhib BSR
    ksSO4BSR   = 1600.   , # mmolSO4/m3  half-sat SO4 in sulfate reduction
    kinSO4Met  = 1000    , # mmolSO4/m3  half-sat SO4 inhibition for methanogenesis

  ## nitrogen parameters
    NH3Ads     = 1.3     , # -          adsorption coeff ammonium
    rnitri1    = 20      , # /d         nitrification rate (step1) - oxidation of ammonium  
    rnitri2    = 20.     , # /d         nitrification rate (step2) - oxidation of nitrite
    ksO2nitri  = 1.      , # mmolO2/m3  half-sat O2 in nitrification
    ranammox   = 0.1     , # /(mmol/m3)/d   Anammox rate
    
  ## phosphate parameters
    rFePadsorp = 1e-6    , # /(mmolLiq/m3)/day P adsorption to Fe-oxides
    rCaPprod   = 0.0     , # /(mmolLiq/m3)/day CaP production rate (apatite)
    rCaPdiss   = 0.0     , # /d           CaP dissolution rate
    CPrCaP     = 1.32/4.6, # molC:molP   Ca_P ratio in apatite Ca10(PO4)4.6(CO3)1.32F1.87(OH)1.45 Jilbert and Slomp
    rPads      = 0.0     , # /day -  adsorption rate of phosphate
    rPdes      = 0.0     , # /day - desorption rate of adsorbed P
    maxPads    = 1e3     , # Max adsorbed P concentration - mmolP/m3 solid
  
  ## Fe, Mn and S  
    rFeSprod     = 1e-4  , # m3 liquid/mmol/d FeS2 production rate - Rickard (1997a)
    rFeS2prod_S0 = 0     , # /d/mmol/m3  FES2 production rate, with S0
    rFeS2prod_HS = 0     , # /d/mmol/m3  FES2 production rate, with HS
    rMnCO3prod   = 0     , #3e-4,     # m3/mmol/d MnCO3 production rate
    rFeCO3prod   = 0     , #3e-4,     # m3/mmol/d FeCO3 production rate
    
    rMnox      = 0.3     , #3e-7*86400, # m3/mmol/d Manganese oxidation rate with O2 
    rFeox      = 0.3     , # /d/mmol/m3  oxidation ct for iron by O2 (bimolecular rate law)
    rH2Sox     = 5e-4    , # /d/mmol/m3  oxidation ct for diss Sulfide by O2 (bimolecular rate law)
    rCH4ox     = 27      , # /d/mmol/m3  oxidation ct for CH4 by O2 (bimolecular rate law)
    rAOM       = 3e-5    , # /d/mmol/m3  oxidation ct for AOM CH4 by SO4 (bimolecular rate law)

   # New MTM same order DLL
    rH2SMnox   = 0       , # 5.48e-5 , m3/mmol/d rate of H2S oxidation by MnO2 - Wijsman 2002
    rH2SFeox   = 0       , # 1.2e-7  , m3/mmol/d rate of H2S oxidation by FeOH3 - Wijsman 2002
    rFeMnox    = 0       , # 8e-6 ,    m3/mmol/d rato of Fe + MnOx reaction- Wijsman 2002 #7.5e-11*86400,
    rFeSox     = 8.22e-4 , # 0,        m3/mmol/d FeS oxidation rate - Wijsman 2002
    rFeS2ox    = 0       , # 8.22e-4 , m3/mmol/d FeS2 oxidation rate - ??
    
    rSurfH2Sox = 0.      , # /d           Max rate oxidation of deep H2S with surface O2 
    rSurfCH4ox = 0.      , # /d           Max rate oxidation of deep CH4 with surface O2 
    ksSurfALK  = 3000.   , # mmol/m3      half-sat alkalinity in reoxidation of CH4 or H2S with O2
    ksO2reox   = 1.      , # mmolO2/m3    half-sat O2 in reoxidation of CH4 or H2S with O2
    
    ODUoxdepth = 0.05    , # m            Depth where oxidation of H2S/ODU with surface water O2 is possible
    ODUoxatt   = 0.01    , # m           the depth attenuation coeff of H2S/ODU oxidation below ODUoxdepth.
  
# parameters if bottom water is dynamically described
    dilution   = 0       , # /day         relaxation towards background conc dissolved
    Hwater     = 0.1     , # m           height of water over core
    Cfall      = 1       , # m/day       fall speed of organic carbon (FDET, SDET)
    FePfall    = 1       , # m/day       fall speed of FeP
    FeOH3fall  = 1       , # m/day       fall speed of FeOH3
    CaPfall    = 1       , # m/day       fall speed of CaP
    MnO2fall   = 1       , # m/d         fall speed of MnO2 

  ## MPB production
    MPBprod    =     0   , # mmol/m3/d   maximal rate - range: 5000-5e4
    kdSed      =  2000   , # /m,         exponential decay of MPB production with depth 
    kNH3upt    =  0.01   , # mmol/m3,    DIN limitation constant
    kPO4upt    = 0.001   , # mmol/m3,    P limitation constant
    kDICupt    =     1     # mmol/m3,    C limitation constant
     
    )

# parameter units
.FEMSDIA$parms_units <- c(   
  Cflux     = "mmolC/m2/d",  # Reactive organic Carbon deposition
  pFast     = "-",           # fraction fast detritus in flux
  RDETflux  = "mmolC/m2/d",  # refractory Carbon deposition
  
  MnO2flux  = "mmolMn/m2/d", # deposition rate of MnO2
  FeOH3flux = "mmolFe/m2/d", # FeOH3 deposition rate 0.01
  FePflux   = "mmolP/m2/d",  # deposition rate of FeP
  CaPflux   = "mmolP/m2/d",  # deposition rate of CaP
  Padsflux  = "mmolP/m2/d",  # deposition rate of adsorbed P
  FeSflux   = "mmolFe/m2/d", # deposition rate of FeS
  FeS2flux  = "mmolFe/m2/d", # deposition rate of FeS2
  S0flux    = "mmolS/m2/d",  # deposition rate of S0
  rFast     = "/d",          # decay rate fast decay detritus
  rSlow     = "/d",          # decay rate slow decay detritus
  rRefrac   = "/d",          # decay rate RDET 
  NCrFdet   = "molN/molC",   # NC ratio fast decay detritus
  NCrSdet   = "molN/molC",   # NC ratio slow decay detritus
  NCrRdet   = "molN/molC",   # NC ratio refractory detritus
  PCrFdet   = "molP/molC",   # PC ratio fast decay det.
  PCrSdet   = "molP/molC",   # PC ratio slow decay det.
  PCrRdet   = "molP/molC",   # PC ratio refractory det.
  
  ## Nutrient bottom water conditions
  BCupLiq   = "-", # upper boundary cond. for liquid; 1= flux, 2=conc, 3 = 0-grad
  BCdownLiq = "-", # lower boundary cond. ; default = 0-gradient
  O2bw      = "mmol/m3",     # Oxygen conc/flux in bottom water
  NO3bw     = "mmol/m3",     #
  NO2bw     = "mmol/m3",     #
  NH3bw     = "mmol/m3",     #
  Mnbw      = "mmol/m3",     #
  Febw      = "mmol/m3",     #
  H2Sbw     = "mmol/m3",     #
  SO4bw     = "mmol/m3",     #
  CH4bw     = "mmol/m3",     #
  PO4bw     = "mmol/m3",     #
  DICbw     = "mmol/m3",     #
  ALKbw     = "mmol/m3",     #

  O2dw      = "mmol/m3",     # deep boundary concentrations
  NO3dw     = "mmol/m3",     #
  NO2dw     = "mmol/m3",     #
  NH3dw     = "mmol/m3",     #
  Mndw      = "mmol/m3",     # deep water concentration of Mn2+
  Fedw      = "mmol/m3",     #
  H2Sdw     = "mmol/m3",     #
  SO4dw     = "mmol/m3",     #
  CH4dw     = "mmol/m3",     #
  PO4dw     = "mmol/m3",     #
  DICdw     = "mmol/m3",     #
  ALKdw     = "mmol/m3",     #

  TOC0      = "%",           # TOC concentration at depth 
  
  por0      = "-",       # surface porosity
  pordeep   = "-",       # deep porosity
  porcoeff  = "m",       # porosity coefficient
  formationtype = "-",   # to estimate effective diffusion, 1=sand, 2=mud, 3=general
  
  ## Bioturbation, advection, bio-irrigation
  DBL        = "m",       # thickness of the diffusive boundary layer
  flow       = "m3/m2/d", # bulk flow rate (water)  
  w          = "m/d",    # advection rate
  biot       = "m2/d",   # bioturbation coefficient
  biotdepth  = "m",      # depth of mixed layer
  biotatt    = "m",      # depth attenuation coefficient below biotdepth
  irr        = "/d",     # bio-irrigation rate
  irrdepth   = "m",      # depth of irrigates layer
  irratt     = "m",      # depth attenuation coefficient below irrdepth
  gasflux    = "m/d",    # piston velocity for dry flats - exchange of O2&DIC only+deposition 
  Q10        =  "-",     # Q10  temperature multiplication factor for all rates
  Treference = "deg C",  # reference temperature (at which rates are defined)
  Twater     = "deg C",  # temperature of overlying water

  ## To estimate diffusion coefficients
  Swater     = "-", #           salinity
  
  ## Mineralisation parameters  
  ksO2oxic    = "mmolO2/m3",    # half-sat O2 in oxic mineralisation
  ksNO3denit  = "mmolNO3/m3",   # half-sat NO3 in denitrification
  kinO2denit  = "mmolO2/m3",    # half-sat O2 inhib denitrification
  kinO2anox   = "mmolO2/m3",    # half-sat O2 inhib anoxic min
  kinNO3anox  = "mmolNO3/m3",   # half-sat NO3 inhib anoxic degr
  ksMnO2      = "mmolMnO2/m3",  # half-sat MnO2 in manganese red - Wijsman 2002
  kinMnO2     = "mmolMnO2/m3",  # half-sat MnO2 inhib - Wijsman 2002
  ksFeOH3     = "mmolFeOH3/m3", # half-sat FeOH3 in iron red  
  kinFeOH3    = "mmolFeOH3/m3", # half-sat FeOH3 inhib BSR
  ksSO4BSR    = "mmolSO4/m3",   # half-sat SO4 in sulfate reduction
  kinSO4Met   = "mmolSO4/m3",   # half-sat SO4 inhibition for methanogenesis
  
  ## N parameters
  NH3Ads     = "-",     # Adsorption coeff ammonium
  rnitri1    = "/d",    # Max nitrification rate (step1) - oxidation of ammonium  
  rnitri2    = "/d",    # Max nitrification rate (step2) - oxidation of nitrite
  ksO2nitri  = "mmolO2/m3",    # half-sat O2 in nitrification
  ranammox   = "/(mmol/m3)/d", # Anammox rate
  
  ## P prameters
  rFePadsorp  = "/(mmolLiq/m3)/d", # P adsorption to Fe-oxides
  rCaPprod    = "/(mmolLiq/m3)/d", # CaP production rate (apatite)
  rCaPdiss    = "/d",              # CaP dissolution rate
  CPrCaP      = "molC:molP",       # Ca_P ratio in apatite Ca10(PO4)4.6(CO3)1.32F1.87(OH)1.45   Jilbert and Slomp
  rPads       = "/d",            # adsorption rate of phosphate
  rPdes       = "/d",            # desorption rate of adsorbed P
  maxPads     = "mmolP/m3 sol.", # Max adsorbed P concentration - 
  
  rFeSprod     = "m3/mmol/d", # FeS production rate - Rickard (1997a)
  rFeS2prod_S0 = "/d/mmol/m3",    # FeS2 production rate with S0
  rFeS2prod_HS = "/d/mmol/m3",    # FeS2 production rate with H2S
  rMnCO3prod   = "m3/mmol/d",     # MnCO3 production rate
  rFeCO3prod   = "m3/mmol/d",     # FeCO3 production rate
  
  rMnox       = "m3/mmol/d",  # Manganese oxidation rate with O2 
  rFeox       = "/d/mmol/m3", # oxidation ct for iron by O2 (bimolecular rate law)
  rH2Sox      = "/d/mmol/m3", # oxidation ct for diss Sulfide by O2 (bimolecular rate law)
  rCH4ox      = "/d/mmol/m3", # oxidation ct for CH4 by O2 (bimolecular rate law)
  rAOM        = "/d/mmol/m3", # oxidation ct for AOM CH4 by SO4 (bimolecular rate law)
  
  # New MTM same order DLL
  rH2SMnox    = "m3/mmol/d", # rate of H2S oxidation by MnO2 - Wijsman 2002
  rH2SFeox    = "m3/mmol/d", # rate of H2S oxidation by FeOH3 - Wijsman 2002
  rFeMnox     = "m3/mmol/d", # rate of Fe + MnOx reaction- Wijsman 2002 #7.5e-11*86400,
  rFeSox      = "m3/mmol/d", # FeS oxidation rate - Wijsman 2002
  rFeS2ox     = "m3/mmol/d", # FeS2 oxidation rate - ??
  
  rSurfH2Sox  = "/d",      # Max rate oxidation of deep H2S with surface O2 
  rSurfCH4ox  = "/d",      # Max rate oxidation of deep CH4 with surface O2 
  ksSurfALK   = "mmol/m3", # half-sat alkalinity in reoxidation of CH4 or H2S with O2
  ksO2reox    = "mmolO2/m3", # half-sat O2 in reoxidation of CH4 or H2S with O2
  
  ODUoxdepth  = "m",         # Depth where oxidation of H2S/ODU with surface water O2 is possible
  ODUoxatt    = "m",         # depth attenuation coeff of H2S/ODU oxidation below ODUoxdepth.
  
  # parameters if bottom water is dynamically described
  dilution    = "/d",  #  relaxation towards background conc dissolved
  Hwater      = "m",   #  height of water over core
  Cfall       = "m/d", #  fall speed of organic carbon (FDET, SDET)
  FePfall     = "m/d", #  fall speed of FeP
  FeOH3fall   = "m/d", #  fall speed of FeOH3
  CaPfall     = "m/d", #  fall speed of CaP
  MnO2fall    = "m/d", #  fall speed of MnO2 

  ## MPB production
  MPBprod     = "mmol/m3/d", # maximal rate - range: 5000-5e4
  kdSed       = "/m",        # exponential decay of MPB production with depth 
  kNH3upt     = "mmol/m3",   # DIN limitation constant
  kPO4upt     = "mmol/m3",   # P limitation constant
  kDICupt     = "mmol/m3"    # C limitation constant
  
    ) # 

.FEMSDIA$parms_description <- c(
  Cflux       = "total reactive organic C deposition",
  pFast       = "part FDET (fast-deay detritus) in carbon flux", 
  RDETflux    = "refractory Carbon deposition",
  
  MnO2flux    = "deposition rate of MnO2",
  FeOH3flux   = "deposition rate of FeOH3", 
  FePflux     = "deposition rate of FeP",
  CaPflux     = "deposition rate of CaP",
  Padsflux    = "deposition rate of adsorbed P",
  FeSflux     = "deposition rate of FeS",
  FeS2flux    = "deposition rate of FeS2",
  S0flux      = "deposition rate of S0",
  
  rFast       = "decay rate FDET", 
  rSlow       = "decay rate SDET", 
  rRefrac     = "decay rate RDET", 
  
  NCrFdet     = "NC ratio FDET", 
  NCrSdet     = "NC ratio SDET",
  NCrRdet     = "NC ratio RDET",
  PCrFdet     = "PC ratio FDET", 
  PCrSdet     = "PC ratio SDET",
  PCrRdet     = "PC ratio RDET",
  
  BCupLiq     = "upper boundary liq. 1:flux, 2:conc, 3:0-grad",
  BCdownLiq   = "lower boundary liq. 1:flux, 2:conc, 3:0-grad",
  O2bw        = "upper boundary O2  -if BC=1: flux, 2:conc",
  NO3bw       = "upper boundary NO3 -if BC=1: flux, 2:conc",
  NO2bw       = "upper boundary NO2 -if BC=1: flux, 2:conc",
  NH3bw       = "upper boundary NH3 -if BC=1: flux, 2:conc",
  Mnbw        = "upper boundary Mn2+ -if BC=1: flux, 2:conc",
  Febw        = "upper boundary Fe2+ -if BC=1: flux, 2:conc",
  H2Sbw       = "upper boundary H2S -if BC=1: flux, 2:conc",
  SO4bw       = "upper boundary SO4 -if BC=1: flux, 2:conc",
  CH4bw       = "upper boundary CH4 -if BC=1: flux, 2:conc",
  PO4bw       = "upper boundary PO4 -if BC=1: flux, 2:conc",
  DICbw       = "upper boundary DIC -if BC=1: flux, 2:conc",
  ALKbw       = "upper boundary alkalinity -if BC=1: flux, 2:conc",

  O2dw        = "lower boundary O2  -if BC=1: flux, 2:conc",
  NO3dw       = "lower boundary NO3 -if BC=1: flux, 2:conc",
  NO2dw       = "lower boundary NO2 -if BC=1: flux, 2:conc",
  NH3dw       = "lower boundary NH3 -if BC=1: flux, 2:conc",
  Mndw        = "lower boundary Mn2+ -if BC=1: flux, 2:conc",
  Fedw        = "lower boundary Fe2+ -if BC=1: flux, 2:conc",
  H2Sdw       = "lower boundary H2S -if BC=1: flux, 2:conc",
  SO4dw       = "lower boundary SO4 -if BC=1: flux, 2:conc",
  CH4dw       = "lower boundary CH4 -if BC=1: flux, 2:conc",
  PO4dw       = "lower boundary PO4 -if BC=1: flux, 2:conc",
  DICdw       = "lower boundary DIC -if BC=1: flux, 2:conc",
  ALKdw       = "lower boundary alkalinity -if BC=1: flux, 2:conc",
  
  TOC0        = "refractory Carbon conc",
  
  por0        = "surface porosity", 
  pordeep     = "deep porosity", 
  porcoeff    = "porosity decay coefficient",
  formationtype = "formationfactor, 1=sand,2=fine sand,3=general",
  
  DBL         = "thickness of the diffusive boundary layer",
  flow        = "bulk flow rate (water)",  
  w           = "sediment advection (accretion) rate", 
  biot        = "bioturbation coefficient", 
  biotdepth   = "depth of mixed layer", 
  biotatt     = "attenuation coeff below biotdepth", 
  irr         = "bio-irrigation rate", 
  irrdepth    = "depth of irrigated layer", 
  irratt      = "attenuation coeff below irrdepth", 
  gasflux     = "piston velocity for dry flats", 
  Q10         = "Q10  temperature multiplication factor for all rates" ,
  Treference  = "reference temperature (at which rates are defined)",
  Twater      = "temperature of overlying water" ,
  Swater      = "salinity of overlying water", 

  ksO2oxic    = "half-sat O2 in oxic mineralisation",
  ksNO3denit  = "half-sat NO3 in denitrification", 
  kinO2denit  = "half-sat O2 inhib denitrification",
  kinO2anox   = "half-sat O2 inhib anoxic min",
  kinNO3anox  = "half-sat NO3 inhib anoxic degr", 
  ksMnO2      = "half-sat MnO2 in manganese red",
  kinMnO2     = "half-sat MnO2 inhibition",
  ksFeOH3     = "half-sat FeOH3 conc in iron reduction", 
  kinFeOH3    = "half-sat FeOH3 inhibition S reduction",
  ksSO4BSR    = "half-sat SO4 conc in sulphate reduction", 
  kinSO4Met   = "half-sat SO4 inhibition methanogenesis",
  
  NH3Ads      = "Adsorption coeff ammonium",
  rnitri1     = "Max nitrification rate step1 (NH3ox)", 
  rnitri2     = "Max nitrification rate step2 (NO2ox)",
  ksO2nitri   = "half-sat O2 in nitrification", 
  ranammox    = "Anammox rate", 
  
  rFePadsorp  = "rate FeP adsorption",
  rCaPprod    = "rate CaP production", 
  rCaPdiss    = "rate CaP dissolution", 
  CPrCaP      = "C:Pratio in CaP",
  rPads       = "adsorption rate PO4", 
  rPdes       = "desorption rate of adsorbed P", 
  maxPads     = "pax adsorbed P concentration", 
  
  rFeSprod    = "FeS2 production rate",
  rFeS2prod_S0 = "FeS2 production rate (with S0)",
  rFeS2prod_HS = "FeS2 production rate (with H2S)",
  rMnCO3prod  = "MnCO3 production rate",
  rFeCO3prod  = "FeCO3 production rate",
  
  rMnox       = "Manganese oxidation rate with O2", 
  rFeox       = "max rate Fe oxidation", 
  rH2Sox      = "max rate H2S oxidation", 
  rCH4ox      = "max rate CH4 oxidation with O2", 
  rAOM        = "max rate anaerobic oxidation Methane", 
  
  rH2SMnox    = "rate of H2S oxidation by MnO2",
  rH2SFeox    = "rate of H2S oxidation by FeOH3",
  rFeMnox     = "rate of Fe + MnOx reaction",
  rFeSox      = "FeS oxidation rate",
  rFeS2ox      = "FeS oxidation rate",
  
  rSurfH2Sox  = "max rate H2S oxidation with BW O2", 
  rSurfCH4ox  = "max rate CH4 oxidation with BW O2", 
  ksSurfALK   = "half-sat Alkalinity in oxidation of H2S/CH4 with bwO2", 
  ksO2reox    = "half-sat Oxygen in oxidation of H2S/CH4 with bwO2", 
  ODUoxdepth  =  "Max depth H2S/CH4 oxidation with BW O2", 
  ODUoxatt    = "depth attenuation ODU oxidation",

  dilution    = "relaxation towards background conc ", 
  Hwater      = "height of water over sediment",
  Cfall       = "fall speed of organic C (FDET, SDET)", 
  FePfall     = "fall speed of FeP (when Hwater > 0)", 
  FeOH3fall   = "fall speed of FeOH3 (when Hwater > 0)", 
  CaPfall     = "fall speed of CaP (when Hwater > 0)", 
  MnO2fall    = "fall speed of MnO2",

  MPBprod     = "maximal MPB production rate", 
  kdSed       = "sedimentary light extinction coefficient",
  kNH3upt     = "DIN limitation constant MPB", 
  kPO4upt     = "P limitation constant MPB", 
  kDICupt     = "C limitation constant MPB" 
  
)

##------------------------------------
## State variables
##------------------------------------


.FEMSDIA$y_units <- c(FDET  = "mmolC/m3 solid", 
                      SDET  = "mmolC/m3 solid", 
                      RDET  = "mmolC/m3 solid", 
                      O2    = "mmolO/m3 liquid",
                      NO3   = "mmolN/m3 liquid", 
                      NO2   = "mmolN/m3 liquid", 
                      NH3   = "mmolN/m3 liquid", 
                      Mn    = "mmolMn/m3 liquid",  
                      MnO2  = "mmolMn/m3 solid", 
                      Fe    = "mmolFe/m3 liquid", 
                      FeOH3 = "mmolFe/m3 solid", 
                      H2S   = "mmolS/m3 liquid",
                      SO4   = "mmolS/m3 liquid", 
                      CH4   = "mmolC/m3 liquid", 
                      PO4   = "mmolP/m3 liquid",
                      FeP   = "mmolP/m3 solid", 
                      CaP   = "mmolP/m3 solid", 
                      Pads  = "mmolP/m3 solid", 
                      FeS   = "mmolFe/m3 solid", 
                      FeS2  = "mmolFe/m3 solid", 
                      S0    = "mmolS/m3 solid", 
                      DIC   = "mmolC/m3 liquid", 
                      ALK   = "mmol/m3 liquid" 
 )
.FEMSDIA$y_names <- names(.FEMSDIA$y_units)

.FEMSDIA$y_description <- c(FDET  = "Fast decaying Detritus (solid)", 
                            SDET  = "Slow decaying Detritus (solid)",
                            RDET  = "Refractory Detritus (solid)",
                            O2    = "Oxygen (liquid)", 
                            NO3   = "Nitrate (liquid)", 
                            NO2   = "Nitrite (liquid)", 
                            NH3   = "Ammonium/ammonia (liquid)", 
                            Mn    = "Mn2+ (liquid)", 
                            MnO2  = "Mn-oxide (solid)", 
                            Fe    = "Fe2+ (liquid)",
                            FeOH3 = "Fe-oxide (solid)",
                            H2S   = "Sulphide (liquid)",
                            SO4   = "Sulphate (liquid)",
                            CH4   = "Methane (liquid)",
                            PO4   = "Phosphate (liquid)",
                            FeP   = "Iron-bound P (solid)", 
                            CaP   = "Ca-bound P (solid)", 
                            Pads  = "Adsorbed P (solid)",
                            FeS   = "Iron sulphide (solid)", 
                            FeS2  = "Pyrite (solid)", 
                            S0    = "Sulphur monoxide (solid)", 
                            DIC   = "Dissolved Inorganic Carbon (liquid)",
                            ALK   = "Alkalinity (liquid)" 
                            )

.FEMSDIA$ynamesall <- as.vector(sapply(.FEMSDIA$y_names, 
                                      FUN = function(x) rep(x, times = .FEMSDIA$N)))

##------------------------------------
## forcing functions 
##------------------------------------

.FEMSDIA$forc_units <- c(Cflux      = "mmolC/m2/d", 
                         pFast      = "-", 
                         RDETflux   = "mmolC/m2/d", 
                         MnO2flux   = 'mmolMn/m2/d', 
                         FeOH3flux  = "mmolP/m2/d", 
                         DBL        = "m",
                         flow       = 'm3/m2/d',  
                         w          = "m/d", 
                         Bioturbationfactor = "-", 
                         Irrigationfactor   = "-", 
                         O2bw       = "mmol/m3",
                         NO3bw      = "mmol/m3",
                         NO2bw      = "mmol/m3",
                         NH3bw      = "mmol/m3",
                         Mnbw       = 'mmol/m3', 
                         Febw       = "mmol/m3",
                         H2Sbw      = "mmol/m3",
                         SO4bw      = "mmol/m3",
                         CH4bw      = "mmol/m3",
                         PO4bw      = "mmol/m3",
                         DICbw      = "mmol/m3",
                         ALKbw      = "mmol/m3",
                         Gasflux    = "m/d", 
                         MPBprod    = "mmol/m3/d", 
                         Hwater     = "m", 
                         Twater     = "-",
                         Swater     = "-") 

.FEMSDIA$forc_names <- names(.FEMSDIA$forc_units)

.FEMSDIA$forc_description <- c( 
  Cflux      = "Reactive organic carbon flux to sediment (FDET+SDET)", 
  pFast      = "Part FDET in reactive organic carbon flux", 
  RDETflux   = "RDET (refractory carbon) flux to sediment", 
  MnO2flux   = "MnO2 flux to the sediment",      
  FeOH3flux  = "FeOH3 flux to sediment", 
  DBL        = "Thickness of diffusive boundary layer", 
  flow       = 'Water flow rate through sediment (bulk)',  
  w          = "Sedimentat accretion rate (advection)", 
  Bioturbationfactor = "Bioturbation multiplication factor",
  Irrigationfactor = "Irrigation multiplication factor", 
  O2bw       = "Bottom water O2 concentration", 
  NO3bw      = "Bottom water NO3 concentration", 
  NO2bw      = "Bottom water NO2 concentration", 
  NH3bw      = "Bottom water NH3 concentration", 
  Mnbw       = 'Bottom water Mn concentration',  
  Febw       = "Bottom water Fe concentration", 
  H2Sbw      = "Bottom water H2S concentration", 
  SO4bw      = "Bottom water SO4 concentration", 
  CH4bw      = "Bottom water CH4 concentration", 
  PO4bw      = "Bottom water PO4 concentration", 
  DICbw      = "Bottom water DIC concentration", 
  ALKbw      = "Bottom water alkalinity concentration", 
  Gasflux    = "Gas exchange flux (piston velocity)",
  MPBprod    = "MicroPhytoBenthos forcing",
  Hwater     = "Height of water above the sediment",
  Twater     = "Temperature of overlying water",
  Swater     = "Salinity of overlying water"
)

##------------------------------------
## 0-D Variables
##------------------------------------

.FEMSDIA$out0D_units <- c(
    MeanTemperature = "degC",
    O2flux          = "mmolO2/m2/d", 
    O2deepflux      = "mmolO2/m2/d", 
    NO3flux         = "mmolN/m2/d", 
    NO3deepflux     = "mmolN/m2/d", 
    NO2flux         = "mmolN/m2/d", 
    NO2deepflux     = "mmolN/m2/d", 
    NH3flux         = "mmolN/m2/d", 
    NH3deepflux     = "mmolN/m2/d", 
    Mnflux          = "mmolMn/m2/d",  
    Mndeepflux      = "mmolMn/m2/d",
    Feflux          = "mmolFe/m2/d", 
    Fedeepflux      = "mmolFe/m2/d",  
    H2Sflux         = "mmolS/m2/d",  
    H2Sdeepflux     = "mmolS/m2/d", 
    SO4flux         = "mmolS/m2/d",  
    SO4deepflux     = "mmolS/m2/d",  
    CH4flux         = "mmolC/m2/d", 
    CH4deepflux     = "mmolC/m2/d", 
    PO4flux         = "mmolP/m2/d", 
    PO4deepflux     = "mmolP/m2/d", 
    DICflux         = "mmolC/m2/d",
    DICdeepflux     = "mmolC/m2/d", 
    ALKflux         = "mmol/m2/d",  
    ALKdeepflux     = "mmol/m2/d",
    FDETflux        = "mmolC/m2/d",  
    FDETdeepflux    = "mmolC/m2/d", 
    SDETflux        = "mmolC/m2/d", 
    SDETdeepflux    = "mmolC/m2/d",
    RDETdeepflux    = "mmolC/m2/d",
    MnO2surfflux    = "mmolMn/m2/d", 
    MnO2deepflux    = "mmolMn/m2/d", 
    FeOH3surfflux   = "mmolFe/m2/d", 
    FeOH3deepflux   = "mmolFe/m2/d", 
    FePsurfflux     = "mmolP/m2/d",  
    FePdeepflux     = "mmolP/m2/d", 
    CaPsurfflux     = "mmolP/m2/d", 
    CaPdeepflux     = "mmolP/m2/d",  
    FeSsurfflux     = "mmolFe/m2/d", 
    FeSdeepflux     = "mmolFe/m2/d", 
    FeS2surfflux    = "mmolFe/m2/d", 
    FeS2deepflux    = "mmolFe/m2/d", 
    S0surfflux      = "mmolS/m2/d",  
    S0deepflux      = "mmolS/m2/d", 
    OrgCflux        = "mmolC/m2/d", 
    OrgNflux        = "mmolN/m2/d", 
    OrgPflux        = "mmolP/m2/d", 
    DINDIPflux      = "molN/molP",
    DINDIPmean      = "molN/molP", 
    DINDIPdeep      = "molN/molP",
    TotMin          = "mmolC/m2/d", 
    TotOxic         = "mmolC/m2/d", 
    TotDenit        = "mmolC/m2/d", 
    TotMnred        = "mmolC/m2/d", 
    TotFered        = "mmolC/m2/d", 
    TotBSR          = "mmolC/m2/d", 
    TotMeth         = "mmolC/m2/d", 
    PartOxic        = "-", 
    PartDenit       = "-", 
    PartMnred       = "-", 
    PartFered       = "-", 
    PartBSR         = "-", 
    PartMethano     = "-",
  
    TotNH3prodMin   = "mmolN/m2/d", 
    TotPO4prodMin   = "mmolP/m2/d", 
    TotALkprod      = "mmol/m2/d", 

    TotNH3adsorp    = "mmolN/m2/d", 
    TotNitri1       = "mmolN/m2/d", 
    TotNitri2       = "mmolN/m2/d", 
    TotAnammox      = "mmolN/m2/d",  
  
    TotFePprod      = "mmolFe/m2/d", 
    TotCaPprod      = "mmolP/m2/d", 
    TotFePdesorp    = "mmolP/m2/d", 
    TotCaPdiss      = "mmolP/m2/d", 
    TotPadsorp      = "mmolP/m2/d",
  
    TotFeSprod      = "mmolFe/m2/d", 
    TotFeS2prod     = "mmolFe/m2/d",
    TotFeS2prodB    = "mmolFe/m2/d",
    TotMnCO3prod    = "mmolMn/m2/d",
    TotFeCO3prod    = "mmolFe/m2/d",
    
    TotMnoxid       = "mmolMn/m2/d",
    TotFeoxid       = "mmolFe/m2/d", 
    TotH2Soxid      = "mmolS/m2/d", 
    TotCH4oxid      = "mmolC/m2/d", 
    TotAOM          = "mmolS/m2/d",
    
    TotH2SMnoxid    = "mmolS/m2/d",
    TotH2SFeoxid    = "mmolS/m2/d",
    TotFeMnoxid     = "mmolFe/m2/d",
    TotFeSoxid      = "mmolFe/m2/d",
    TotFeS2oxid     = "mmolFe/m2/d",
    
    TotH2Soxsurf    = "mmolS/m2/d", 
    TotCH4oxsurf    = "mmolC/m2/d", 
    
    PartPremoved    = "-", 
    PartNremoved    = "-",
    TotMPBNO3uptake = "mmolN/m2/d", 
    TotMPBNH3uptake = "mmolN/m2/d", 
    TotMPBPO4uptake = "mmolP/m2/d", 
    TotMPBDICuptake = "mmolC/m2/d", 
    TotMPBO2prod    = "mmolO2/m2/d", 
  
    TotalFDET       = "mmolC/m2", 
    TotalSDET       = "mmolC/m2",   
    TotalRDET       = "mmolC/m2",   
    TotalO2         = "mmolO2/m2",  
    TotalNO3        = "mmolN/m2",  
    TotalNO2        = "mmolN/m2",  
    TotalNH3        = "mmolN/m2",  
    TotalMn         = "mmolMn/m2",
    TotalMnO2       = "mmolMn/m2",  
    TotalFe         = "mmolFe/m2",  
    TotalFeOH3      = "mmolFe/m2",  
    TotalH2S        = "mmolS/m2",  
    TotalSO4        = "mmolS/m2",  
    TotalCH4        = "mmolC/m2",  
    TotalPO4        = "mmolP/m2",  
    TotalFeP        = "mmolP/m2", 
    TotalCaP        = "mmolP/m2",  
    TotalPads       = "mmolP/m2",
    TotalFeS        = "mmolFe/m2",
    TotalFeS2       = "mmolFe/m2",
    TotalS0         = "mmolS/m2",
    TotalDIC        = "mmolC/m2", 
    TotalALK        = "mmol/m2"
    ) 

.FEMSDIA$out0D_names <- names(.FEMSDIA$out0D_units)

.FEMSDIA$out0D_description <- c(
    MeanTemperature = "mean sediment temperature",
    O2flux          = "O2 influx sediment-water", 
    O2deepflux      = "O2 efflux lower boundary", 
    NO3flux         = "NO3 influx sediment-water", 
    NO3deepflux     = "NO3 efflux lower boundary", 
    NO2flux         = "NO2 influx sediment-water", 
    NO2deepflux     = "NO2 efflux lower boundary", 
    NH3flux         = "NH3 influx sediment-water", 
    NH3deepflux     = "NH3 efflux lower boundary", 
    Mnflux          = "Mn2+ influx sediment-water", 
    Mndeepflux      = "Mn2+ efflux lower boundary", 
    Feflux          = "Fe2+ influx sediment-water", 
    Fedeepflux      = "Fe2+ efflux lower boundary", 
    H2Sflux         = "H2S influx sediment-water",  
    H2Sdeepflux     = "H2S efflux lower boundary", 
    SO4flux         = "SO4 influx sediment-water",  
    SO4deepflux     = "SO4 efflux lower boundary", 
    CH4flux         = "CH4 influx sediment-water",
    CH4deepflux     = "CH4 efflux lower boundary", 
    PO4flux         = "PO4 influx sediment-water",  
    PO4deepflux     = "PO4 efflux lower boundary", 
    DICflux         = "DIC influx sediment-water", 
    DICdeepflux     = "DIC efflux lower boundary", 
    ALKflux         = "Alkalinity influx sediment-water", 
    ALKdeepflux     = "Alkalinity efflux lower boundary", 
    FDETflux        = "FDET (fast detritus) flux to sediment", 
    FDETdeepflux    = "FDET (fast detritus) efflux lower boundary",
    SDETflux        = "SDET (slow detritus) flux to sediment", 
    SDETdeepflux    = "SDET (slow detritus) efflux lower boundary", 
    RDETdeepflux    = "RDET (refractory carbon) efflux lower boundary", 
    MnO2surfflux    = "MnO2 flux upper boundary" , 
    MnO2deepflux    = "MnO2 efflux lower boundary",
    FeOH3surfflux   = "FeOH3 flux upper boundary", 
    FeOH3deepflux   = "FeOH3 efflux lower boundary",
    FePsurfflux     = "FeP flux upper boundary"  , 
    FePdeepflux     = "FeP efflux lower boundary",
    CaPsurfflux     = "CaP flux upper boundary"  , 
    CaPdeepflux     = "CaP efflux lower boundary",
    FeSsurfflux     = "FeS flux upper boundary"  , 
    FeSdeepflux     = "FeS efflux lower boundary",
    FeS2surfflux    = "FeS2 flux upper boundary" , 
    FeS2deepflux    = "FeS2 efflux lower boundary",
    S0surfflux      = "S0 flux upper boundary"   , 
    S0deepflux      = "S0 efflux lower boundary",
    OrgCflux        = "OrgC influx to sediment", 
    OrgNflux        = "OrgN influx to sediment",
    OrgPflux        = "OrgP influx to sediment",   
    DINDIPflux      = "DIN:DIP ratio flux sediment-water", 
    DINDIPmean      = "DIN:DIP mean concentration",  
    DINDIPdeep      = "DIN:DIP deep concentration", 
    TotMin          = "Vertically integrated Mineralisation",  
    TotOxic         = "Vertically integrated oxic Mineralisation", 
    TotDenit        = "Vertically integrated Denitrification",  
    TotMnred        = "Vertically integrated Manganese reduction",
    TotFered        = "Vertically integrated Iron reduction", 
    TotBSR          = "Vertically integrated Sulphate reduction",
    TotMeth         = "Vertically integrated Methanogenesis", 
    PartOxic        = "Part of mineralisation by oxic min", 
    PartDenit       = "Part of mineralisation by denitrification", 
    PartMnred       = "Part of mineralisation by Mn reduction", 
    PartFered       = "Part of mineralisation by iron reduction",  
    PartBSR         = "Part of mineralisation by sulphate reduction", 
    PartMethano     = "Part of mineralisation by methanogenisis", 
    TotNH3prodMin   = "Vertically integrated NH3 production by mineralisation",
    TotPO4prodMin   = "Vertically integrated PO4 production by mineralisation",
    TotALkprod      = "Vertically integrated alkalinity production",

    TotNH3adsorp    = "Vertically integrated NH3 adsorption",
    TotNitri1       = "Vertically integrated nitrification step 1 (NH3 ox)",
    TotNitri2       = "Vertically integrated nitrification step 2 (NO2 ox)",
    TotAnammox      = "Vertically integrated anammox",
    
    TotFePprod      = "Vertically integrated FeP production", 
    TotCaPprod      = "Vertically integrated CaP production", 
    TotFePdesorp    = "Vertically integrated FeP desorption",
    TotCaPdiss      = "Vertically integrated CaP dissolution", 
    TotPadsorp      = "Vertically integrated P adsorption",
    
    TotFeSprod      = "Vertically integrated FeS production", 
    TotFeS2prod     = "Vertically integrated FeS2 production, using S0",
    TotFeS2prodB    = "Vertically integrated FeS2 production, using HS",
    TotMnCO3prod    = "Vertically integrated MnCO3 production",
    TotFeCO3prod    = "Vertically integrated FeCO3 production",
    
    TotMnoxid       = "Vertically integrated Mn2+ oxidation",
    TotFeoxid       = "Vertically integrated Fe2+ oxidation",
    TotH2Soxid      = "Vertically integrated H2S oxidation",
    TotCH4oxid      = "Vertically integrated CH4 oxidation",
    TotAOM          = "Vertically integrated Anaerobic oxidation methane", 
    
    TotH2SMnoxid    = "Vertically integrated H2S oxidation by MnO2 to S0",
    TotH2SFeoxid    = "Vertically integrated H2S oxidation by FeO2 to S0",
    TotFeMnoxid     = "Vertically integrated Fe oxidation with MnOx",
    TotFeSoxid      = "Vertically integrated FeS oxidation",
    TotFeS2oxid     = "Vertically integrated FeS2 oxidation",

    TotH2Soxsurf    = "Vertically integrated H2S oxidation by surface O2",
    TotCH4oxsurf    = "Vertically integrated CH4 oxidation by surface O2",
    
    PartPremoved    = "Part P removed", 
    PartNremoved    = "Part N removed",
    TotMPBNO3uptake = "Vertically integrated MPB NO3 uptake",
    TotMPBNH3uptake = "Vertically integrated MPB NH3 uptake",
    TotMPBPO4uptake = "Vertically integrated MPB PO4 uptake",
    TotMPBDICuptake = "Vertically integrated MPB DIC uptake",
    TotMPBO2prod    = "Vertically integrated MPB O2 production", 
    TotalFDET       = "Vertically integrated Fast decaying Detritus",
    TotalSDET       = "Vertically integrated Slow decaying Detritus",
    TotalRDET       = "Vertically integrated refractory Detritus",
    TotalO2         = "Vertically integrated Oxygen",
    TotalNO3        = "Vertically integrated Nitrate",
    TotalNO2        = "Vertically integrated Nitrite",
    TotalNH3        = "Vertically integrated Ammonium/ammonia",
    TotalMn         = "Vertically integrated Mn2+",
    TotalMnO2       = "Vertically integrated MnO2",  
    TotalFe         = "Vertically integrated Fe2+",
    TotalFeOH3      = "Vertically integrated FeOH3",
    TotalH2S        = "Vertically integrated H2S",
    TotalSO4        = "Vertically integrated SO4",
    TotalCH4        = "Vertically integrated CH4",
    TotalPO4        = "Vertically integrated Phosphate",
    TotalFeP        = "Vertically integrated Iron-bound P", 
    TotalCaP        = "Vertically integrated Ca-bound P", 
    TotalPads       = "Vertically integrated Adsorbed P",
    TotalFeS        = "Vertically integrated FeS",
    TotalFeS2       = "Vertically integrated FeS2",
    TotalS0         = "Vertically integrated S0",
    TotalDIC        = "Vertically integrated Dissolved Inorganic Carbon",
    TotalALK        = "Vertically integrated alkalinity"
  ) 


##------------------------------------
## 1D variables
##------------------------------------

.FEMSDIA$out1D_units <- c(
        OCpercent     = "%", 
        ONpercent     = "%", 
        Ppercent      = "%",
        Mnpercent     = "%",
        Fepercent     = "%",
        Spercent      = "%", 
        Solidpercent  = "%",
  
        Temperature   = "degC",

        DICprodMin    = "mmolC/m3 liquid/d", 
        DINprodMin    = "mmolN/m3 liquid/d", 
        DIPprodMin    = "mmolP/m3 liquid/d", 
        DICprodCH4    = "mmolC/m3 liquid/d", 
        DICprod       = "mmolC/m3 liquid/d", 
        ALKprod       = "mmol/m3 liquid/d", 
  
        Oxicmin       = "mmolC/m3 liquid/d", 
        Denitrific    = "mmolC/m3 liquid/d", 
        MnredMin      = "mmolC/m3 liquid/d",          
        Feredmin      = "mmolC/m3 liquid/d", 
        BSRmin        = "mmolC/m3 liquid/d", 
        Methmin       = "mmolC/m3 liquid/d",
  
        Nitri1        = "mmolN/m3 liquid/d", 
        Nitri2        = "mmolN/m3 liquid/d", 
        Anammox       = "mmolN/m3 liquid/d", 
  
        FePadsorp     = "mmolFe/m3 liquid/d", 
        FePdesorp     = "mmolP/m3 solid/d",  
        CaPprod       = "mmolP/m3 liquid/d", 
        CaPdiss       = "mmolP/m3 solid/d", 
        Padsorp       = "mmolP/m3 solid/d",
  
        FeSprod       = "mmolFe/m3 liquid/d",  
        FeS2prod      = "mmolFe/m3 liquid/d",
        FeS2prodB     = "mmolFe/m3 liquid/d",
        MnCO3prod     = "mmolMn/m3 liquid/d", 
        FeCO3prod     = "mmolFe/m3 liquid/d", 
  
        Mnoxid        = "mmolMn/m3 liquid/d", 
        Feoxid        = "mmolFe/m3 liquid/d", 
        H2Soxid       = "mmolS/m3 liquid/d", 
        CH4oxid       = "mmolC/m3 liquid/d", 
        AOM           = "mmolS/m3 liquid/d", 
        H2SMnoxid     = "mmolS/m3 liquid/d", 
        H2SFeoxid     = "mmolS/m3 liquid/d", 
        FeMnoxid      = "mmolFe/m3 solid/d", 
        FeSoxid       = "mmolFe/m3 solid/d", 
        FeS2oxid      = "mmolFe/m3 solid/d", 
  
        H2Soxsurf     = "mmolS/m3 liquid/d",  
        CH4oxsurf     = "mmolC/m3 liquid/d",  
        O2distConsump = "mmolO2/m3 liquid/d",  
  
        MPBCprod      = "mmolC/m3 solid/d", 
        MPBO2prod     = "mmolO2/m3 liquid/d", 
        MPBuptakeNO3  = "mmolN/m3 liquid/d", 
        MPBuptakeNH3  = "mmolN/m3 liquid/d", 
        MPBuptakePO4  = "mmolP/m3 liquid/d", 
        MPBuptakeDIC  = "mmolC/m3 liquid/d" 
)

.FEMSDIA$out1D_names <- names(.FEMSDIA$out1D_units)     

.FEMSDIA$out1D_description <- c(
        OCpercent     = "Total Organic Carbon in % of dry sediment profile", 
        ONpercent     = "Total Organic Nitrogen in % of dry sediment profile", 
        Ppercent      = "Total P in % of dry sediment profile", 
        Mnpercent     = "Total Mn in % of dry sediment profile", 
        Fepercent     = "Total Fe in % of dry sediment profile", 
        Spercent      = "Total S in % of dry sediment profile", 
        Solidpercent  = "FeOH3 + MnO2 + FeS + FeS2 n % of dry sediment profile",       
        Temperature   = "Sediment temperature",
        
        DICprodMin    = "DIC production profile (mineralisation)", 
        DINprodMin    = "DIN production profile (mineralisation)",  
        DIPprodMin    = "DIP production profile (mineralisation)", 
        DICprodCH4    = "DIC production via Methane profile",
        DICprod       = "Total DIC production",
        ALKprod       = "Alkalinity production profile", 
  
        Oxicmin       = "Oxic mineralisation profile", 
        Denitrific    = "Denitrification profile", 
        MnredMin      = "Mn reduction mineralisation profile",
        Feredmin      = "Fe reduction mineralisation profile", 
        BSRmin        = "Sulphate reduction mineralisation profile",
        Methmin       = "Methanogensis mineralisation profile",
  
        Nitri1        = "Nitrification step 1 profile (NH3 oxidation)", 
        Nitri2        = "Nitrification step 2 profile (NO2 oxidation)", 
        Anammox       = "Anammox profile", 
  
        FePadsorp     = "FeP adsorption profile", 
        FePdesorp     = "FeP desorption profile",  
        CaPprod       = "CaP production profile", 
        CaPdiss       = "CaP dissolution profile", 
        Padsorp       = "P adsorption profile", 
        
        FeSprod       = "FeS production profile",
        FeS2prod      = "FeS2 production profile, using S0",
        FeS2prodB     = "FeS2 production profile, using HS",
        MnCO3prod     = "MnCO3 production profile",
        FeCO3prod     = "FeCO3 production profile",
  
        Mnoxid        = "Mn2+ oxidation profile",
        Feoxid        = "Fe2+ oxidation profile", 
        H2Soxid       = "H2S oxidaton profile",
        CH4oxid       = "CH4 oxidation profile",  
        AOM           = "Anaerobic oxidation of methane profile", 
        H2SMnoxid     = "H2S oxidation with MnO2 to S0 profile",
        H2SFeoxid     = "H2S oxidation with FeO2 to S0 profile",
        FeMnoxid      = "Fe oxidation with MnOx profile", 
        FeSoxid       = "FeS oxidation profile",
        FeS2oxid      = "FeS2 oxidation profile",

        H2Soxsurf     = "H2S oxidation with surface O2 profile", 
        CH4oxsurf     = "CH4 oxidation with surface O2 profile", 
        O2distConsump = "O2 uptake oxidation with surface O2 profile", 
  
        MPBCprod      = "MPB C production profile",
        MPBO2prod     = "O2 production profile (microphytobenthos)", 
        MPBuptakeNO3  = "MPB NO3 uptake profile", 
        MPBuptakeNH3  = "MPB NH3 uptake profile", 
        MPBuptakePO4  = "MPB PO4 uptake profile", 
        MPBuptakeDIC  = "MPB DIC uptake profile"
)
  
.FEMSDIA$outnames <- c(
     .FEMSDIA$out0D_names, 
     as.vector(sapply(.FEMSDIA$out1D_names, 
                      FUN = function(x) rep(x, times = .FEMSDIA$N))),
     .FEMSDIA$forc_names)

.FEMSDIA$outunits <- c(
  as.vector(sapply(.FEMSDIA$y_units, 
                   FUN = function(x) rep(x, times = .FEMSDIA$N))),
  .FEMSDIA$out0D_units, 
  as.vector(sapply(.FEMSDIA$out1D_units, 
                  FUN = function(x) rep(x, times = .FEMSDIA$N))),
  .FEMSDIA$forc_units)

.FEMSDIA$nout <- length(.FEMSDIA$outnames)

# how to plot the units
.FEMSDIA$labels <- data.frame(
    Units = c("%", "mmolC/m3 liquid/d", "mmolN/m3 liquid/d", 
       "mmolP/m3 liquid/d", "mmolO/m3 liquid/d", "mmolFe/m3 liquid/d",
       "mmolS/m3 liquid/d", "mmolP/m3 solid/d", "mmolC/m3 solid/d",
       "mmol/m3 liquid/d",
       "mmolO2/m2/d", "mmolN/m2/d", "mmolP/m2/d", "mmolC/m2/d",
       "mmolFe/m2/d", "mmolS/m2/d", "mmol/m2/d", "molN/molP", "-",                  
       "mmolO2/m2/d" , "m/d", "/d", "mmol/m3/d", "mmol/m3", 
       "m", "mmolC/m3 solid",                 
       "mmolO/m3 liquid", "mmolN/m3 liquid", "mmolC/m3 liquid", 
       "mmolFe/m3 liquid", "mmolFe/m3 solid",  
       "mmolS/m3 liquid", "mmolP/m3 liquid", "mmolP/m3 solid", "mmol/m3 liquid",
       "mmolC/m2", "mmolO/m2", "mmolN/m2", "mmolFe/m2", "mmolS/m2"),
    Labels = c("%", "mmol/m3.l/d", "mmol/m3.l/d", 
       "mmol/m3.l/d", "mmol/m3.l/d", "mmol/m3.l/d",
       "mmol/m3.l/d", "mmol/m3.s/d", "mmol/m3.s/d", "mmol/m3.l/d",
       "mmol/m2/d", "mmol/m2/d", "mmol/m2/d", "mmol/m2/d",
       "mmol/m2/d", "mmol/m2/d", "mmol/m2/d", "mol/mol", "-",                  
       "mmol/m2/d" , "m/d", "/d", "mmol/m3/d", "mmol/m3", "m", "mmol/m3.s",                 
       "mmol/m3.l", "mmol/m3.l", "mmol/m3.l", "mmol/m3.l", "mmol/m3.s",  
       "mmol/m3.l", "mmol/m3.l", "mmol/m3.s", "mmol/m3.l",
       "mmol/m2",   "mmol/m2", "mmol/m2", "mmol/m2", "mmol/m2")  )

#row.names(.FEMSDIA$labels) <- .FEMSDIA$labels$Units

.FEMSDIA$getplot1D <- 
    rbind(data.frame(names = .FEMSDIA$y_names, 
                     units = .FEMSDIA$labels[.FEMSDIA$y_units,2]),
          data.frame(names = .FEMSDIA$out1D_names, 
                     units = .FEMSDIA$labels[.FEMSDIA$out1D_units, 2]))

